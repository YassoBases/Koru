'use client';

import { useRouter } from 'next/navigation';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from 'react';
import { apiService } from '../src/services/apiService';
import { tokenService } from '../src/services/tokenService';
import {
  DEFAULT_PERMISSIONS,
  LoginResponse,
  LoginUserDto,
  RegisterResponse,
  RegisterUserDto,
} from '../src/types/auth.types';
import { Company } from '../src/types/company.types';
import { ApiError } from '../src/types/error.types';
import { User, UserRole } from '../src/types/user.types';

interface AuthContextType {
  user: User | null;
  company: Company | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  authError: string | null;
  login: (credentials: LoginUserDto) => Promise<LoginResponse>;
  register: (userData: RegisterUserDto) => Promise<RegisterResponse>;
  logout: () => void;
  clearAuthError: () => void;
  updateCompany: (company: Company) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const router = useRouter();

  const clearAuthError = useCallback(() => {
    setAuthError(null);
  }, []);

  const updateCompany = (companyData: Company) => {
    setCompany(companyData);
    if (user && tokenService.getToken()) {
        tokenService.setTokens(tokenService.getToken()!, '', user, companyData);
    }
  }

  const verifyAuth = useCallback(async () => {
    setIsLoading(true);
    try {
      const token = tokenService.getToken();
      const storedUser = tokenService.getUser();
      const storedCompany = tokenService.getCompany();

      if (token && storedUser && !tokenService.isTokenExpired(token)) {
        setUser(storedUser);
        setCompany(storedCompany || null);
        setIsAuthenticated(true);
      } else {
        tokenService.clearAll();
        setUser(null);
        setCompany(null);
        setIsAuthenticated(false);
      }
    } catch (error) {
      console.error('Auth verification failed:', error);
      tokenService.clearAll();
      setUser(null);
      setCompany(null);
      setIsAuthenticated(false);
      if (ApiError.isInstance(error)) {
        setAuthError(error.message);
      } else {
        setAuthError('Failed to verify authentication. Please log in again.');
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    verifyAuth();
  }, [verifyAuth]);

  const login = useCallback(
    async (credentials: LoginUserDto): Promise<LoginResponse> => {
      setIsLoading(true);
      setAuthError(null);
      try {
        const response = await apiService.auth.login(credentials);
        if (response.success && response.user) {
          setUser(response.user);
          setCompany(response.company || null);
          setIsAuthenticated(true);
          
          let redirectPath = '/dashboard';
          switch (response.user.role) {
            case UserRole.SUPERADMIN:
              redirectPath = '/superadmin/users'; // Go directly to user management
              break;
            case UserRole.ADMIN:
              redirectPath = '/admin';
              break;
            case UserRole.COMPANY_ADMIN:
              redirectPath = response.company?.companyId ? `/company/${response.company.companyId}/dashboard` : '/company/create';
              break;
            case UserRole.EMPLOYEE:
              redirectPath = response.company?.companyId ? `/company/${response.company.companyId}/dashboard` : '/login'; // Or an error page
              break;
            case UserRole.INDIVIDUAL:
              redirectPath = '/dashboard';
              break;
          }
          
          router.push(redirectPath);
          
          return response;
        } else {
          const message = response.message || 'Login failed. Please check your credentials.';
          setAuthError(message);
          return { success: false, message };
        }
      } catch (error) {
        console.error('Login error:', error);
        let message = 'An unexpected error occurred during login.';
        if (ApiError.isInstance(error)) {
          message = error.message;
        }
        setAuthError(message);
        return { success: false, message };
      } finally {
        setIsLoading(false);
      }
    },
    [router]
  );

  const register = useCallback(
    async (userData: RegisterUserDto): Promise<RegisterResponse> => {
      setIsLoading(true);
      setAuthError(null);
      try {
        const dataWithPermissions = {
          ...userData,
          permissions: (userData.permissions && userData.permissions.length > 0)
            ? userData.permissions 
            : DEFAULT_PERMISSIONS[userData.role] || ['access_assigned_content']
        };

        const response = await apiService.auth.register(dataWithPermissions);
        
        if (!response.success) {
           const message = response.message || 'Registration failed. Please try again.';
           setAuthError(message);
        }
        
        return response;

      } catch (error) {
        console.error('Registration error:', error);
        let message = 'An unexpected error occurred during registration.';
        if (ApiError.isInstance(error)) {
          message = error.message;
        }
        setAuthError(message);
        return { success: false, message };
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const logout = useCallback(() => {
    tokenService.clearAll();
    setUser(null);
    setCompany(null);
    setIsAuthenticated(false);
    router.push('/login');
  }, [router]);

  const value: AuthContextType = {
    user,
    company,
    isAuthenticated,
    isLoading,
    authError,
    login,
    register,
    logout,
    clearAuthError,
    updateCompany,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
