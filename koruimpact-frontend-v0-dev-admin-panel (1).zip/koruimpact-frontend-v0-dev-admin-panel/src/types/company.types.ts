// src/types/company.types.ts

export enum BusinessModel {
  B2B = 'B2B',
  B2B2C = 'B2B2C'
}

export enum SubscriptionPlan {
  BASIC = 'basic',
  PREMIUM = 'premium', 
  ENTERPRISE = 'enterprise'
}

export enum CompanyStatus {
  ACTIVE = 'active',
  TRIAL = 'trial',
  SUSPENDED = 'suspended'
}

export enum CompanySize {
    STARTUP = "Startup",
    SMALL = "Small",
    MEDIUM = "Medium",
    LARGE = "Large",
    ENTERPRISE = "Enterprise"
}

export interface CompanySettings {
  maxEmployees: number;
  allowedServices: string[];
  customBranding: boolean;
}

export interface ContactInfo {
  email?: string;
  phone?: string;
  address?: {
      street?: string;
      city?: string;
      state?: string;
      country?: string;
      postalCode?: string;
  };
}

export interface BillingInfo {
  [key: string]: any;
}

export interface Company {
  companyId: string;
  name: string;
  description?: string;
  industry?: string;
  size: CompanySize;
  website?: string;
  contactEmail?: string;
  phoneNumber?: string;
  address?: ContactInfo['address'];
  businessModel: BusinessModel;
  subscriptionPlan: SubscriptionPlan;
  status: CompanyStatus;  
  settings: CompanySettings;
  billingInfo: BillingInfo;
  createdAt: string;
  updatedAt: string;
  adminIds: string[];
  memberIds: string[];
}

export interface CreateCompanyDto {
  name: string;
  description?: string;
  industry?: string;
  size: CompanySize;
  website?: string;
  contactEmail?: string;
  phoneNumber?: string;
  address?: ContactInfo['address'];
}

export interface CompanyUpdate {
  name?: string;
  businessModel?: BusinessModel;
  subscriptionPlan?: SubscriptionPlan;
  status?: CompanyStatus;
  settings?: Partial<CompanySettings>;
  contactInfo?: Partial<ContactInfo>;
  billingInfo?: BillingInfo;
  adminIds?: string[];
  memberIds?: string[];
}

export interface AddAdminDto {
  email: string;
}
export interface CompanyResponse {
  success: boolean;
  message?: string;
  data: Company;
}

export interface CompaniesResponse {
  success: boolean;
  message?: string;
  data: Company[];
  pagination?: {
    total: number;
    page: number;
    limit: number;
  };
}