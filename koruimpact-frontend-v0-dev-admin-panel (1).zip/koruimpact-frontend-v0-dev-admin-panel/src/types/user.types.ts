// src/types/user.types.ts
import { Company } from './company.types';

// This is now the single source of truth for user roles.
export enum UserRole {
  SUPERADMIN = 'superadmin',
  ADMIN = 'admin',
  COMPANY_ADMIN = 'company_admin',
  EMPLOYEE = 'employee',
  INDIVIDUAL = 'individual',
}

export interface UserProfile {
  description?: string;
  phone?: string;
  department?: string;
  position?: string;
  photoURL?: string;
  [key: string]: any;
}

export interface User {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  isActive: boolean;
  companyId?: string;
  company?: Company;
  permissions: string[];
  profile: UserProfile;
  createdAt: string;
  updatedAt: string;
}

// DTOs for creating/updating users
export interface CreateUserDto {
  email: string;
  password?: string;
  displayName: string;
  role: UserRole;
  companyId?: string;
  permissions?: string[];
  profile?: UserProfile;
}

export interface UpdateUserDto {
  email?: string;
  displayName?: string;
  role?: UserRole;
  isActive?: boolean;
  companyId?: string;
  permissions?: string[];
  profile?: UserProfile;
}

// API Response Wrappers
export interface UserResponse {
  success: boolean;
  message?: string;
  data: User;
}

export interface UsersResponse {
  success: boolean;
  message?: string;
  data: User[];
  pagination?: {
    total: number;
    page: number;
    limit: number;
  };
}
