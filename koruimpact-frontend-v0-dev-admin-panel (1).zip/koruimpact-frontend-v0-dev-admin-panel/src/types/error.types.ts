// src/types/error.types.ts

// Matches the ValidationError structure from swagger-schema-errors.png
export interface ValidationError {
  type: string;
  value: any;
  msg: string;
  path: string;
  location: string;
}

// A robust ApiError class for consistent error handling
export class ApiError extends Error {
  public code: string;
  public details?: any;

  constructor(message: string, code: string = 'API_ERROR', details?: any) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.details = details;
    Object.setPrototypeOf(this, ApiError.prototype);
  }

  static isInstance(obj: any): obj is ApiError {
    return obj instanceof ApiError;
  }
}
