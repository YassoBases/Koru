import { User } from './user.types';
import { Company } from './company.types';
import { Task } from './task.types';
import { Content } from './content.types';
import { Notification } from './notification.types';
import { Project } from './project.types';

// Generic API response wrapper
export interface ApiResponse<T> {
  data: T;
  message: string;
  success: boolean;
}

// Paginated API response
export interface PaginatedApiResponse<T> {
  data: T[];
  message: string;
  success: boolean;
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

// Generic error response
export interface ApiErrorResponse {
  error: string;
  code: string;
  details?: any;
}

export class ApiError extends Error {
  public status: number;
  public code?: string;
  public details?: any;
  public timestamp: string;
  public path: string;

  constructor(errorData: ApiErrorData) {
    super(errorData.message);
    this.name = 'ApiError';
    this.status = errorData.status;
    this.code = errorData.code;
    this.details = errorData.details;
    this.timestamp = errorData.timestamp;
    this.path = errorData.path;
  }
}

// Request options interface
export interface ApiRequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  headers?: Record<string, string>;
  body?: any;
  params?: Record<string, string | number>;
}

// Common query parameters
export interface PaginationParams {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface FilterParams {
  search?: string;
  status?: string;
  type?: string;
  startDate?: string;
  endDate?: string;
}

export type QueryParams = PaginationParams & FilterParams;

export interface AuthResponse {
  success: boolean;
  message?: string;
  user?: User;
  token?: string;
  company?: Company;
}

export interface LoginResponse {
  success: boolean;
  message?: string;
  user?: User;
  token?: string;
}

export interface RegisterResponse {
  success: boolean;
  message?: string;
  user?: User;
}

export interface UsersResponse extends ApiResponse<User[]> {}
export interface UserResponse extends ApiResponse<User> {}

export interface CompaniesResponse extends ApiResponse<Company[]> {}
export interface CompanyResponse extends ApiResponse<Company> {}

export interface TasksResponse extends ApiResponse<Task[]> {}
export interface TaskResponse extends ApiResponse<Task> {}

export interface ContentsResponse extends ApiResponse<Content[]> {}
export interface ContentResponse extends ApiResponse<Content> {}

export interface NotificationsResponse extends ApiResponse<Notification[]> {}
export interface NotificationResponse extends ApiResponse<Notification> {}

export interface ProjectsResponse extends ApiResponse<Project[]> {}
export interface ProjectResponse extends ApiResponse<Project> {}
