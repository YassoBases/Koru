// src/types/auth.types.ts
import { Company } from './company.types';
import { User, UserRole } from './user.types'; // Import the single source of truth

export interface LoginUserDto {
  email: string;
  password: string;
}

export interface RegisterUserDto {
  email: string;
  password: string;
  name: string;
  role: UserRole; // Use the consolidated UserRole enum
  companyId?: string;
  permissions: string[];
  profile?: {
    phone?: string;
    department?: string;
    position?: string;
    description?: string;
  };
}

export interface AuthResponse {
  success: boolean;
  message?: string;
  token?: string;
  user?: User;
  company?: Company;
}

export interface LoginResponse extends AuthResponse {}
export interface RegisterResponse extends AuthResponse {}

export const DEFAULT_PERMISSIONS: Record<UserRole, string[]> = {
  [UserRole.SUPERADMIN]: ['manage_all'],
  [UserRole.ADMIN]: ['manage_companies', 'manage_users', 'manage_content'],
  [UserRole.COMPANY_ADMIN]: ['manage_company_users', 'manage_company_tasks', 'access_assigned_content'],
  [UserRole.EMPLOYEE]: ['access_assigned_content', 'view_tasks'],
  [UserRole.INDIVIDUAL]: ['access_assigned_content'],
};
