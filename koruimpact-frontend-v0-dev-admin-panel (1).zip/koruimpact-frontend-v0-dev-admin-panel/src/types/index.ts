// src/types/index.ts
// Central export for all type definitions

// User types
export * from './user.types';

// Authentication types
export * from './auth.types';

// Company types
export * from './company.types';

// Task types
export * from './task.types';

// Project types
export * from './project.types';

// Content types
export * from './content.types';

// Notification types
export * from './notification.types';

// API types
export * from './api.types';

// Error types
export * from './error.types';

// Utility types
export type ID = string;
export type Timestamp = string;
export type Email = string;
export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

// Common response patterns
export interface SuccessResponse {
  success: true;
  message?: string;
}

export interface ErrorResponse {
  success: false;
  error: string;
  message: string;
}

// Pagination utility type
export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

// Filter base interface
export interface BaseFilter {
  search?: string;
  dateFrom?: string;
  dateTo?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

// Common utility types
export interface BaseEntity {
  id: string;
  createdAt: string;
  updatedAt: string;
}

export interface TimestampedEntity {
  createdAt: string;
  updatedAt: string;
}

export interface SoftDeletableEntity extends TimestampedEntity {
  deletedAt?: string;
  isDeleted: boolean;
}

// Form state types
export interface FormState<T = any> {
  data: T;
  errors: Record<string, string>;
  isSubmitting: boolean;
  isValid: boolean;
}

// Loading states
export interface LoadingState {
  isLoading: boolean;
  error?: string;
}

// Generic data state
export interface DataState<T> extends LoadingState {
  data?: T;
  lastUpdated?: string;
}

// Search and filter types
export interface SearchParams {
  query?: string;
  filters?: Record<string, any>;
  sort?: {
    field: string;
    direction: 'asc' | 'desc';
  };
  pagination?: PaginationParams;
}

// Additional types can be added here if needed

// Pagination utility type
export interface PaginationParams {
  page: number;
  limit: number;
}
