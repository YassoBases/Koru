// Content schema based on swagger-schema-content.png

// Content type enum from swagger: article, blog_post, service, therapy_info  
export enum ContentType {
  ARTICLE = 'article',
  BLOG_POST = 'blog_post',
  SERVICE = 'service', 
  THERAPY_INFO = 'therapy_info'
}

// Content schema - matches swagger exactly
export interface Content {
  id: string; // required - unique content identifier
  title: string; // required - content title
  content: string; // required - content body
  type: ContentType; // required - content type  
  authorId: string; // required - author user ID
  isPublished: boolean; // required - publication status
  tags?: string[]; // optional - content tags, example: ["psychology", "mental-health"]
  createdAt: string; // required - date-time format
  updatedAt: string; // required - date-time format  
  thumbnailUrl?: string;
}

export interface CreateContentDto {
  title: string;
  content: string;
  type: ContentType;
  authorId: string;
  isPublished: boolean;
  tags?: string[];
}

export interface UpdateContentDto {
  title?: string;
  content?: string;
  type?: ContentType;
  authorId?: string;
  isPublished?: boolean;
  tags?: string[];
}

// A single content response is the Content object itself
export type ContentResponse = Content;

// The response for a list of content is an array of Content objects.
export type ContentsResponse = Content[];