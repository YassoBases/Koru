import { Company } from '../types/company.types';
import { User } from '../types/user.types';

const TOKEN_KEY = 'jwt_token';
const USER_KEY = 'user_data';
const COMPANY_KEY = 'company_data';

class TokenService {
  getToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem(TOKEN_KEY);
    }
    return null;
  }

  getUser(): User | null {
    if (typeof window !== 'undefined') {
      const userData = localStorage.getItem(USER_KEY);
      return userData ? JSON.parse(userData) : null;
    }
    return null;
  }

  getCompany(): Company | null {
    if (typeof window !== 'undefined') {
      const companyData = localStorage.getItem(COMPANY_KEY);
      return companyData ? JSON.parse(companyData) : null;
    }
    return null;
  }

  setTokens(token: string, refreshToken: string, user: User, company?: Company): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(USER_KEY, JSON.stringify(user));
      if (company) {
        localStorage.setItem(COMPANY_KEY, JSON.stringify(company));
      } else {
        localStorage.removeItem(COMPANY_KEY);
      }
    }
  }

  clearAll(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
      localStorage.removeItem(COMPANY_KEY);
    }
  }

  isTokenExpired(token: string): boolean {
    if (!token) return true;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const exp = payload.exp; // Expiration time in seconds since epoch
      const now = Math.floor(Date.now() / 1000); // Current time in seconds since epoch
      return exp < now;
    } catch (e) {
      console.error("Error decoding token:", e);
      return true; // Treat as expired if decoding fails
    }
  }
}

export const tokenService = new TokenService();
