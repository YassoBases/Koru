// src/services/apiService.ts
import { QueryParams } from '../types/api.types';
import {
  AuthResponse,
  LoginResponse,
  LoginUserDto,
  RegisterResponse,
  RegisterUserDto,
} from '../types/auth.types';
import {
  CompanyResponse,
  CompanyUpdate,
  CreateCompanyDto
} from '../types/company.types';
import { ContentResponse, ContentsResponse, CreateContentDto, UpdateContentDto } from '../types/content.types';
import { ApiError } from '../types/error.types';
import { CreateTaskDto, TaskResponse, TasksResponse, UpdateTaskDto } from '../types/task.types';
import { CreateUserDto, UpdateUserDto, User, UserResponse, UsersResponse } from '../types/user.types';
import { tokenService } from './tokenService';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000/api';

class ApiService {
  private async request<T>(
    endpoint: string,
    options: RequestInit = {},
    requiresAuth: boolean = true
  ): Promise<T> {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (requiresAuth) {
      const token = tokenService.getToken();
      if (!token) {
        throw new ApiError('Authentication token is missing.', 'AUTH_REQUIRED');
      }
      if (tokenService.isTokenExpired(token)) {
        throw new ApiError('Authentication token has expired.', 'TOKEN_EXPIRED');
      }
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
      // This is the key change: it prevents Next.js and the browser from caching API responses.
      cache: 'no-store', 
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));

      if (errorData.errors && Array.isArray(errorData.errors) && errorData.errors.length > 0) {
        const firstError = errorData.errors[0];
        const validationMessage = `Validation Error: ${firstError.msg} for field '${firstError.path}'.`;
        throw new ApiError(validationMessage, 'VALIDATION_ERROR', errorData.errors);
      }

      const errorMessage = errorData.message || errorData.error || response.statusText || 'An unknown error occurred';
      const errorCode = errorData.code || 'HTTP_ERROR';
      throw new ApiError(errorMessage, errorCode, errorData.details);
    }

    if (response.status === 204 || response.headers.get('content-length') === '0') {
      return {} as T;
    }

    return response.json();
  }

  // Auth endpoints
  auth = {
    login: async (credentials: LoginUserDto): Promise<LoginResponse> => {
      const responseData = await this.request<any>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      }, false);

      if (responseData && responseData.token && responseData.uid) {
        const user: User = {
          uid: responseData.uid,
          email: responseData.email,
          displayName: responseData.name,
          role: responseData.role,
          isActive: responseData.status === 'active',
          permissions: responseData.permissions || [],
          profile: responseData.profile || {},
          createdAt: responseData.createdAt || new Date().toISOString(),
          updatedAt: responseData.updatedAt || new Date().toISOString(),
          companyId: responseData.companyId,
          company: responseData.company,
        };

        const company = responseData.company || null;
        
        tokenService.setTokens(responseData.token, '', user, company);

        return {
          success: true,
          user,
          token: responseData.token,
          company,
        };
      }

      return {
        success: false,
        message: responseData.message || 'Login failed due to unexpected response from server.',
      };
    },
    register: async (userData: RegisterUserDto): Promise<RegisterResponse> => {
      const responseBody = await this.request<Partial<AuthResponse>>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData),
      }, false);

      return {
        success: true,
        user: responseBody.user,
        token: responseBody.token,
        company: responseBody.company,
        message: responseBody.message || "Registration successful",
      };
    },
  };

  // User endpoints
  users = {
    getAll: async (params?: QueryParams): Promise<UsersResponse> =>
      this.request<UsersResponse>(`/superadmin/users${params ? `?${new URLSearchParams(params as any)}` : ''}`),
    getById: async (uid: string): Promise<UserResponse> =>
      this.request<UserResponse>(`/superadmin/users/${uid}`),
    create: async (userData: CreateUserDto): Promise<UserResponse> =>
      this.request<UserResponse>('/superadmin/users', {
        method: 'POST',
        body: JSON.stringify(userData),
      }),
    update: async (uid: string, updateData: UpdateUserDto): Promise<UserResponse> =>
      this.request<UserResponse>(`/superadmin/users/${uid}`, {
        method: 'PUT',
        body: JSON.stringify(updateData),
      }),
    delete: async (uid: string): Promise<void> =>
      this.request<void>(`/superadmin/users/${uid}`, { method: 'DELETE' }),
  };

  // Company endpoints
  companies = {
     create: async (companyData: CreateCompanyDto): Promise<CompanyResponse> =>
      this.request<CompanyResponse>('/companies', {
        method: 'POST',
        body: JSON.stringify(companyData),
      }),
    getById: async (companyId: string): Promise<CompanyResponse> =>
      this.request<CompanyResponse>(`/companies/${companyId}`),
    update: async (companyId: string, updateData: CompanyUpdate): Promise<CompanyResponse> =>
      this.request<CompanyResponse>(`/companies/${companyId}`, {
        method: 'PUT',
        body: JSON.stringify(updateData),
      }),
    delete: async (companyId: string): Promise<void> =>
      this.request<void>(`/companies/${companyId}`, { method: 'DELETE' }),
    addAdmin: async (companyId: string, userId: { userId: string }): Promise<void> =>
      this.request<void>(`/companies/${companyId}/admins`, {
        method: 'POST',
        body: JSON.stringify(userId),
      }),
    removeAdmin: async (companyId: string, userId: string): Promise<void> =>
      this.request<void>(`/companies/${companyId}/admins/${userId}`, { method: 'DELETE' }),
  };
  
  // Task endpoints
  tasks = {
    create: async (taskData: CreateTaskDto): Promise<TaskResponse> =>
      this.request<TaskResponse>('/admin/tasks', {
        method: 'POST',
        body: JSON.stringify(taskData),
      }),
    getAll: async (params?: QueryParams): Promise<TasksResponse> =>
      this.request<TasksResponse>(`/admin/tasks${params ? `?${new URLSearchParams(params as any)}` : ''}`),
    update: async (taskId: string, updateData: UpdateTaskDto): Promise<TaskResponse> =>
      this.request<TaskResponse>(`/admin/tasks/${taskId}`, {
        method: 'PUT',
        body: JSON.stringify(updateData),
      }),
    delete: async (taskId: string): Promise<void> =>
      this.request<void>(`/admin/tasks/${taskId}`, { method: 'DELETE' }),
  };

  // Content endpoints
  content = {
    create: async (contentData: CreateContentDto): Promise<ContentResponse> =>
      this.request<ContentResponse>('/content', {
        method: 'POST',
        body: JSON.stringify(contentData),
      }),
    getAdminContent: async (params?: QueryParams): Promise<ContentsResponse> =>
      this.request<ContentsResponse>(`/content/admin${params ? `?${new URLSearchParams(params as any)}` : ''}`),
    getPublishedContent: async (params?: QueryParams): Promise<ContentsResponse> =>
      this.request<ContentsResponse>(`/content/published${params ? `?${new URLSearchParams(params as any)}` : ''}`, {}, false),
    getById: async (id: string): Promise<ContentResponse> =>
      this.request<ContentResponse>(`/content/${id}`, {}, false),
    update: async (id: string, updateData: UpdateContentDto): Promise<ContentResponse> =>
      this.request<ContentResponse>(`/content/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updateData),
      }),
    delete: async (id: string): Promise<void> =>
      this.request<void>(`/content/${id}`, { method: 'DELETE' }),
  };
}

export const apiService = new ApiService();