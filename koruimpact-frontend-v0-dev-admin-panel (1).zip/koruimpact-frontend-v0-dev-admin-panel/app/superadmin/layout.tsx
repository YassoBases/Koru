import { AdminHeader } from "@/components/admin/AdminHeader"
import { SuperadminSidebar } from "@/components/admin/SuperadminSidebar"
import { ProtectedRoute } from "@/components/auth/ProtectedRoute"
import { UserRole } from "@/src/types"

export default function SuperadminLayout({ children }: { children: React.ReactNode }) {
  return (
    <ProtectedRoute allowedRoles={[UserRole.SUPERADMIN]}>
      <div className="grid min-h-screen w-full lg:grid-cols-[280px_1fr]">
        <SuperadminSidebar />
        <div className="flex flex-col">
          <AdminHeader />
          <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6 bg-gray-50">
            {children}
          </main>
        </div>
      </div>
    </ProtectedRoute>
  )
}