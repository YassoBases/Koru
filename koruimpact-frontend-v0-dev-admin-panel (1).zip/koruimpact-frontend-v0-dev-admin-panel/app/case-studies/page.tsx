import { Navigation } from "@/components/Navigation"
import { Footer } from "@/components/Footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, TrendingUp, Users, Target, CheckCircle } from "lucide-react"
import Link from "next/link"

export default function CaseStudiesPage() {
  const caseStudies = [
    {
      id: 1,
      title: "Transforming Team Dynamics at Global Tech Company",
      industry: "Technology",
      challenge: "Low psychological safety scores",
      quantitativeFindings: "Team alignment scored 4.2/10 in initial survey",
      qualitativeInsights: "Interviews revealed defensive silence due to high power distance culture",
      triangulatedInsight: "Real issue was absence of psychological safety, not alignment",
      intervention: "Leadership coaching focused on inclusive decision-making",
      results: "45% reduction in project rework, measurable increase in employee-led innovation",
      timeline: "6 months",
      teamSize: "250+ employees",
    },
    {
      id: 2,
      title: "Cultural Transformation in Financial Services",
      industry: "Financial Services",
      challenge: "High burnout rates and turnover",
      quantitativeFindings: "Burnout scores at 7.8/10, well above industry average",
      qualitativeInsights: "Focus groups uncovered systemic overwork culture and unclear boundaries",
      triangulatedInsight: "Burnout was symptom of poor resource allocation and unrealistic expectations",
      intervention: "Workload redesign and leadership accountability systems",
      results: "32% reduction in turnover, 60% improvement in work-life balance scores",
      timeline: "8 months",
      teamSize: "180 employees",
    },
    {
      id: 3,
      title: "Change Management Success in Manufacturing",
      industry: "Manufacturing",
      challenge: "Resistance to digital transformation",
      quantitativeFindings: "Change readiness scored 3.5/10 across all departments",
      qualitativeInsights: "Interviews revealed fear of job loss and lack of digital skills confidence",
      triangulatedInsight: "Resistance rooted in fear and capability gaps, not attitude",
      intervention: "Comprehensive reskilling program with job security guarantees",
      results: "85% successful adoption of new systems, 40% increase in productivity",
      timeline: "12 months",
      teamSize: "320 employees",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-100">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 font-heading">
                Evidence-First Success Stories
              </h1>
              <p className="text-xl text-gray-700 mb-8 font-body leading-relaxed">
                See how methodological triangulation leads to breakthrough insights and transformational results. Each
                case study demonstrates the power of validated evidence over single-source assumptions.
              </p>
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                Validated Results Through Triangulated Research
              </Badge>
            </div>
          </div>
        </section>

        {/* Case Studies */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="max-w-6xl mx-auto">
              <div className="space-y-16">
                {caseStudies.map((study, index) => (
                  <Card key={study.id} className="border-2 border-gray-100 hover:border-blue-200 transition-colors">
                    <CardHeader>
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                        <div>
                          <Badge className="mb-2 bg-gray-100 text-gray-800 hover:bg-gray-100">{study.industry}</Badge>
                          <CardTitle className="text-2xl font-heading">{study.title}</CardTitle>
                        </div>
                        <div className="flex space-x-4 text-sm text-gray-600 font-body">
                          <div className="flex items-center">
                            <Users className="w-4 h-4 mr-1" />
                            {study.teamSize}
                          </div>
                          <div className="flex items-center">
                            <Target className="w-4 h-4 mr-1" />
                            {study.timeline}
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-8">
                        {/* Left Column - The Journey */}
                        <div className="space-y-6">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-3 font-heading flex items-center">
                              <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center mr-2">
                                <span className="text-red-600 text-sm font-bold">1</span>
                              </div>
                              The Initial Challenge
                            </h3>
                            <p className="text-gray-700 font-body">{study.challenge}</p>
                          </div>

                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-3 font-heading flex items-center">
                              <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-2">
                                <span className="text-blue-600 text-sm font-bold">2</span>
                              </div>
                              The Initial Hypothesis
                            </h3>
                            <div className="bg-blue-50 p-4 rounded-lg">
                              <p className="text-blue-800 font-body">
                                <strong>Quantitative Finding:</strong> {study.quantitativeFindings}
                              </p>
                            </div>
                          </div>

                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-3 font-heading flex items-center">
                              <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mr-2">
                                <span className="text-green-600 text-sm font-bold">3</span>
                              </div>
                              The Validating Evidence
                            </h3>
                            <div className="bg-green-50 p-4 rounded-lg">
                              <p className="text-green-800 font-body">
                                <strong>Qualitative Insights:</strong> {study.qualitativeInsights}
                              </p>
                            </div>
                          </div>

                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-3 font-heading flex items-center">
                              <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center mr-2">
                                <span className="text-purple-600 text-sm font-bold">4</span>
                              </div>
                              The Triangulated Insight
                            </h3>
                            <div className="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-400">
                              <p className="text-purple-800 font-body font-semibold">{study.triangulatedInsight}</p>
                            </div>
                          </div>
                        </div>

                        {/* Right Column - Results */}
                        <div className="space-y-6">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-3 font-heading flex items-center">
                              <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center mr-2">
                                <span className="text-orange-600 text-sm font-bold">5</span>
                              </div>
                              The Targeted Intervention
                            </h3>
                            <p className="text-gray-700 font-body">{study.intervention}</p>
                          </div>

                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-3 font-heading flex items-center">
                              <TrendingUp className="w-5 h-5 text-green-600 mr-2" />
                              The Results
                            </h3>
                            <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                              <p className="text-green-800 font-body text-lg font-semibold mb-4">{study.results}</p>
                              <div className="flex items-center text-green-700">
                                <CheckCircle className="w-5 h-5 mr-2" />
                                <span className="font-body">Validated through post-intervention measurement</span>
                              </div>
                            </div>
                          </div>

                          <div className="bg-gray-50 p-6 rounded-lg">
                            <h4 className="font-semibold text-gray-900 mb-3 font-heading">Why This Approach Worked</h4>
                            <p className="text-gray-700 font-body text-sm">
                              By combining quantitative data with qualitative validation, we uncovered the real drivers
                              behind the surface-level symptoms. This triangulated approach enabled a targeted
                              intervention that addressed root causes rather than just symptoms.
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Methodology Highlight */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-6 font-heading">
                The Power of Methodological Triangulation
              </h2>
              <p className="text-xl text-gray-700 mb-8 font-body">
                Each success story demonstrates how our evidence-first approach uncovers insights that single-source
                data would miss.
              </p>

              <div className="grid md:grid-cols-3 gap-8 mb-12">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-blue-600">1</span>
                  </div>
                  <h3 className="text-lg font-semibold mb-2 font-heading">Quantitative Hypothesis</h3>
                  <p className="text-gray-600 font-body">Initial data reveals patterns and potential issues</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-green-600">2</span>
                  </div>
                  <h3 className="text-lg font-semibold mb-2 font-heading">Qualitative Validation</h3>
                  <p className="text-gray-600 font-body">Deep exploration uncovers the "why" behind the data</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-purple-600">3</span>
                  </div>
                  <h3 className="text-lg font-semibold mb-2 font-heading">Triangulated Insight</h3>
                  <p className="text-gray-600 font-body">Validated evidence leads to targeted solutions</p>
                </div>
              </div>

              <Link href="/our-approach/methodology" passHref>
                <Button
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg font-semibold font-heading"
                >
                  Learn About Our Methodology
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-blue-600 to-indigo-700">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-heading">
                Ready to Write Your Success Story?
              </h2>
              <p className="text-xl text-blue-100 mb-8 font-body">
                Let's discuss how our evidence-first approach can uncover the insights your organization needs to
                thrive.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/our-approach/organizational-audit" passHref>
                  <Button
                    size="lg"
                    className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold font-heading"
                  >
                    Start Your Organizational Audit
                  </Button>
                </Link>
                <Link href="/contact" passHref>
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 text-lg font-semibold font-heading bg-transparent"
                  >
                    Schedule a Discovery Call
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
