"use client"

import { LoadingSpinner } from "@/components/LoadingSpinner"
import { CreateTaskForm } from "@/components/tasks/CreateTaskForm"
import { EditTaskForm } from "@/components/tasks/EditTaskForm"
import { TaskList } from "@/components/tasks/TaskList"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { useAuth } from "@/contexts/AuthContext"
import { Task } from "@/src/types/task.types"; // Corrected import path
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"

// --- MOCK DATA SECTION ---
// Keep this here for now. This is what you will remove when the backend is ready.
const mockTasks: Record<string, Task[]> = {
  "company_1": [
    { id: "task_1", title: "Review Q4 Financials", description: "Analyze Q4 performance and prepare report.", status: "in_progress", assignedTo: "user_admin_1", assignedBy: "user_admin_1", priority: "high", dueDate: "2024-12-31", createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
    { id: "task_2", title: "Plan 2025 Marketing Strategy", description: "Develop comprehensive marketing plan for next year.", status: "pending", assignedTo: "user_member_1", assignedBy: "user_admin_1", priority: "medium", dueDate: "2024-11-15", createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
    { id: "task_3", title: "Update Employee Handbook", description: "Incorporate new HR policies and benefits.", status: "completed", assignedTo: "user_admin_1", assignedBy: "user_admin_1", priority: "low", dueDate: "2024-09-30", createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  ],
};
// --- END MOCK DATA SECTION ---


export default function CompanyTasksPage({ params }: { params: { companyId: string } }) {
  const { user, loading: authLoading } = useAuth()
  const router = useRouter()
  const [tasks, setTasks] = useState<Task[]>([])
  const [isLoading, setIsLoading] = useState(true);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)

  useEffect(() => {
    if (!authLoading) {
      if (!user || (user.role !== 'admin' && user.role !== 'company_admin' && user.role !== 'employee') || user.companyId !== params.companyId) {
        router.push("/login");
      } else {
        fetchTasks();
      }
    }
  }, [user, authLoading, router, params.companyId]);

  const fetchTasks = async () => {
    setIsLoading(true);
    try {
      // **THIS IS THE KEY CHANGE**
      // When your backend is ready, you will replace the line below...
      const companyTasks = mockTasks[params.companyId] || []; // Using mock data for now
      
      // ...with this line:
      // const response = await apiService.tasks.getAll({ companyId: params.companyId });
      // const companyTasks = response.data;

      setTasks(companyTasks);
    } catch (error) {
      console.error("Failed to fetch tasks:", error);
      // Handle error (e.g., show a toast message)
    } finally {
      setIsLoading(false);
    }
  };


  const handleCreateTask = (newTask: Task) => {
    // This function will now optimistically update the UI.
    // The actual creation happens in the form, and then we refetch.
    setTasks((prev) => [...prev, newTask]);
    setIsCreateDialogOpen(false);
    fetchTasks(); // Refetch to ensure data is in sync
  }

  const handleUpdateTask = (updatedTask: Task) => {
    setTasks((prev) => prev.map((task) => (task.id === updatedTask.id ? updatedTask : task)))
    setIsEditDialogOpen(false)
    setSelectedTask(null)
    fetchTasks(); // Refetch to ensure data is in sync
  }

  const handleDeleteTask = async (taskId: string) => {
    try {
        // In a real app, you'd call the API here:
        // await apiService.tasks.delete(taskId);
        setTasks((prev) => prev.filter((task) => task.id !== taskId));
        // For mock data, we also remove it from the source
        if (mockTasks[params.companyId]) {
            mockTasks[params.companyId] = mockTasks[params.companyId].filter(t => t.id !== taskId);
        }
    } catch (error) {
        console.error("Failed to delete task:", error);
    }
  }


  const openEditDialog = (task: Task) => {
    setSelectedTask(task)
    setIsEditDialogOpen(true)
  }

  if (authLoading || isLoading) {
    return <LoadingSpinner />
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <h1 className="text-3xl font-bold">Tasks for your Company</h1>
      <p className="text-lg text-muted-foreground">
        Manage all tasks and projects for your organization.
      </p>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle>All Tasks</CardTitle>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>Create New Task</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
              </DialogHeader>
              <CreateTaskForm onCreate={handleCreateTask} />
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <TaskList tasks={tasks} onEdit={openEditDialog} onDelete={handleDeleteTask} />
        </CardContent>
      </Card>

      {selectedTask && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Edit Task</DialogTitle>
            </DialogHeader>
            <EditTaskForm task={selectedTask} onUpdate={handleUpdateTask} />
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}