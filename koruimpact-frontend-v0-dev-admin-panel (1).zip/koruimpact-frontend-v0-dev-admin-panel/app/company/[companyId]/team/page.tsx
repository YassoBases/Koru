"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { TeamManagement } from "@/components/team/TeamManagement"
import { InviteAdminForm } from "@/components/team/InviteAdminForm"
import { useAuth } from "@/contexts/AuthContext"
import { useRouter } from "next/navigation"
import { LoadingSpinner } from "@/components/LoadingSpinner"

// Mock User Type (simplified for team management)
interface TeamMember {
  id: string
  email: string
  role: "admin" | "member"
}

// Mock Team Data (per company)
const mockTeamMembers: Record<string, TeamMember[]> = {
  "company_1": [
    { id: "user_admin_1", email: "admin@example.com", role: "admin" },
    { id: "user_member_1", email: "member@example.com", role: "member" },
    { id: "user_member_2", email: "jane.doe@example.com", role: "member" },
  ],
  // Add more mock companies and their teams as needed
}

export default function CompanyTeamPage({ params }: { params: { companyId: string } }) {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([])
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false)

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin" || user.companyId !== params.companyId)) {
      router.push("/login") // Redirect if not an admin or not authorized for this company
    } else if (!loading && user && user.companyId === params.companyId) {
      // Simulate fetching team members for the company
      setTeamMembers(mockTeamMembers[params.companyId] || [])
    }
  }, [user, loading, router, params.companyId])

  const handleInviteAdmin = (email: string) => {
    // Simulate inviting a new admin/member
    const newMember: TeamMember = { id: `user_${Date.now()}`, email, role: "member" } // Default to member for simplicity
    setTeamMembers((prev) => [...prev, newMember])
    if (!mockTeamMembers[params.companyId]) {
      mockTeamMembers[params.companyId] = []
    }
    mockTeamMembers[params.companyId].push(newMember) // Update mock data
    setIsInviteDialogOpen(false)
    // In a real app, send an actual invitation
  }

  const handleRemoveMember = (memberId: string) => {
    setTeamMembers((prev) => prev.filter((member) => member.id !== memberId))
    if (mockTeamMembers[params.companyId]) {
      mockTeamMembers[params.companyId] = mockTeamMembers[params.companyId].filter(m => m.id !== memberId)
    }
  }

  if (loading) {
    return <LoadingSpinner />
  }

  if (!user || user.role !== "admin" || user.companyId !== params.companyId) {
    return null // Should redirect by useEffect
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <h1 className="text-3xl font-bold">Team Management for Company {params.companyId}</h1>
      <p className="text-lg text-muted-foreground">
        Add, remove, and manage roles for your company's team members.
      </p>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle>Team Members</CardTitle>
          <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
            <DialogTrigger asChild>
              <Button>Invite New Member</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Invite New Member</DialogTitle>
              </DialogHeader>
              <InviteAdminForm onInvite={handleInviteAdmin} />
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <TeamManagement members={teamMembers} onRemove={handleRemoveMember} />
        </CardContent>
      </Card>
    </div>
  )
}
