import { CompanyAdminDashboard } from "@/components/company/CompanyAdminDashboard"
import { MemberDashboard } from "@/components/member/MemberDashboard"
import { useAuth } from "@/contexts/AuthContext"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { LoadingSpinner } from "@/components/LoadingSpinner"

export default function CompanyDashboardPage({ params }: { params: { companyId: string } }) {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && (!user || user.companyId !== params.companyId)) {
      router.push("/login") // Redirect if not authenticated or not part of this company
    }
  }, [user, loading, router, params.companyId])

  if (loading) {
    return <LoadingSpinner />
  }

  if (!user || user.companyId !== params.companyId) {
    return null // Should redirect by useEffect
  }

  if (user.role === "admin") {
    return <CompanyAdminDashboard companyId={params.companyId} />
  } else if (user.role === "member") {
    return <MemberDashboard />
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] p-4">
      <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
      <p className="text-muted-foreground text-center">
        You do not have permission to view this company dashboard.
      </p>
    </div>
  )
}
