"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/AuthContext"
import { useEffect } from "react"

export default function MemberHubPage({ params }: { params: { companyId: string } }) {
  const router = useRouter()
  const { user, loading } = useAuth()

  useEffect(() => {
    if (!loading && (!user || (user.role !== "admin" && user.role !== "member") || user.companyId !== params.companyId)) {
      router.push("/login") // Redirect if not authorized for this company
    }
  }, [user, loading, router, params.companyId])

  if (loading) {
    return <div>Loading member hub...</div>
  }

  if (!user || (user.role !== "admin" && user.role !== "member") || user.companyId !== params.companyId) {
    return null // Should redirect by useEffect
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <h1 className="text-3xl font-bold">Member Hub for Company {params.companyId}</h1>
      <p className="text-lg text-muted-foreground">
        Welcome to your company's dedicated portal. Here you can access resources, manage tasks, and collaborate with your team.
      </p>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>My Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">View and manage your assigned tasks and project deadlines.</p>
            <Button onClick={() => router.push(`/company/${params.companyId}/tasks`)}>Go to Tasks</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Team Collaboration</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">Connect with your team members and manage team settings.</p>
            <Button onClick={() => router.push(`/company/${params.companyId}/team`)}>Manage Team</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Company Resources</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">Access shared documents, guides, and company policies.</p>
            <Button>View Resources</Button> {/* Placeholder for actual resource page */}
          </CardContent>
        </Card>

        {user.role === "admin" && (
          <Card>
            <CardHeader>
              <CardTitle>Admin Dashboard</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">Access administrative tools for company management.</p>
              <Button onClick={() => router.push(`/company/${params.companyId}/dashboard`)}>Go to Admin Dashboard</Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
