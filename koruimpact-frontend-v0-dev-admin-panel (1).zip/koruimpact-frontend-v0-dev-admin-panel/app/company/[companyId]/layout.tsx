"use client"

import { CompanySidebar } from "@/components/company/CompanySidebar"
import { ProtectedRoute } from "@/components/auth/ProtectedRoute"
import { Header } from "@/components/Header" // Corrected import path

export default function CompanyLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: { companyId: string }
}) {
  return (
    <ProtectedRoute allowedRoles={["Admin", "Member"]} companyId={params.companyId}>
      <div className="grid min-h-screen w-full lg:grid-cols-[280px_1fr]">
        <CompanySidebar />
        <div className="flex flex-col">
          <Header />
          <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
            {children}
          </main>
        </div>
      </div>
    </ProtectedRoute>
  )
}
