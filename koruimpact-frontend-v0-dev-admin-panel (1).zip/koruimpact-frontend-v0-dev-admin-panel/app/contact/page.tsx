"use client"

import { Navigation } from "@/components/Navigation"
import { Footer } from "@/components/Footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Mail, Phone, MapPin, Calendar, Users, MessageCircle, ArrowRight, Send, Linkedin, Youtube } from "lucide-react"
import { ProgressiveContactForm } from "@/components/ProgressiveContactForm"

export default function ContactPage() {
  const contactMethods = [
    {
      icon: Mail,
      title: "Email Us",
      primary: "hello@koruimpact.org",
      secondary: "We respond within 24 hours",
      description:
        "For general inquiries, partnership opportunities, and detailed project discussions. Our team carefully reviews each message and provides personalized responses with relevant resources and next steps. Perfect for sharing detailed project requirements, scheduling consultations, or exploring collaboration opportunities.",
      gradient: "from-koru-blue-500 to-koru-blue-400",
      cta: "Send Email",
      action: () => window.open("mailto:hello@koruimpact.org", "_blank"),
    },
    {
      icon: Phone,
      title: "Schedule a Call",
      primary: "+90 (555) 123-4567",
      secondary: "Monday - Friday, 9AM - 6PM CET",
      description:
        "Direct consultation for urgent matters and in-depth project planning. Speak directly with our experts to discuss your organizational challenges, explore tailored solutions, and get immediate answers to your questions. Ideal for complex projects requiring detailed discussion and strategic planning.",
      gradient: "from-koru-green-400 to-koru-green-500",
      cta: "Book Call",
      action: () => window.open("tel:+905551234567", "_blank"),
    },
    {
      icon: MapPin,
      title: "Our Location",
      primary: "Istanbul, Turkey",
      secondary: "Serving organizations globally",
      description:
        "Headquartered in Istanbul with remote capabilities worldwide. While we're based in Turkey, we work with organizations across different time zones and cultures. Our global perspective and local expertise allow us to provide culturally-sensitive solutions that work in diverse organizational contexts.",
      gradient: "from-koru-blue-400 to-koru-green-400",
      cta: "View Map",
      action: () => window.open("https://maps.google.com/?q=Istanbul,Turkey", "_blank"),
    },
    {
      icon: Calendar,
      title: "Free Consultation",
      primary: "30-minute strategy session",
      secondary: "No commitment required",
      description:
        "Discuss your organizational challenges and explore potential solutions in a no-pressure environment. During this session, we'll assess your needs, share relevant insights from our research, and outline potential approaches. This is your opportunity to experience our expertise firsthand and determine if we're the right fit for your organization.",
      gradient: "from-koru-green-500 to-koru-green-600",
      cta: "Schedule Now",
      action: () => window.open("https://calendly.com/koruimpact/consultation", "_blank"),
    },
  ]

  const inquiryTypes = [
    {
      title: "Psychological Safety Diagnostic",
      description: "Comprehensive assessment of team psychological safety levels",
      icon: Users,
    },
    {
      title: "Burnout Prevention & Recovery",
      description: "Evidence-based burnout prevention and recovery programs",
      icon: MessageCircle,
    },
    {
      title: "Culture Assessment",
      description: "Deep dive into organizational culture and dynamics",
      icon: Users,
    },
    {
      title: "Leadership Development",
      description: "Develop leaders who create psychologically safe environments",
      icon: Users,
    },
    {
      title: "Change Management",
      description: "Navigate organizational change with evidence-based strategies",
      icon: MessageCircle,
    },
    {
      title: "The Lighthouse Project",
      description: "Research partnership opportunities for SMEs",
      icon: Calendar,
    },
    {
      title: "Custom Consultation",
      description: "Tailored organizational wellness and culture transformation",
      icon: MessageCircle,
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="pt-16">
        {/* Hero Section with Aurora Gradient */}
        <section className="py-20 bg-gradient-to-br from-koru-blue-500 via-koru-green-400 to-koru-blue-400 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-koru-green-600/20 via-transparent to-koru-blue-600/20"></div>
          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 font-heading">Get in Touch</h1>
              <p className="text-xl md:text-2xl mb-8 text-white/95 leading-relaxed font-body">
                Ready to transform your organization? Let's discuss how we can help you create the
                <span className="font-semibold text-koru-gold-200"> psychological blueprint</span> for flourishing.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                <a href="https://calendly.com/koruimpact/consultation" target="_blank" rel="noopener noreferrer">
                  <Button
                    size="lg"
                    className="bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur-sm px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105 shadow-lg font-heading"
                  >
                    <Calendar className="w-5 h-5 mr-2" />
                    Schedule Free Consultation
                  </Button>
                </a>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white hover:text-koru-green-600 px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105 bg-transparent font-heading"
                  onClick={() =>
                    document.getElementById("progressive-contact-form")?.scrollIntoView({ behavior: "smooth" })
                  }
                >
                  <Send className="w-5 h-5 mr-2" />
                  Send Message
                </Button>
              </div>

              {/* Social Media Links */}
              <div className="flex items-center justify-center space-x-6">
                <span className="text-white/80 font-body">Follow us:</span>
                <a
                  href="https://www.linkedin.com/company/koru-impact/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 text-white/80 hover:text-white transition-colors duration-300 hover:scale-110"
                >
                  <Linkedin className="w-6 h-6" />
                  <span className="font-body">LinkedIn</span>
                </a>
                <a
                  href="https://www.youtube.com/@koruimpact"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 text-white/80 hover:text-white transition-colors duration-300 hover:scale-110"
                >
                  <Youtube className="w-6 h-6" />
                  <span className="font-body">YouTube</span>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Methods Grid */}
        <section className="py-20 bg-gradient-to-br from-koru-blue-50 via-white to-koru-green-50">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6 font-heading">
                Multiple Ways to Connect
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed font-body">
                Choose the communication method that works best for you. We're committed to responding promptly and
                providing the support you need.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
              {contactMethods.map((method, index) => {
                const IconComponent = method.icon
                return (
                  <Card
                    key={index}
                    className="bg-white/90 backdrop-blur-sm shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 border border-white/50 text-center flex flex-col h-full group"
                  >
                    <CardHeader>
                      <div
                        className={`w-16 h-16 bg-gradient-to-r ${method.gradient} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}
                      >
                        <IconComponent className="w-8 h-8 text-white" />
                      </div>
                      <CardTitle className="text-xl font-bold font-heading">{method.title}</CardTitle>
                      <div className="space-y-1">
                        <p className="text-lg font-semibold text-gray-800 font-body">{method.primary}</p>
                        <p className="text-sm text-gray-500 font-body">{method.secondary}</p>
                      </div>
                    </CardHeader>
                    <CardContent className="flex-1 flex flex-col justify-between">
                      <p className="text-gray-600 text-sm leading-relaxed mb-6 font-body">{method.description}</p>
                      <div className="mt-auto pt-4">
                        <Button
                          className={`w-full bg-gradient-to-r ${method.gradient} hover:opacity-90 text-white font-heading font-semibold transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl`}
                          size="sm"
                          onClick={method.action}
                        >
                          {method.cta}
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        </section>

        {/* Service Areas Quick Reference */}
        <section className="py-20 bg-gradient-to-br from-gray-50 to-koru-blue-50">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6 font-heading">
                  What Can We Help You With?
                </h2>
                <p className="text-lg text-gray-600 font-body">
                  Quick reference guide to our main service areas and expertise.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {inquiryTypes.map((type, index) => {
                  const IconComponent = type.icon
                  return (
                    <Card
                      key={index}
                      className="bg-white/90 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 border border-white/50 group"
                    >
                      <CardContent className="p-6 flex items-start space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-koru-blue-500 to-koru-green-400 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
                          <IconComponent className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-800 mb-2 font-heading">{type.title}</h3>
                          <p className="text-gray-600 text-sm font-body">{type.description}</p>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>
          </div>
        </section>

        {/* Progressive Contact Form */}
        <section id="progressive-contact-form" className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6 font-heading">Send us a message</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed font-body">
                We'll guide you through a few quick questions to better understand your needs and provide a personalized
                response.
              </p>
            </div>

            <ProgressiveContactForm />
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
