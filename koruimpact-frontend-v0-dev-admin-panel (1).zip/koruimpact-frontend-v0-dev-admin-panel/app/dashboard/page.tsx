"use client"

import { IndividualDashboard } from "@/components/individual/IndividualDashboard"
import { LoadingSpinner } from "@/components/LoadingSpinner"
import { useAuth } from "@/contexts/AuthContext"
import { UserRole } from "@/src/types"
import { useRouter } from "next/navigation"
import { useEffect } from "react"

export default function DashboardPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login") // Redirect to login if not authenticated
    } else if (!loading && user) {
      // Redirect users based on their role to the appropriate dashboard
      switch (user.role) {
        case UserRole.ADMIN:
        case UserRole.SUPERADMIN:
          router.push("/admin");
          break;
        case UserRole.COMPANY_ADMIN:
          if (user.companyId) {
            router.push(`/company/${user.companyId}/dashboard`);
          } else {
            router.push("/company/create");
          }
          break;
        case UserRole.EMPLOYEE:
           if (user.companyId) {
            router.push(`/company/${user.companyId}/dashboard`);
          } else {
            // Handle case where an employee has no companyId, maybe redirect to an error page or login
            router.push("/login");
          }
          break;
        // For 'individual', we let them stay on this page to see the IndividualDashboard
        case UserRole.INDIVIDUAL:
          break;
        default:
          // Fallback for any other roles
          router.push("/");
          break;
      }
    }
  }, [user, loading, router])

  if (loading || !user) {
    return <LoadingSpinner />
  }

  // Only render IndividualDashboard if the user is an individual
  if (user.role === UserRole.INDIVIDUAL) {
    return <IndividualDashboard />
  }

  // For other roles that are being redirected, show a loading state
  return <LoadingSpinner />;
}