import { Navigation } from "@/components/Navigation"
import { Footer } from "@/components/Footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Users, Target, TrendingUp, Shield, Award, ArrowRight } from "lucide-react"

export default function LighthouseProjectPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-indigo-50 to-purple-100">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto text-center">
              <Badge className="mb-4 bg-purple-100 text-purple-800 hover:bg-purple-100">
                Flagship Research Initiative
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 font-heading">The Lighthouse Project</h1>
              <p className="text-xl text-gray-700 mb-8 font-body leading-relaxed">
                An exclusive research partnership program for organizations committed to evidence-based transformation.
                Available only to clients who have successfully completed our comprehensive Organizational Audit.
              </p>
              <div className="flex justify-center items-center space-x-8 text-sm text-gray-600 font-body">
                <div className="flex items-center">
                  <Shield className="w-5 h-5 text-green-600 mr-2" />
                  <span>Invitation Only</span>
                </div>
                <div className="flex items-center">
                  <Award className="w-5 h-5 text-purple-600 mr-2" />
                  <span>Research Partnership</span>
                </div>
                <div className="flex items-center">
                  <TrendingUp className="w-5 h-5 text-blue-600 mr-2" />
                  <span>Validated Results</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* What Makes It Exclusive */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto">
              <div className="bg-purple-50 border-l-4 border-purple-400 p-6 mb-12">
                <h3 className="text-lg font-semibold text-purple-800 mb-2 font-heading">
                  Why The Lighthouse Project is Invitation-Only
                </h3>
                <p className="text-purple-700 font-body">
                  This program is available exclusively to organizations that have successfully completed our
                  Organizational Audit and passed through the "Validation Gate." This ensures we're working with
                  validated evidence and aligned expectations before embarking on transformational change.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Program Overview */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6 font-heading">
                  A Research Partnership, Not Just Consulting
                </h2>
                <p className="text-xl text-gray-700 max-w-3xl mx-auto font-body">
                  The Lighthouse Project transforms your organization while contributing to the broader scientific
                  understanding of organizational change.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-6 font-heading">What Makes This Different</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 font-heading">Evidence-Based Foundation</h4>
                        <p className="text-gray-700 font-body">
                          Built on validated findings from your completed Organizational Audit, ensuring interventions
                          target real issues, not assumptions.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 font-heading">Continuous Measurement</h4>
                        <p className="text-gray-700 font-body">
                          Real-time tracking of transformation progress using the same triangulated methodology that
                          revealed your baseline reality.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 font-heading">Scientific Contribution</h4>
                        <p className="text-gray-700 font-body">
                          Your transformation journey contributes to peer-reviewed research, advancing the field of
                          organizational science.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 font-heading">Exclusive Access</h4>
                        <p className="text-gray-700 font-body">
                          Priority access to cutting-edge research findings and methodological innovations before
                          they're publicly available.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-8 rounded-lg shadow-lg">
                  <h4 className="text-xl font-bold text-gray-900 mb-4 font-heading">Program Structure</h4>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-bold text-sm">1</span>
                      </div>
                      <div>
                        <h5 className="font-semibold font-heading">Validation Gate</h5>
                        <p className="text-sm text-gray-600 font-body">Confirm audit findings alignment</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <span className="text-green-600 font-bold text-sm">2</span>
                      </div>
                      <div>
                        <h5 className="font-semibold font-heading">Co-Design Phase</h5>
                        <p className="text-sm text-gray-600 font-body">Collaborative intervention planning</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                        <span className="text-purple-600 font-bold text-sm">3</span>
                      </div>
                      <div>
                        <h5 className="font-semibold font-heading">Implementation</h5>
                        <p className="text-sm text-gray-600 font-body">
                          Guided transformation with continuous measurement
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                        <span className="text-orange-600 font-bold text-sm">4</span>
                      </div>
                      <div>
                        <h5 className="font-semibold font-heading">Knowledge Capture</h5>
                        <p className="text-sm text-gray-600 font-body">Document insights for scientific contribution</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Client Benefits */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-16 font-heading">
                Exclusive Benefits for Lighthouse Partners
              </h2>

              <div className="grid md:grid-cols-3 gap-8">
                <Card className="border-2 border-blue-200">
                  <CardHeader>
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                      <Target className="w-6 h-6 text-blue-600" />
                    </div>
                    <CardTitle className="font-heading">Precision Interventions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 font-body">
                      Interventions designed specifically for your validated organizational reality, not generic best
                      practices that may not apply to your context.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 border-green-200">
                  <CardHeader>
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                      <TrendingUp className="w-6 h-6 text-green-600" />
                    </div>
                    <CardTitle className="font-heading">Measurable Impact</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 font-body">
                      Continuous measurement using triangulated methods ensures you can track real progress and make
                      data-driven adjustments throughout the transformation.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 border-purple-200">
                  <CardHeader>
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                      <Award className="w-6 h-6 text-purple-600" />
                    </div>
                    <CardTitle className="font-heading">Thought Leadership</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 font-body">
                      Position your organization as a thought leader by contributing to peer-reviewed research and
                      industry best practices.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 border-orange-200">
                  <CardHeader>
                    <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                      <Users className="w-6 h-6 text-orange-600" />
                    </div>
                    <CardTitle className="font-heading">Expert Partnership</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 font-body">
                      Direct access to our multi-disciplinary team of organizational psychologists, change management
                      experts, and research scientists.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 border-red-200">
                  <CardHeader>
                    <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                      <Shield className="w-6 h-6 text-red-600" />
                    </div>
                    <CardTitle className="font-heading">Risk Mitigation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 font-body">
                      Evidence-based approach significantly reduces the risk of failed transformation initiatives by
                      addressing validated root causes.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 border-indigo-200">
                  <CardHeader>
                    <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                      <CheckCircle className="w-6 h-6 text-indigo-600" />
                    </div>
                    <CardTitle className="font-heading">Sustainable Change</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 font-body">
                      Focus on building internal capabilities and systems that ensure transformation results persist
                      long after the engagement ends.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Application Process */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-16 font-heading">
                How to Join The Lighthouse Project
              </h2>

              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600 font-bold">1</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2 font-heading">Complete Your Organizational Audit</h3>
                    <p className="text-gray-700 font-body">
                      The Lighthouse Project is exclusively available to organizations that have successfully completed
                      our comprehensive Organizational Audit and validated the findings through our structured process.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-green-600 font-bold">2</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2 font-heading">Pass the Validation Gate</h3>
                    <p className="text-gray-700 font-body">
                      Demonstrate explicit alignment with the triangulated findings from your audit. This ensures we
                      have a shared understanding of your organizational reality before designing transformation
                      interventions.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-purple-600 font-bold">3</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2 font-heading">Research Partnership Application</h3>
                    <p className="text-gray-700 font-body">
                      Submit a formal application demonstrating your organization's commitment to evidence-based
                      transformation and willingness to contribute to scientific research.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-orange-600 font-bold">4</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2 font-heading">Partnership Approval</h3>
                    <p className="text-gray-700 font-body">
                      Our research committee reviews applications based on scientific merit, transformation potential,
                      and alignment with our research objectives.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-indigo-600 to-purple-700">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-heading">
                Ready to Begin Your Journey?
              </h2>
              <p className="text-xl text-indigo-100 mb-8 font-body">
                The path to The Lighthouse Project begins with understanding your organizational reality through our
                comprehensive audit process.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-white text-indigo-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold font-heading"
                >
                  Start with Organizational Audit
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-indigo-600 px-8 py-4 text-lg font-semibold font-heading bg-transparent"
                >
                  Learn About Our Methodology
                </Button>
              </div>
              <p className="text-sm text-indigo-200 mt-6 font-body">
                * The Lighthouse Project is invitation-only and available exclusively to organizations that have
                completed our Organizational Audit.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
