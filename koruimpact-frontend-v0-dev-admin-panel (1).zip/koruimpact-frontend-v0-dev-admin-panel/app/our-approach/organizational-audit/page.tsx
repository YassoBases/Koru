import type { Metadata } from "next"
import { Navigation } from "@/components/Navigation"
import { Footer } from "@/components/Footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  BarChart3,
  Users,
  MessageSquare,
  Target,
  CheckCircle,
  ArrowRight,
  AlertTriangle,
  Shield,
  TrendingUp,
  Clock,
} from "lucide-react"
import Link from "next/link"

export const metadata: Metadata = {
  title: "Organizational Audit | Evidence-First Assessment",
  description:
    "Our comprehensive organizational audit combines quantitative surveys with qualitative validation to deliver triangulated evidence you can trust.",
}

export default function OrganizationalAuditPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-24 pb-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-koru-blue-50 via-white to-koru-green-50 py-20 relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1200')] opacity-5" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center">
              <Badge className="mb-6 bg-koru-blue-100 text-koru-blue-800 border-koru-blue-200 px-4 py-2 text-sm font-medium">
                <Target className="w-4 h-4 mr-2" />
                Core Service
              </Badge>
              <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl lg:text-6xl mb-6 leading-tight">
                Organizational{" "}
                <span className="bg-gradient-to-r from-koru-blue-600 to-koru-green-600 bg-clip-text text-transparent">
                  Audit
                </span>
              </h1>
              <p className="mt-6 text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
                Move beyond surface-level surveys. Our comprehensive audit delivers validated evidence through
                methodological triangulation—combining quantitative data with qualitative validation to uncover the real
                drivers of organizational performance.
              </p>
            </div>
          </div>
        </section>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* The Problem */}
          <section className="py-20">
            <div className="text-center mb-16">
              <div className="w-20 h-20 bg-gradient-to-br from-amber-100 to-orange-200 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertTriangle className="h-10 w-10 text-amber-600" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">The Data Validity Paradox</h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
                Traditional organizational surveys suffer from a critical flaw: they assume employees will provide
                honest, unbiased responses. In reality, cultural factors like high Power Distance and social
                desirability bias systematically corrupt self-report data.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <Card className="border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50/50 hover:shadow-lg transition-all duration-300 group">
                <CardHeader>
                  <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                    <Users className="w-6 h-6 text-amber-600" />
                  </div>
                  <CardTitle className="text-amber-800 group-hover:text-amber-900 transition-colors duration-300">
                    Response Bias
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-amber-700 leading-relaxed">
                    Employees tell you what they think you want to hear, not what they actually experience.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50/50 hover:shadow-lg transition-all duration-300 group">
                <CardHeader>
                  <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                    <Shield className="w-6 h-6 text-amber-600" />
                  </div>
                  <CardTitle className="text-amber-800 group-hover:text-amber-900 transition-colors duration-300">
                    Cultural Blindness
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-amber-700 leading-relaxed">
                    High Power Distance cultures create defensive silence that surveys can't detect.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50/50 hover:shadow-lg transition-all duration-300 group">
                <CardHeader>
                  <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                    <TrendingUp className="w-6 h-6 text-amber-600" />
                  </div>
                  <CardTitle className="text-amber-800 group-hover:text-amber-900 transition-colors duration-300">
                    Expensive Mistakes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-amber-700 leading-relaxed">
                    Acting on flawed data leads to interventions that miss the mark and waste resources.
                  </p>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Our Solution: Three-Phase Process */}
          <section className="py-20 bg-gradient-to-br from-gray-50 to-koru-blue-50/30 -mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <div className="w-20 h-20 bg-gradient-to-br from-koru-blue-100 to-koru-green-200 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="h-10 w-10 text-koru-blue-600" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Evidence-First Solution</h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
                We solve the Data Validity Paradox through methodological triangulation—systematically validating
                quantitative findings with structured qualitative methods.
              </p>
            </div>

            <div className="space-y-16">
              {/* Phase 1 */}
              <div className="flex flex-col lg:flex-row items-center gap-12">
                <div className="lg:w-1/2">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-koru-blue-600 to-koru-blue-700 text-white rounded-full flex items-center justify-center font-bold text-lg shadow-lg">
                      1
                    </div>
                    <h3 className="text-3xl font-bold text-gray-900">The Hypothesis Engine</h3>
                  </div>
                  <h4 className="text-xl font-semibold text-koru-blue-600 mb-4">Quantitative Snapshot</h4>
                  <p className="text-gray-600 mb-6 leading-relaxed text-lg">
                    We begin with a comprehensive survey, but we're intellectually honest about its limitations. This
                    quantitative data serves as our "Hypothesis Generation Tool"—identifying potential areas of concern
                    that require deeper investigation.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-koru-green-500 flex-shrink-0" />
                      <span className="text-gray-700">Validated psychometric instruments</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-koru-green-500 flex-shrink-0" />
                      <span className="text-gray-700">Cultural context considerations</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-koru-green-500 flex-shrink-0" />
                      <span className="text-gray-700">Statistical significance testing</span>
                    </li>
                  </ul>
                </div>
                <div className="lg:w-1/2">
                  <Card className="bg-gradient-to-br from-koru-blue-50 to-koru-blue-100 border-koru-blue-200 hover:shadow-xl transition-all duration-500 group">
                    <CardContent className="p-8 text-center">
                      <div className="w-20 h-20 bg-gradient-to-br from-koru-blue-100 to-koru-blue-200 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                        <BarChart3 className="h-10 w-10 text-koru-blue-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-3 text-lg">Survey Results</h4>
                      <p className="text-gray-600 mb-4">"Team psychological safety score: 4.2/10"</p>
                      <Badge className="bg-amber-100 text-amber-800 border-amber-200">Hypothesis Generated</Badge>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Phase 2 */}
              <div className="flex flex-col lg:flex-row-reverse items-center gap-12">
                <div className="lg:w-1/2">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-koru-green-600 to-koru-green-700 text-white rounded-full flex items-center justify-center font-bold text-lg shadow-lg">
                      2
                    </div>
                    <h3 className="text-3xl font-bold text-gray-900">The Deeper Story</h3>
                  </div>
                  <h4 className="text-xl font-semibold text-koru-green-600 mb-4">Qualitative Validation</h4>
                  <p className="text-gray-600 mb-6 leading-relaxed text-lg">
                    Here's where we uncover the "why" behind the numbers. Through confidential focus groups and key
                    informant interviews, we explore the cultural and systemic factors that surveys alone cannot
                    capture.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-koru-green-500 flex-shrink-0" />
                      <span className="text-gray-700">Confidential focus groups</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-koru-green-500 flex-shrink-0" />
                      <span className="text-gray-700">Key informant interviews</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-koru-green-500 flex-shrink-0" />
                      <span className="text-gray-700">Thematic analysis</span>
                    </li>
                  </ul>
                </div>
                <div className="lg:w-1/2">
                  <Card className="bg-gradient-to-br from-koru-green-50 to-koru-green-100 border-koru-green-200 hover:shadow-xl transition-all duration-500 group">
                    <CardContent className="p-8 text-center">
                      <div className="w-20 h-20 bg-gradient-to-br from-koru-green-100 to-koru-green-200 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                        <MessageSquare className="h-10 w-10 text-koru-green-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-3 text-lg">Qualitative Insights</h4>
                      <blockquote className="text-gray-600 italic border-l-4 border-koru-green-300 pl-4 mb-4 text-sm leading-relaxed">
                        "We don't challenge leadership decisions because last time someone did, they were 'restructured
                        out' within a month."
                      </blockquote>
                      <Badge className="bg-koru-green-100 text-koru-green-800 border-koru-green-200">
                        Root Cause Identified
                      </Badge>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Phase 3 */}
              <div className="flex flex-col lg:flex-row items-center gap-12">
                <div className="lg:w-1/2">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-full flex items-center justify-center font-bold text-lg shadow-lg">
                      3
                    </div>
                    <h3 className="text-3xl font-bold text-gray-900">The Synthesis</h3>
                  </div>
                  <h4 className="text-xl font-semibold text-purple-600 mb-4">Your Organizational Audit</h4>
                  <p className="text-gray-600 mb-6 leading-relaxed text-lg">
                    We integrate both data streams into a comprehensive report of validated evidence. This isn't just
                    data—it's triangulated intelligence that reveals the true drivers of organizational performance.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-koru-green-500 flex-shrink-0" />
                      <span className="text-gray-700">Integrated data analysis</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-koru-green-500 flex-shrink-0" />
                      <span className="text-gray-700">Validated findings</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-koru-green-500 flex-shrink-0" />
                      <span className="text-gray-700">Actionable recommendations</span>
                    </li>
                  </ul>
                </div>
                <div className="lg:w-1/2">
                  <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200 hover:shadow-xl transition-all duration-500 group">
                    <CardContent className="p-8 text-center">
                      <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-purple-200 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                        <TrendingUp className="h-10 w-10 text-purple-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-3 text-lg">Validated Evidence</h4>
                      <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                        "The real issue isn't lack of psychological safety—it's a culture of defensive silence driven by
                        fear of retaliation."
                      </p>
                      <Badge className="bg-purple-100 text-purple-800 border-purple-200">Evidence-Based Insight</Badge>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </section>

          {/* Benefits */}
          <section className="py-20">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Organizations Choose Our Audit</h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
                Move beyond guesswork. Get the validated evidence you need to drive successful transformation.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <Card className="hover:shadow-xl transition-all duration-500 border-0 bg-white hover:bg-gradient-to-br hover:from-white hover:to-koru-blue-50/30 group">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-koru-blue-100 to-koru-blue-200 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Target className="h-8 w-8 text-koru-blue-600" />
                  </div>
                  <CardTitle className="group-hover:text-koru-blue-700 transition-colors duration-300">
                    Clarity on Core Challenges
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600 leading-relaxed">
                    Understand not just what the problems are, but why they exist and how cultural factors perpetuate
                    them.
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-xl transition-all duration-500 border-0 bg-white hover:bg-gradient-to-br hover:from-white hover:to-koru-green-50/30 group">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-koru-green-100 to-koru-green-200 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Users className="h-8 w-8 text-koru-green-600" />
                  </div>
                  <CardTitle className="group-hover:text-koru-green-700 transition-colors duration-300">
                    Alignment Backed by Evidence
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600 leading-relaxed">
                    Build leadership consensus around validated findings that everyone can trust and act upon with
                    confidence.
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-xl transition-all duration-500 border-0 bg-white hover:bg-gradient-to-br hover:from-white hover:to-purple-50/30 group">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-purple-200 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Shield className="h-8 w-8 text-purple-600" />
                  </div>
                  <CardTitle className="group-hover:text-purple-700 transition-colors duration-300">
                    De-Risked Path to Transformation
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600 leading-relaxed">
                    Avoid costly mistakes by basing your transformation strategy on triangulated evidence, not
                    assumptions.
                  </p>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Process Timeline */}
          <section className="py-20 bg-gradient-to-br from-gray-50 to-koru-green-50/30 -mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <div className="w-20 h-20 bg-gradient-to-br from-koru-green-100 to-koru-blue-200 rounded-full flex items-center justify-center mx-auto mb-6">
                <Clock className="h-10 w-10 text-koru-green-600" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Typical Engagement Timeline</h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
                Our structured approach delivers validated insights in 6-8 weeks.
              </p>
            </div>

            <div className="grid md:grid-cols-4 gap-8">
              <div className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-r from-koru-blue-600 to-koru-blue-700 text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  1
                </div>
                <h4 className="font-semibold mb-2 text-lg group-hover:text-koru-blue-700 transition-colors duration-300">
                  Scoping & Design
                </h4>
                <p className="text-sm text-gray-600">Week 1</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-r from-koru-green-600 to-koru-green-700 text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  2
                </div>
                <h4 className="font-semibold mb-2 text-lg group-hover:text-koru-green-700 transition-colors duration-300">
                  Quantitative Data Collection
                </h4>
                <p className="text-sm text-gray-600">Weeks 2-3</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  3
                </div>
                <h4 className="font-semibold mb-2 text-lg group-hover:text-purple-700 transition-colors duration-300">
                  Qualitative Validation
                </h4>
                <p className="text-sm text-gray-600">Weeks 4-5</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-r from-koru-gold-500 to-koru-gold-600 text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  4
                </div>
                <h4 className="font-semibold mb-2 text-lg group-hover:text-koru-gold-700 transition-colors duration-300">
                  Analysis & Reporting
                </h4>
                <p className="text-sm text-gray-600">Weeks 6-8</p>
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-20">
            <Card className="bg-gradient-to-br from-koru-blue-600 via-koru-blue-700 to-koru-green-600 border-0 text-white overflow-hidden relative">
              <div className="absolute inset-0 bg-black/10" />
              <CardContent className="p-12 text-center relative z-10">
                <h2 className="text-3xl font-bold mb-4">Ready for Evidence You Can Trust?</h2>
                <p className="text-xl mb-8 max-w-3xl mx-auto text-blue-100 leading-relaxed">
                  Stop making critical decisions based on flawed data. Let's discuss how our organizational audit can
                  provide the validated evidence your transformation needs.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    asChild
                    size="lg"
                    className="bg-koru-gold-500 hover:bg-koru-gold-600 text-white shadow-lg hover:shadow-xl px-8 py-4 text-lg transition-all duration-300 group"
                  >
                    <Link href="/contact">
                      Request Audit Proposal
                      <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                    </Link>
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    size="lg"
                    className="border-white/30 text-white hover:bg-white/10 hover:border-white/50 px-8 py-4 text-lg bg-transparent backdrop-blur-sm transition-all duration-300"
                  >
                    <Link href="/case-studies">See Audit Results</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </section>
        </div>
      </main>

      <Footer />
    </div>
  )
}
