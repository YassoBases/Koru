import { Navigation } from "@/components/Navigation"
import { Footer } from "@/components/Footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  ArrowRight,
  Target,
  Users,
  Heart,
  Award,
  BookOpen,
  Globe,
  CheckCircle,
  Zap,
  Shield,
  TrendingUp,
} from "lucide-react"
import Link from "next/link"

export default function MethodologyPage() {
  const actionLearningSteps = [
    {
      step: "1",
      title: "Client Engagement",
      description:
        "Every organizational audit becomes a learning laboratory where our multidisciplinary team applies evidence-first principles in real-world contexts.",
      icon: Users,
      gradient: "from-blue-500 to-cyan-400",
    },
    {
      step: "2",
      title: "Delivery Debrief",
      description:
        "Institutionalized ritual where our team collaboratively deconstructs each engagement, identifying patterns and extracting validated insights.",
      icon: BookOpen,
      gradient: "from-cyan-400 to-teal-400",
    },
    {
      step: "3",
      title: "Insight Codification",
      description:
        "Systematic documentation of triangulated findings, cultural nuances, and methodological learnings into our proprietary knowledge base.",
      icon: Target,
      gradient: "from-teal-400 to-green-400",
    },
    {
      step: "4",
      title: "Methodology Refinement",
      description:
        "Continuous improvement of our evidence-first approach based on validated learnings from each client engagement.",
      icon: TrendingUp,
      gradient: "from-green-400 to-emerald-400",
    },
  ]

  const vrioAdvantages = [
    {
      title: "Valuable",
      description:
        "Our methodology directly addresses the critical market need for validated organizational insights, solving the widespread problem of unreliable survey data.",
      icon: Award,
      color: "text-blue-600",
      bg: "bg-blue-50",
    },
    {
      title: "Rare",
      description:
        "Few consulting firms systematically combine quantitative and qualitative methods with cultural intelligence to validate organizational findings.",
      icon: Shield,
      color: "text-purple-600",
      bg: "bg-purple-50",
    },
    {
      title: "Inimitable",
      description:
        "Our Action-Learning process creates socially complex, path-dependent knowledge that competitors cannot easily replicate or reverse-engineer.",
      icon: Zap,
      color: "text-orange-600",
      bg: "bg-orange-50",
    },
    {
      title: "Organized",
      description:
        "Institutionalized through systematic debriefs, structured documentation, and continuous methodology refinement across our entire team.",
      icon: CheckCircle,
      color: "text-green-600",
      bg: "bg-green-50",
    },
  ]

  const insightEngine = [
    {
      title: "Cultural Pattern Recognition",
      description:
        "Systematic identification of how cultural factors (Power Distance, Uncertainty Avoidance) impact data validity across different organizational contexts.",
    },
    {
      title: "Methodological Triangulation Templates",
      description:
        "Proven frameworks for combining quantitative surveys with qualitative validation methods, refined through dozens of client engagements.",
    },
    {
      title: "Validation Gate Protocols",
      description:
        "Structured processes for ensuring client alignment on findings before advancing to transformation recommendations.",
    },
    {
      title: "Evidence Synthesis Frameworks",
      description:
        "Proprietary methods for integrating multiple data sources into coherent, actionable organizational narratives.",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-blue-500 via-cyan-400 to-teal-400 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 via-transparent to-green-600/20"></div>
          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <Badge className="mb-6 bg-white/20 text-white border-white/30 hover:bg-white/30">
                Strategy 1.5: The Fortified Foundation
              </Badge>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 font-heading">Our Methodology</h1>
              <p className="text-xl md:text-2xl mb-8 text-white/95 leading-relaxed font-body">
                The Action-Learning framework that transforms every client engagement into a
                <span className="font-semibold text-yellow-200"> strategic learning laboratory</span>, building our
                proprietary Insight Engine.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur-sm px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105 shadow-lg font-heading"
                >
                  Explore Our Process
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105 bg-transparent font-heading"
                  asChild
                >
                  <Link href="/our-approach/organizational-audit">See It In Action</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* The Action-Learning Process */}
        <section className="py-20 bg-gradient-to-br from-gray-50 via-blue-50 to-cyan-50">
          <div className="container mx-auto px-6">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6 font-heading">
                  The Action-Learning Codification Process
                </h2>
                <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed font-body">
                  Every client engagement becomes a strategic learning laboratory. Our institutionalized Action-Learning
                  process systematically captures, codifies, and refines our methodology, creating a continuously
                  evolving competitive advantage.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {actionLearningSteps.map((step, index) => {
                  const IconComponent = step.icon
                  return (
                    <Card
                      key={index}
                      className="overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 bg-white/90 backdrop-blur-sm border border-white/50"
                    >
                      <div
                        className={`h-32 bg-gradient-to-br ${step.gradient} flex items-center justify-center relative`}
                      >
                        <div className="absolute top-4 left-4 w-8 h-8 bg-white/30 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-sm">{step.step}</span>
                        </div>
                        <IconComponent className="w-12 h-12 text-white" />
                      </div>
                      <CardHeader>
                        <CardTitle className="text-xl font-bold text-gray-800 font-heading">{step.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 leading-relaxed font-body">{step.description}</p>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>
          </div>
        </section>

        {/* VRIO Analysis */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6 font-heading">
                  Our VRIO-Defensible Competitive Advantage
                </h2>
                <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed font-body">
                  Our methodology creates a sustainable competitive moat through socially complex, inimitable processes
                  that systematically build proprietary intellectual property.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {vrioAdvantages.map((advantage, index) => {
                  const IconComponent = advantage.icon
                  return (
                    <Card key={index} className="text-center hover:shadow-lg transition-shadow duration-300">
                      <CardHeader>
                        <div
                          className={`w-16 h-16 ${advantage.bg} rounded-full flex items-center justify-center mx-auto mb-4`}
                        >
                          <IconComponent className={`w-8 h-8 ${advantage.color}`} />
                        </div>
                        <CardTitle className="text-lg font-bold font-heading">{advantage.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-gray-600 leading-relaxed font-body text-sm">
                          {advantage.description}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>
          </div>
        </section>

        {/* The Insight Engine */}
        <section className="py-20 bg-gradient-to-br from-emerald-50 via-cyan-50 to-blue-50">
          <div className="container mx-auto px-6">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6 font-heading">
                  The Proprietary Insight Engine
                </h2>
                <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed font-body">
                  Our living knowledge base, continuously enriched through systematic client engagement analysis,
                  cultural pattern recognition, and methodological refinement.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {insightEngine.map((component, index) => (
                  <Card
                    key={index}
                    className="bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <CardHeader>
                      <CardTitle className="text-xl font-bold font-heading flex items-center">
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-teal-400 rounded-full flex items-center justify-center mr-3">
                          <span className="text-white font-bold text-sm">{index + 1}</span>
                        </div>
                        {component.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 leading-relaxed font-body">{component.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Four-Pillar Ecosystem */}
        <section className="py-20 bg-gradient-to-br from-blue-600 via-cyan-500 to-teal-500 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 via-transparent to-green-600/20"></div>
          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 font-heading">Our Four-Pillar Ecosystem</h2>
              <p className="text-xl mb-12 text-white/90 font-body">
                A comprehensive, self-reinforcing "Value Chain Flywheel" approach to organizational transformation.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {[
                  {
                    title: "Social Science Research",
                    desc: "The intellectual engine conducting rigorous, culturally-attuned research",
                    icon: BookOpen,
                  },
                  {
                    title: "B2B Well-being Services",
                    desc: "Commercial engine applying research to solve client problems",
                    icon: Heart,
                  },
                  {
                    title: "Professional Education",
                    desc: "Community flywheel solidifying thought leadership",
                    icon: Users,
                  },
                  {
                    title: "UN SDG Consulting",
                    desc: "Purpose apex helping clients align with sustainable goals",
                    icon: Globe,
                  },
                ].map((pillar, index) => {
                  const IconComponent = pillar.icon
                  return (
                    <div key={index} className="text-center">
                      <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-6 border border-white/30">
                        <IconComponent className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-lg font-bold mb-3 font-heading">{pillar.title}</h3>
                      <p className="text-white/80 text-sm font-body leading-relaxed">{pillar.desc}</p>
                    </div>
                  )
                })}
              </div>

              <div className="mt-12">
                <Link href="/our-approach">
                  <Button
                    size="lg"
                    className="bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur-sm px-8 py-4 font-heading"
                  >
                    See Our Approach In Action
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6 font-heading">
                Experience Our Methodology
              </h2>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed font-body">
                Ready to move beyond unreliable survey data? Let our evidence-first methodology deliver the validated
                insights your organization needs for confident decision-making.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" asChild className="px-8 py-4 text-lg font-heading">
                  <Link href="/our-approach/organizational-audit">
                    Request Organizational Audit
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="px-8 py-4 text-lg font-heading bg-transparent">
                  <Link href="/case-studies">View Case Studies</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
