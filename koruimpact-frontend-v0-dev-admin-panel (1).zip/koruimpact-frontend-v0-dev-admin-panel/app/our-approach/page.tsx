import { Navigation } from "@/components/Navigation"
import { Footer } from "@/components/Footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Search, Users, FileText, ArrowRight, Target, Shield, TrendingUp } from "lucide-react"
import Link from "next/link"

export default function OurApproachPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="pt-24">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-koru-blue-50 via-white to-koru-green-50 relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1200')] opacity-5" />
          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <Badge className="mb-6 bg-koru-blue-100 text-koru-blue-800 border-koru-blue-200 px-4 py-2 text-sm font-medium">
                <Target className="w-4 h-4 mr-2" />
                Evidence-First Methodology
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 font-heading leading-tight">
                Beyond the Survey: Our{" "}
                <span className="bg-gradient-to-r from-koru-blue-600 to-koru-green-600 bg-clip-text text-transparent">
                  Evidence-First Audit
                </span>
              </h1>
              <p className="text-xl text-gray-700 mb-8 font-body leading-relaxed max-w-3xl mx-auto">
                Most organizational assessments rely on single-source data that can be misleading. We solve the "Data
                Validity Paradox" through methodological triangulation, delivering validated evidence you can trust.
              </p>
              <div className="flex flex-wrap justify-center items-center gap-6 text-sm text-gray-600 font-body mb-8">
                <div className="flex items-center bg-white/80 backdrop-blur-sm rounded-full px-4 py-2 shadow-sm hover:shadow-md transition-all duration-300">
                  <CheckCircle className="w-5 h-5 text-koru-green-600 mr-2" />
                  <span>Quantitative + Qualitative</span>
                </div>
                <div className="flex items-center bg-white/80 backdrop-blur-sm rounded-full px-4 py-2 shadow-sm hover:shadow-md transition-all duration-300">
                  <CheckCircle className="w-5 h-5 text-koru-green-600 mr-2" />
                  <span>Culturally Validated</span>
                </div>
                <div className="flex items-center bg-white/80 backdrop-blur-sm rounded-full px-4 py-2 shadow-sm hover:shadow-md transition-all duration-300">
                  <CheckCircle className="w-5 h-5 text-koru-green-600 mr-2" />
                  <span>Bias-Resistant</span>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  asChild
                  size="lg"
                  className="bg-koru-gold-500 hover:bg-koru-gold-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 px-8 py-4 text-lg font-semibold group"
                >
                  <Link href="/our-approach/organizational-audit">
                    Explore Our Audit Process
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-koru-blue-300 text-koru-blue-700 hover:bg-koru-blue-50 hover:border-koru-blue-400 px-8 py-4 text-lg font-semibold transition-all duration-300 bg-transparent"
                >
                  <Link href="/our-approach/methodology">View Our Methodology</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* The Problem Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto">
              <div className="bg-gradient-to-r from-red-50 to-orange-50 border-l-4 border-red-400 p-8 mb-12 rounded-r-lg shadow-sm hover:shadow-md transition-all duration-300">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Shield className="w-6 h-6 text-red-600" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-semibold text-red-800 mb-3 font-heading">
                      The Hidden Risk in Traditional Surveys
                    </h3>
                    <p className="text-red-700 font-body text-lg leading-relaxed">
                      In high Power Distance cultures, employees often provide socially desirable responses rather than
                      honest feedback. A single survey can miss critical systemic issues, leading to misguided
                      interventions and wasted resources.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Three-Step Process */}
        <section className="py-20 bg-gradient-to-br from-gray-50 to-koru-blue-50/30">
          <div className="container mx-auto px-6">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 font-heading">
                  Our Three-Step Evidence-First Process
                </h2>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                  A systematic approach to uncovering organizational truth through methodological triangulation
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                {/* Step 1 */}
                <Card className="relative group hover:shadow-xl transition-all duration-500 border-0 bg-white hover:bg-gradient-to-br hover:from-white hover:to-koru-blue-50/50">
                  <div className="absolute -top-4 left-6 bg-gradient-to-r from-koru-blue-600 to-koru-blue-700 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold text-lg shadow-lg">
                    1
                  </div>
                  <CardHeader className="pt-8">
                    <div className="w-16 h-16 bg-gradient-to-br from-koru-blue-100 to-koru-blue-200 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                      <Search className="w-8 h-8 text-koru-blue-600" />
                    </div>
                    <CardTitle className="font-heading text-xl">The Hypothesis Engine</CardTitle>
                    <p className="text-sm text-koru-blue-600 font-medium">A Quantitative Snapshot</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-6 font-body leading-relaxed">
                      We begin with a comprehensive survey to generate initial hypotheses about your organizational
                      challenges. This quantitative data provides the "what" - identifying patterns and potential areas
                      of concern.
                    </p>
                    <div className="bg-gradient-to-r from-koru-blue-50 to-koru-blue-100/50 p-4 rounded-lg border border-koru-blue-200">
                      <p className="text-sm text-koru-blue-800 font-body">
                        <strong className="font-semibold">Key Output:</strong> Initial hypotheses and quantitative
                        baselines across key organizational dimensions.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Step 2 */}
                <Card className="relative group hover:shadow-xl transition-all duration-500 border-0 bg-white hover:bg-gradient-to-br hover:from-white hover:to-koru-green-50/50">
                  <div className="absolute -top-4 left-6 bg-gradient-to-r from-koru-green-600 to-koru-green-700 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold text-lg shadow-lg">
                    2
                  </div>
                  <CardHeader className="pt-8">
                    <div className="w-16 h-16 bg-gradient-to-br from-koru-green-100 to-koru-green-200 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                      <Users className="w-8 h-8 text-koru-green-600" />
                    </div>
                    <CardTitle className="font-heading text-xl">The Deeper Story</CardTitle>
                    <p className="text-sm text-koru-green-600 font-medium">Qualitative Validation</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-6 font-body leading-relaxed">
                      Through confidential focus groups and key informant interviews, we explore the "why" behind the
                      quantitative patterns. This reveals cultural nuances, systemic drivers, and context that surveys
                      alone cannot capture.
                    </p>
                    <div className="bg-gradient-to-r from-koru-green-50 to-koru-green-100/50 p-4 rounded-lg border border-koru-green-200">
                      <p className="text-sm text-koru-green-800 font-body">
                        <strong className="font-semibold">Key Output:</strong> Rich qualitative insights that validate,
                        challenge, or deepen the initial quantitative hypotheses.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Step 3 */}
                <Card className="relative group hover:shadow-xl transition-all duration-500 border-0 bg-white hover:bg-gradient-to-br hover:from-white hover:to-purple-50/50">
                  <div className="absolute -top-4 left-6 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-full w-10 h-10 flex items-center justify-center font-bold text-lg shadow-lg">
                    3
                  </div>
                  <CardHeader className="pt-8">
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-purple-200 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                      <FileText className="w-8 h-8 text-purple-600" />
                    </div>
                    <CardTitle className="font-heading text-xl">The Synthesis</CardTitle>
                    <p className="text-sm text-purple-600 font-medium">Your Organizational Audit</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-6 font-body leading-relaxed">
                      We integrate both data streams into a comprehensive audit that provides validated evidence about
                      your organization's reality. This triangulated approach ensures reliability and actionability.
                    </p>
                    <div className="bg-gradient-to-r from-purple-50 to-purple-100/50 p-4 rounded-lg border border-purple-200">
                      <p className="text-sm text-purple-800 font-body">
                        <strong className="font-semibold">Key Output:</strong> A comprehensive organizational audit with
                        validated findings and evidence-based recommendations.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 font-heading">
                  Client-Centric Outcomes
                </h2>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                  Transform uncertainty into clarity with evidence you can trust and act upon
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center group">
                  <div className="w-20 h-20 bg-gradient-to-br from-koru-blue-100 to-koru-blue-200 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                    <CheckCircle className="w-10 h-10 text-koru-blue-600" />
                  </div>
                  <h3 className="text-2xl font-semibold mb-4 font-heading group-hover:text-koru-blue-700 transition-colors duration-300">
                    Clarity on Core Challenges
                  </h3>
                  <p className="text-gray-700 font-body leading-relaxed">
                    Move beyond surface-level symptoms to understand the root causes of organizational dysfunction.
                  </p>
                </div>

                <div className="text-center group">
                  <div className="w-20 h-20 bg-gradient-to-br from-koru-green-100 to-koru-green-200 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                    <Users className="w-10 h-10 text-koru-green-600" />
                  </div>
                  <h3 className="text-2xl font-semibold mb-4 font-heading group-hover:text-koru-green-700 transition-colors duration-300">
                    Alignment Backed by Evidence
                  </h3>
                  <p className="text-gray-700 font-body leading-relaxed">
                    Build leadership consensus around validated findings that everyone can trust and act upon.
                  </p>
                </div>

                <div className="text-center group">
                  <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-purple-200 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                    <TrendingUp className="w-10 h-10 text-purple-600" />
                  </div>
                  <h3 className="text-2xl font-semibold mb-4 font-heading group-hover:text-purple-700 transition-colors duration-300">
                    A De-Risked Path to Transformation
                  </h3>
                  <p className="text-gray-700 font-body leading-relaxed">
                    Make informed decisions about organizational change based on comprehensive, validated evidence.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-koru-blue-600 via-koru-blue-700 to-koru-green-600 relative overflow-hidden">
          <div className="absolute inset-0 bg-black/10" />
          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-heading">
                Ready to Move Beyond Guesswork?
              </h2>
              <p className="text-xl text-blue-100 mb-8 font-body leading-relaxed">
                Let's discuss how our evidence-first organizational audit can provide the validated insights your
                organization needs to thrive.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  asChild
                  size="lg"
                  className="bg-koru-gold-500 hover:bg-koru-gold-600 text-white shadow-lg hover:shadow-xl px-8 py-4 text-lg font-semibold font-heading transition-all duration-300 group"
                >
                  <Link href="/contact">
                    Request an Audit Proposal
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10 hover:border-white/50 px-8 py-4 text-lg font-semibold font-heading bg-transparent backdrop-blur-sm transition-all duration-300"
                >
                  <Link href="/our-approach/organizational-audit">Learn More About Our Process</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
