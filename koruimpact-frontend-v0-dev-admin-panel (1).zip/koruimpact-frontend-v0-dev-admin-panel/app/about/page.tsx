import Link from "next/link"
import { ArrowLeft } from 'lucide-react'
import { BreadcrumbNavigation } from "@/components/BreadcrumbNavigation"
import { Team } from "@/components/Team"
import { EnhancedTestimonials } from "@/components/EnhancedTestimonials"
import { TrustSignals } from "@/components/TrustSignals"
import { GuidingPrinciples } from "@/components/GuidingPrinciples"
import { FinalCTA } from "@/components/FinalCTA"
import { Footer } from "@/components/Footer"
import { Header } from "@/components/Header"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          <BreadcrumbNavigation
            items={[
              { href: "/", label: "Home" },
              { href: "/about", label: "About Us" },
            ]}
          />
          <div className="my-8">
            <Link href="/" className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900 transition-colors">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Link>
          </div>

          <section className="py-12 md:py-20">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">About Koru Impact</h1>
              <p className="text-lg text-gray-700 leading-relaxed">
                At Koru Impact, we believe in fostering thriving workplaces where individuals and teams can flourish. Our mission is to empower organizations to build resilient cultures, enhance psychological safety, and drive sustainable growth through evidence-based strategies and compassionate guidance.
              </p>
            </div>
          </section>

          <GuidingPrinciples />
          <Team />
          <EnhancedTestimonials />
          <TrustSignals />
          <FinalCTA />
        </div>
      </main>
      <Footer />
    </div>
  )
}
