import { RootLayoutClient } from "@/components/layouts/RootLayoutClient"
import { Toaster } from "@/components/ui/toaster"
import { AuthProvider } from "@/contexts/AuthContext"
import type { Metadata } from "next"
import { Inter } from 'next/font/google'
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Koru Impact",
  description: "Driving sustainable change through strategic impact.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          <RootLayoutClient>
            {children}
          </RootLayoutClient>
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  )
}
