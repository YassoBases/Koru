"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, BookOpen, Calendar, FileText, TrendingUp, UserCheck, Users } from "lucide-react"
import Link from "next/link"

// Mock data for dashboard
const mockStats = {
  totalClients: 24,
  activeProjects: 12,
  totalLeads: 156,
  conversionRate: 27,
  monthlyRevenue: 425000,
  contentPieces: 48,
  playbookEntries: 32,
  teamUtilization: 87,
}

const mockRecentActivities = [
  {
    id: 1,
    type: "Client",
    description: "New client onboarded: TechCorp Inc.",
    timestamp: "2 hours ago",
    status: "success",
  },
  {
    id: 2,
    type: "Lead",
    description: "Qualified lead: Jennifer Martinez from InnovateTech",
    timestamp: "4 hours ago",
    status: "info",
  },
  {
    id: 3,
    type: "Content",
    description: "Published: Building Psychological Safety in Remote Teams",
    timestamp: "1 day ago",
    status: "success",
  },
  {
    id: 4,
    type: "Debrief",
    description: "Completed debrief for Global Manufacturing engagement",
    timestamp: "2 days ago",
    status: "success",
  },
]

const mockUpcomingTasks = [
  {
    id: 1,
    title: "Follow up with David Kim (Future Finance)",
    dueDate: "2024-01-25",
    priority: "High",
    type: "Lead Management",
  },
  {
    id: 2,
    title: "Complete TechCorp quarterly review",
    dueDate: "2024-01-26",
    priority: "Medium",
    type: "Client Management",
  },
  {
    id: 3,
    title: "Update psychological safety methodology",
    dueDate: "2024-01-28",
    priority: "Low",
    type: "Playbook",
  },
  {
    id: 4,
    title: "Publish Q1 insights report",
    dueDate: "2024-01-30",
    priority: "High",
    type: "Content",
  },
]

export default function AdminDashboard() {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "High":
        return "destructive"
      case "Medium":
        return "default"
      case "Low":
        return "secondary"
      default:
        return "outline"
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "Client":
        return <Users className="h-4 w-4" />
      case "Lead":
        return <UserCheck className="h-4 w-4" />
      case "Content":
        return <FileText className="h-4 w-4" />
      case "Debrief":
        return <BookOpen className="h-4 w-4" />
      default:
        return <AlertCircle className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-8">
        {/* Strategy 1.5 Metrics */}
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-blue-900">Strategy 1.5: Action-Learning Metrics</CardTitle>
            <CardDescription className="text-blue-700">
              Key performance indicators for building our VRIO-defensible competitive advantage through systematic
              knowledge capture.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{mockStats.playbookEntries}</div>
                <div className="text-sm text-blue-700">Playbook Entries</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">91%</div>
                <div className="text-sm text-blue-700">Avg Methodology Effectiveness</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">156</div>
                <div className="text-sm text-blue-700">Insights Captured</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{mockStats.teamUtilization}%</div>
                <div className="text-sm text-blue-700">Team Utilization</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Clients</p>
                  <p className="text-2xl font-bold text-gray-900">{mockStats.totalClients}</p>
                  <p className="text-xs text-green-600 mt-1">+12% from last month</p>
                </div>
                <Users className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Projects</p>
                  <p className="text-2xl font-bold text-gray-900">{mockStats.activeProjects}</p>
                  <p className="text-xs text-green-600 mt-1">+3 new this month</p>
                </div>
                <BookOpen className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Leads</p>
                  <p className="text-2xl font-bold text-gray-900">{mockStats.totalLeads}</p>
                  <p className="text-xs text-green-600 mt-1">{mockStats.conversionRate}% conversion rate</p>
                </div>
                <UserCheck className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Monthly Revenue</p>
                  <p className="text-2xl font-bold text-gray-900">${(mockStats.monthlyRevenue / 1000).toFixed(0)}K</p>
                  <p className="text-xs text-green-600 mt-1">+18% from last month</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Activities */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activities</CardTitle>
              <CardDescription>Latest updates across all modules</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockRecentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-start space-x-3">
                    <div className="flex-shrink-0 mt-1">{getActivityIcon(activity.type)}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900">{activity.description}</p>
                      <p className="text-xs text-gray-500">{activity.timestamp}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {activity.type}
                    </Badge>
                  </div>
                ))}
              </div>
              <div className="mt-6">
                <Button variant="outline" className="w-full bg-transparent">
                  View All Activities
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Tasks */}
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Tasks</CardTitle>
              <CardDescription>Important tasks and deadlines</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockUpcomingTasks.map((task) => (
                  <div key={task.id} className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900">{task.title}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Calendar className="h-3 w-3 text-gray-400" />
                        <p className="text-xs text-gray-500">{new Date(task.dueDate).toLocaleDateString()}</p>
                        <Badge variant="outline" className="text-xs">
                          {task.type}
                        </Badge>
                      </div>
                    </div>
                    <Badge variant={getPriorityColor(task.priority)} className="text-xs ml-2">
                      {task.priority}
                    </Badge>
                  </div>
                ))}
              </div>
              <div className="mt-6">
                <Button variant="outline" className="w-full bg-transparent">
                  View All Tasks
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Frequently used actions and shortcuts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button asChild variant="outline" className="h-20 flex-col bg-transparent">
                <Link href="/admin/clients/new">
                  <Users className="h-6 w-6 mb-2" />
                  Add New Client
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex-col bg-transparent">
                <Link href="/admin/leads/new">
                  <UserCheck className="h-6 w-6 mb-2" />
                  Add New Lead
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex-col bg-transparent">
                <Link href="/admin/content/new">
                  <FileText className="h-6 w-6 mb-2" />
                  Create Content
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex-col bg-transparent">
                <Link href="/admin/debriefs/new">
                  <BookOpen className="h-6 w-6 mb-2" />
                  New Debrief
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
    </div>
  )
}
