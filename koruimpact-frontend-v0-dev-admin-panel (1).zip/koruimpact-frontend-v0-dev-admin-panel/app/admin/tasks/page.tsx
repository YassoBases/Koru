// app/admin/tasks/page.tsx
"use client"

import { LoadingSpinner } from "@/components/LoadingSpinner"
import { CreateTaskForm } from "@/components/tasks/CreateTaskForm"
import { EditTaskForm } from "@/components/tasks/EditTaskForm"
import { TaskList } from "@/components/tasks/TaskList"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { apiService } from "@/src/services/apiService"
import { Task, TasksResponse } from "@/src/types"
import { Plus } from "lucide-react"
import { useCallback, useEffect, useState } from "react"

export default function AdminTasksPage() {
    const [tasks, setTasks] = useState<Task[]>([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState<string | null>(null)
    const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
    const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
    const [selectedTask, setSelectedTask] = useState<Task | null>(null)

    const fetchTasks = useCallback(async () => {
        try {
            const response = await apiService.tasks.getAll() as unknown as TasksResponse | Task[];
            const tasksData = Array.isArray(response) ? response : response?.data;
            setTasks(Array.isArray(tasksData) ? tasksData : []);
            setError(null)
        } catch (err) {
            console.error("Failed to fetch tasks:", err)
            setError("Failed to load tasks.")
        } finally {
            setLoading(false)
        }
    }, [])

    useEffect(() => {
        setLoading(true);
        fetchTasks()
    }, [fetchTasks])

    const handleCreateTask = (newTask: Task) => {
        // Optimistic update for immediate UI feedback
        setTasks((prev) => [newTask, ...(prev || [])]);
        setIsCreateDialogOpen(false);
        // Silently re-fetch to ensure data consistency without a loading spinner
        fetchTasks(); 
    }

    const handleUpdateTask = (updatedTask: Task) => {
        // Optimistic update: find the task in the list and replace it.
        setTasks((prev) => 
            (prev || []).map((task) => 
                task.id === updatedTask.id ? updatedTask : task
            )
        );
        // Close the dialog and clear the selected task.
        setIsEditDialogOpen(false)
        setSelectedTask(null)
    }

    const handleDeleteTask = async (taskId: string) => {
        const originalTasks = tasks;
        // Optimistic update
        setTasks((prev) => (prev || []).filter((task) => task.id !== taskId));
        try {
            await apiService.tasks.delete(taskId);
        } catch (error) {
            console.error("Failed to delete task:", error);
            // Revert on error
            setTasks(originalTasks);
        }
    }

    const openEditDialog = (task: Task) => {
        setSelectedTask(task)
        setIsEditDialogOpen(true)
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle>Task Management</CardTitle>
                        <CardDescription>Create, assign, and track tasks across the organization.</CardDescription>
                    </div>
                     <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                        <DialogTrigger asChild>
                            <Button><Plus className="mr-2 h-4 w-4" />Create Task</Button>
                        </DialogTrigger>
                        <DialogContent>
                            <DialogHeader>
                                <DialogTitle>Create New Task</DialogTitle>
                                <DialogDescription>
                                    Fill in the details below to create a new task.
                                </DialogDescription>
                            </DialogHeader>
                            <CreateTaskForm onCreate={handleCreateTask} />
                        </DialogContent>
                    </Dialog>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="flex justify-center items-center h-40">
                            <LoadingSpinner />
                        </div>
                    ) : error ? (
                        <div className="text-center text-red-600">{error}</div>
                    ) : (
                        <TaskList tasks={tasks} onEdit={openEditDialog} onDelete={handleDeleteTask} />
                    )}
                </CardContent>
            </Card>

            {selectedTask && (
                <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                <DialogContent className="sm:max-w-lg">
                    <DialogHeader>
                        <DialogTitle>Edit Task</DialogTitle>
                        <DialogDescription>
                            Update the details for the task "{selectedTask.title}".
                        </DialogDescription>
                    </DialogHeader>
                    <EditTaskForm task={selectedTask} onUpdate={handleUpdateTask} />
                </DialogContent>
                </Dialog>
            )}
        </div>
    )
}
