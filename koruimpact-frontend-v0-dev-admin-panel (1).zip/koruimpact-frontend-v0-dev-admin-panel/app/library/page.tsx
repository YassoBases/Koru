import Link from "next/link"
import { Metadata } from "next"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import { FinalCTA } from "@/components/FinalCTA"
import { PremiumContentLibrary } from "@/components/PremiumContentLibrary"

export const metadata: Metadata = {
  title: "Library - Koru Impact",
  description: "Access Koru Impact's comprehensive library of resources, guides, and tools for organizational development, leadership, and psychological safety.",
}

const libraryItems = [
  {
    id: "1",
    title: "The Ultimate Guide to Psychological Safety",
    description: "A comprehensive guide to understanding, implementing, and measuring psychological safety in your organization.",
    image: "/public/images/psychological-safety-guide.png",
    link: "#",
    type: "Guide",
  },
  {
    id: "2",
    title: "Burnout Prevention Playbook for Leaders",
    description: "Actionable strategies for leaders to identify, prevent, and address burnout within their teams.",
    image: "/public/images/burnout-prevention-leadership.png",
    link: "#",
    type: "Playbook",
  },
  {
    id: "3",
    title: "Team Cohesion Toolkit: Building Stronger Bonds",
    description: "Tools and exercises to enhance team collaboration, communication, and overall cohesion.",
    image: "/public/images/team-cohesion-guide.png",
    link: "#",
    type: "Toolkit",
  },
  {
    id: "4",
    title: "Organizational Culture Assessment Framework",
    description: "A step-by-step framework for conducting a thorough assessment of your company's culture.",
    image: "/placeholder.svg?height=200&width=300",
    link: "#",
    type: "Framework",
  },
  {
    id: "5",
    title: "Leading Through Change: A Leader's Handbook",
    description: "Essential insights and practical advice for leaders navigating periods of significant organizational change.",
    image: "/placeholder.svg?height=200&width=300",
    link: "#",
    type: "Handbook",
  },
  {
    id: "6",
    title: "Innovation Workshop Facilitator Guide",
    description: "A complete guide for facilitating workshops designed to spark creativity and drive innovation within teams.",
    image: "/placeholder.svg?height=200&width=300",
    link: "#",
    type: "Guide",
  },
]

export default function LibraryPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  Our Library
                </h1>
                <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                  Access a wealth of resources, guides, and tools to support your organizational development journey.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container grid items-center justify-center gap-4 px-4 text-center md:px-6 lg:gap-10">
            <div className="space-y-3">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Featured Resources
              </h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                Explore some of our most popular and impactful resources.
              </p>
            </div>
            <div className="grid w-full grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {libraryItems.map((item) => (
                <Card key={item.id} className="flex flex-col">
                  <CardHeader>
                    <Image
                      src={item.image || "/placeholder.svg"}
                      alt={item.title}
                      width={300}
                      height={200}
                      className="aspect-video object-cover rounded-md mb-4"
                    />
                    <CardTitle className="text-xl font-bold">{item.title}</CardTitle>
                    <CardDescription className="text-sm text-gray-500">
                      Type: {item.type}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <p className="text-sm text-gray-600 dark:text-gray-400">{item.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Button asChild className="w-full">
                      <Link href={item.link}>Download / Learn More</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <PremiumContentLibrary />

        <FinalCTA />
      </main>
    </div>
  )
}
