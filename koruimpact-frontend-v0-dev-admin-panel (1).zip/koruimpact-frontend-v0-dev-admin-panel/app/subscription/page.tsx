import Link from "next/link"
import { Metadata } from "next"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle } from 'lucide-react'
import { FinalCTA } from "@/components/FinalCTA"
import { SubscriptionGate } from "@/components/SubscriptionGate"

export const metadata: Metadata = {
  title: "Subscription - Koru Impact",
  description: "Unlock premium content and exclusive features with Koru Impact's subscription plans. Access advanced guides, tools, and expert insights.",
}

const subscriptionPlans = [
  {
    id: "basic",
    name: "Basic Access",
    price: "$19/month",
    features: [
      "Access to all public journal articles",
      "Basic guides and templates",
      "Monthly newsletter",
      "Community forum access",
    ],
    buttonText: "Get Started",
    link: "#",
  },
  {
    id: "premium",
    name: "Premium Pro",
    price: "$49/month",
    features: [
      "Everything in Basic Access",
      "Full access to premium content library",
      "Exclusive webinars and workshops",
      "Early access to new research",
      "Priority community support",
    ],
    buttonText: "Go Premium",
    link: "#",
  },
  {
    id: "enterprise",
    name: "Enterprise Solutions",
    price: "Custom",
    features: [
      "Tailored organizational assessments",
      "Dedicated expert consultation",
      "Customized training programs",
      "On-site workshops",
      "Strategic partnership opportunities",
    ],
    buttonText: "Contact Sales",
    link: "/contact",
  },
]

export default function SubscriptionPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  Unlock Premium Insights
                </h1>
                <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                  Choose a plan that fits your needs and gain access to exclusive content, tools, and expert support.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container grid items-center justify-center gap-4 px-4 text-center md:px-6 lg:gap-10">
            <div className="space-y-3">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Our Subscription Plans
              </h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                Whether you're an individual looking to grow or an organization seeking transformation, we have a plan for you.
              </p>
            </div>
            <div className="grid w-full grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {subscriptionPlans.map((plan) => (
                <Card key={plan.id} className="flex flex-col">
                  <CardHeader className="text-center">
                    <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                    <CardDescription className="text-4xl font-bold text-primary mt-2">
                      {plan.price}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-2 text-left">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button asChild className="w-full">
                      <Link href={plan.link}>{plan.buttonText}</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <SubscriptionGate />

        <FinalCTA />
      </main>
    </div>
  )
}
