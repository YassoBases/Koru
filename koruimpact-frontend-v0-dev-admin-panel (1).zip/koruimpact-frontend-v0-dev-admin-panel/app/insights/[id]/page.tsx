"use client"

import { BreadcrumbNavigation } from "@/components/BreadcrumbNavigation"
import { LoadingSpinner } from "@/components/LoadingSpinner"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { apiService } from "@/src/services/apiService"
import { Content } from "@/src/types/content.types"
import { User } from "@/src/types/user.types"
import { ArrowLeft, Share2 } from "lucide-react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import React, { useEffect, useState } from "react"

// Helper function to convert Firestore timestamp
const formatFirestoreTimestamp = (timestamp: any) => {
  if (timestamp && timestamp._seconds) {
    return new Date(timestamp._seconds * 1000).toLocaleDateString();
  }
  if (typeof timestamp === 'string') {
    return new Date(timestamp).toLocaleDateString();
  }
  return "Date not available";
};

export default function InsightDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  // Unwrap the params promise with React.use()
  const resolvedParams = React.use(params);
  const [insight, setInsight] = useState<Content | null>(null)
  const [author, setAuthor] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    const loadInsightAndAuthor = async () => {
      // Use the resolved ID from the unwrapped params
      const { id } = resolvedParams;
      if (!id) {
        setError("No insight ID provided.");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const insightData = await apiService.content.getById(id as string);
        
        if (insightData) {
          setInsight(insightData);
          
          if (insightData.authorId) {
            try {
              const authorData = await apiService.users.getById(insightData.authorId);
              if(authorData) {
                setAuthor(authorData);
              }
            } catch (authorError) {
              console.warn("Could not fetch author details:", authorError);
              setAuthor(null);
            }
          }
        } else {
          throw new Error("Insight not found.");
        }
      } catch (err: any) {
        setError(err.message || "Failed to load insight");
        console.error('Error loading insight:', err);
      } finally {
        setLoading(false);
      }
    }

    loadInsightAndAuthor();
  }, [resolvedParams]);


  if (loading) {
    return <LoadingSpinner />;
  }

  if (error || !insight) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Button variant="ghost" onClick={() => router.back()} className="mb-6 flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" /> Back to Insights
        </Button>
        <div className="flex items-center justify-center h-64">
          <p className="text-lg text-destructive">{error || "Insight not found."}</p>
        </div>
      </div>
    )
  }

  const authorName = author?.displayName || "Koru Impact Team";
  const authorInitials = author?.displayName ? author.displayName.split(' ').map(n => n[0]).join('') : "KI";

  return (
    <div className="min-h-screen bg-background">
      <main className="pt-16">
        <div className="container mx-auto px-6 pt-6">
          <BreadcrumbNavigation items={[{ label: "Insights", href: "/insights" }, { label: insight.title }]} />
        </div>

        <section className="py-12">
          <div className="container mx-auto px-6 max-w-4xl">
             <Button variant="ghost" onClick={() => router.back()} className="mb-6">
                  <ArrowLeft className="w-4 w-4 mr-2" />
                  Back to Insights
              </Button>
            <div className="mb-6">
              {insight.tags && insight.tags.length > 0 && (
                 <Badge className="mb-4">{insight.tags[0]}</Badge>
              )}
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-800 mb-6 font-heading leading-tight">
                {insight.title}
              </h1>
            </div>

            <div className="flex flex-wrap items-center gap-6 mb-8 pb-8 border-b border-gray-200">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={author?.profile?.photoURL} alt={authorName} />
                    <AvatarFallback>{authorInitials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-gray-800">{authorName}</p>
                    <p className="text-sm text-gray-600">Published on {formatFirestoreTimestamp(insight.createdAt)}</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="ml-auto bg-transparent">
                  <Share2 className="w-4 w-4 mr-2" />
                  Share
                </Button>
            </div>
          </div>
        </section>

        <section className="pb-12">
          <div className="container mx-auto px-6 max-w-4xl">
            <div className="relative w-full h-64 md:h-96 mb-8 rounded-lg overflow-hidden bg-gray-100">
                <Image
                  src={insight.thumbnailUrl || "/placeholder.svg?height=400&width=800"}
                  alt={insight.title}
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            <div
              className="prose prose-lg max-w-none font-body"
              dangerouslySetInnerHTML={{ __html: insight.content }}
            />
          </div>
        </section>
      </main>
    </div>
  )
}
