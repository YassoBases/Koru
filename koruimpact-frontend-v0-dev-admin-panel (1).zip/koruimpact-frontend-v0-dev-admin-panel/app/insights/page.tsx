import type { Metadata } from "next"
import { Navigation } from "@/components/Navigation"
import { Footer } from "@/components/Footer"
import { InsightsPage } from "@/components/insights/InsightsPage"

export const metadata: Metadata = {
  title: "Insights | Evidence-Based Organizational Research",
  description:
    "Explore our latest research, case studies, and insights on organizational transformation, psychological safety, and evidence-based leadership.",
}

export default function Insights() {
  return <InsightsPage />
}
