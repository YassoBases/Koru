import { EvidenceFirstShowcase } from "@/components/EvidenceFirstShowcase"
import { FinalCTA } from "@/components/FinalCTA"
import { Footer } from "@/components/Footer"
import { GuidingPrinciples } from "@/components/GuidingPrinciples"
import { Hero } from "@/components/Hero"
import { LatestJournal } from "@/components/LatestJournal"
import { LighthouseProjectHighlight } from "@/components/LighthouseProjectHighlight"
import { Navigation } from "@/components/Navigation"
import { ScrollToTop } from "@/components/ScrollToTop"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main className="pt-24">
        <Hero />
        <EvidenceFirstShowcase />
        <LighthouseProjectHighlight />
        <GuidingPrinciples />
        <LatestJournal />
        <FinalCTA />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  )
}
