import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import { Lock } from 'lucide-react'

export function PremiumContentLibrary() {
  const premiumItems = [
    {
      id: "1",
      title: "Advanced Psychological Safety Metrics",
      description: "Deep dive into advanced metrics and analytics for measuring and improving psychological safety.",
      image: "/placeholder.svg?height=200&width=300",
      type: "Report",
    },
    {
      id: "2",
      title: "Executive Playbook: Leading Through Disruption",
      description: "Strategies for senior leaders to navigate and thrive amidst unprecedented organizational disruption.",
      image: "/placeholder.svg?height=200&width=300",
      type: "Playbook",
    },
    {
      id: "3",
      title: "Webinar Recording: Future of Work & AI",
      description: "A recording of our exclusive webinar discussing the intersection of AI, automation, and the evolving workplace.",
      image: "/placeholder.svg?height=200&width=300",
      type: "Webinar",
    },
  ]

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Premium Content Library
            </h2>
            <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              Unlock exclusive access to our in-depth reports, executive playbooks, and expert webinars.
            </p>
          </div>
        </div>
        <div className="grid w-full grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 mt-10">
          {premiumItems.map((item) => (
            <Card key={item.id} className="flex flex-col relative overflow-hidden">
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center z-10">
                <Lock className="h-12 w-12 text-white" />
              </div>
              <CardHeader>
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  width={300}
                  height={200}
                  className="aspect-video object-cover rounded-md mb-4 blur-sm" // Apply blur for premium content
                />
                <CardTitle className="text-xl font-bold">{item.title}</CardTitle>
                <CardDescription className="text-sm text-gray-500">
                  Type: {item.type}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1">
                <p className="text-sm text-gray-600 dark:text-gray-400">{item.description}</p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full" disabled>
                  <Link href="/subscription">Unlock with Premium</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        <div className="flex justify-center mt-10">
          <Button asChild>
            <Link href="/subscription">View All Plans</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
