"use client"

import { StatCard } from "@/components/dashboard/StatCard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/contexts/AuthContext"
import { Award, BookOpen, Calendar, Lightbulb } from 'lucide-react'
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { apiService } from "../../src/services/apiService"
import { Content } from "../../src/types/content.types"

export function IndividualDashboard() {
  const { user, loading: authLoading } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [recentContent, setRecentContent] = useState<Content[]>([])
  const [readContent, setReadContent] = useState<Content[]>([])

  useEffect(() => {
    if (!authLoading && (!user || user.role !== "individual")) {
      router.push("/login")
      return
    }
    
    if (user) {
      loadDashboardData()
    }
  }, [user, authLoading, router])

  const loadDashboardData = async () => {
    try {
      setLoading(true)
      
      // Load recent published content
      const contentResponse = await apiService.content.getPublishedContent({ 
        limit: 10 
      })
      // contentResponse is the array directly
      setRecentContent(contentResponse.slice(0, 5))

      // In a real app, you would track which content the user has read
      // For now, we'll simulate some read content
      setReadContent(contentResponse.slice(0, 3))

    } catch (error) {
      console.error('Error loading dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (authLoading || loading) {
    return <div className="flex items-center justify-center h-64">Loading dashboard...</div>
  }

  if (!user || user.role !== "individual") {
    return null
  }

  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-3xl font-bold">Welcome, {user.displayName || user.email}!</h1>
      <p className="text-lg text-muted-foreground">
        Here's your personalized dashboard with the latest insights and resources.
      </p>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Insights Read"
          value={readContent.length.toString()}
          description="Total articles and reports viewed"
          icon={<BookOpen className="h-5 w-5 text-muted-foreground" />}
        />
        <StatCard
          title="Available Content"
          value={recentContent.length.toString()}
          description="New insights available to read"
          icon={<Lightbulb className="h-5 w-5 text-muted-foreground" />}
        />
        <StatCard
          title="Upcoming Events"
          value="0"
          description="Events you've registered for"
          icon={<Calendar className="h-5 w-5 text-muted-foreground" />}
        />
        <StatCard
          title="Certifications"
          value="0"
          description="Completed programs"
          icon={<Award className="h-5 w-5 text-muted-foreground" />}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recommended for You</CardTitle>
          </CardHeader>
          <CardContent>
            {recentContent.length > 0 ? (
              <ul className="space-y-2">
                {recentContent.slice(0, 5).map((content) => (
                  <li key={content.id} className="flex justify-between items-center">
                    <span className="truncate">{content.title}</span>
                    <span className="text-sm text-muted-foreground">
                      {content.type}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground">No content available at the moment.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recently Read</CardTitle>
          </CardHeader>
          <CardContent>
            {readContent.length > 0 ? (
              <ul className="space-y-2">
                {readContent.map((content) => (
                  <li key={content.id} className="flex justify-between items-center">
                    <span className="truncate">{content.title}</span>
                    <span className="text-sm text-muted-foreground">
                      {new Date(content.createdAt).toLocaleDateString()}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground">No reading history yet.</p>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-2">
        <Button onClick={() => router.push("/insights")}>Explore Insights</Button>
        <Button variant="outline" onClick={() => router.push("/events")}>View Events</Button>
        <Button variant="outline" onClick={() => router.push("/library")}>Browse Library</Button>
      </div>
    </div>
  )
}
