"use client"

import { StatCard } from "@/components/dashboard/StatCard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/contexts/AuthContext"
import { Briefcase, CheckCircle, Clock, Users } from 'lucide-react'
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { apiService } from "../../src/services/apiService"
import { Content } from "../../src/types/content.types"
import { Task } from "../../src/types/task.types"

export function MemberDashboard() {
  const { user, company, loading: authLoading } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [recentContent, setRecentContent] = useState<Content[]>([])
  const [myTasks, setMyTasks] = useState<Task[]>([])
  const [companyName, setCompanyName] = useState("Your Company")

  useEffect(() => {
    if (!authLoading && (!user || user.role !== "member" || !user.companyId)) {
      router.push("/login")
      return
    }
    
    if (user?.companyId) {
      loadDashboardData()
    }
  }, [user, authLoading, router])

  const loadDashboardData = async () => {
    if (!user?.companyId) return

    try {
      setLoading(true)
      
      // Load company data
      if (company) {
        setCompanyName(company.name)
      } else {
        const companyResponse = await apiService.companies.getById(user.companyId)
        setCompanyName(companyResponse.data.name)
      }

      // Load recent content
      try {
        const contentResponse = await apiService.content.getPublishedContent({ limit: 5 })
        setRecentContent(contentResponse.slice(0, 3))
      } catch (error) {
        console.error('Error loading content:', error)
      }

      // Load user's tasks
      try {
        const tasksResponse = await apiService.tasks.getAll({ 
          assignedTo: user.uid,
          limit: 10 
        })
        // Corrected: The tasks array is in the 'data' property
        setMyTasks(tasksResponse.data)
      } catch (error) {
        console.error('Error loading tasks:', error)
      }

    } catch (error) {
      console.error('Error loading dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (authLoading || loading) {
    return <div className="flex items-center justify-center h-64">Loading dashboard...</div>
  }

  if (!user || user.role !== "member" || !user.companyId) {
    return null
  }

  const completedTasks = myTasks.filter(task => task.status === "completed").length
  const pendingTasks = myTasks.filter(task => task.status === "pending").length
  const inProgressTasks = myTasks.filter(task => task.status === "in_progress").length

  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-3xl font-bold">Welcome, {user.displayName || user.email}!</h1>
      <p className="text-lg text-muted-foreground">
        You are a member of {companyName}. Here's an overview of your activities.
      </p>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="My Tasks"
          value={myTasks.length.toString()}
          description={`${completedTasks} completed, ${inProgressTasks} in progress`}
          icon={<Briefcase className="h-5 w-5 text-muted-foreground" />}
        />
        <StatCard
          title="Pending Tasks"
          value={pendingTasks.toString()}
          description="Tasks awaiting your attention"
          icon={<Clock className="h-5 w-5 text-muted-foreground" />}
        />
        <StatCard
          title="Completed Tasks"
          value={completedTasks.toString()}
          description="Tasks you've finished"
          icon={<CheckCircle className="h-5 w-5 text-muted-foreground" />}
        />
        <StatCard
          title="Team Members"
          value={company?.memberIds.length.toString() || "0"}
          description="Total members in your organization"
          icon={<Users className="h-5 w-5 text-muted-foreground" />}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Company Content</CardTitle>
          </CardHeader>
          <CardContent>
            {recentContent.length > 0 ? (
              <ul className="space-y-2">
                {recentContent.map((content) => (
                  <li key={content.id} className="flex justify-between items-center">
                    <span className="truncate">{content.title}</span>
                    <span className="text-sm text-muted-foreground">
                      {new Date(content.createdAt).toLocaleDateString()}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground">No recent content available.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>My Recent Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            {myTasks.length > 0 ? (
              <ul className="space-y-2">
                {myTasks.slice(0, 5).map((task) => (
                  <li key={task.id} className="flex justify-between items-center">
                    <span className="truncate">{task.title}</span>
                    <span className={`text-sm px-2 py-1 rounded ${
                      task.status === 'completed' ? 'bg-green-100 text-green-800' :
                      task.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {task.status}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground">No tasks assigned to you.</p>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-2">
        <Button onClick={() => router.push(`/company/${user.companyId}/tasks`)}>
          View My Tasks
        </Button>
        <Button variant="outline" onClick={() => router.push(`/company/${user.companyId}/team`)}>
          View Team
        </Button>
        <Button variant="outline" onClick={() => router.push("/insights")}>
          Browse Insights
        </Button>
      </div>
    </div>
  )
}