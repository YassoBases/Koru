"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Linkedin, Youtube } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center">
              <Image src="/images/koru-logo.png" alt="Koru Impact" width={120} height={40} className="h-8 w-auto" />
            </Link>
            <p className="text-sm text-gray-600 leading-relaxed">
              Transforming organizations through evidence-first methodologies and actionable insights that drive
              sustainable change.
            </p>
            <div className="flex space-x-4">
              <Link
                href="https://www.linkedin.com/company/koru-impact/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-blue-600 transition-colors"
              >
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Link>
              <Link
                href="https://www.youtube.com/@koruimpact"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-red-600 transition-colors"
              >
                <Youtube className="h-5 w-5" />
                <span className="sr-only">YouTube</span>
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/our-approach" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
                  Our Approach
                </Link>
              </li>
              <li>
                <Link
                  href="/lighthouse-project"
                  className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
                >
                  The Lighthouse Project
                </Link>
              </li>
              <li>
                <Link href="/insights" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
                  Insights
                </Link>
              </li>
              <li>
                <Link href="/case-studies" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
                  Case Studies
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
                  About Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Contact</h3>
            <div className="space-y-2">
              <p className="text-sm text-gray-600">
                <span className="block">hello@koruimpact.org</span>
              </p>
              <p className="text-sm text-gray-600">
                <span className="block">+90 (555) 123-4567</span>
              </p>
              <p className="text-sm text-gray-600">
                <span className="block">Maltepe, Istanbul</span>
                <span className="block">Turkey</span>
              </p>
            </div>
          </div>

          {/* Stay Updated */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Stay Updated</h3>
            <p className="text-sm text-gray-600 mb-4">
              Subscribe to our newsletter for the latest insights and updates.
            </p>
            <form className="space-y-2">
              <Input type="email" placeholder="Enter your email" className="w-full" />
              <Button type="submit" className="w-full">
                Subscribe
              </Button>
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-8 border-t border-gray-200 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-500">© 2024 Koru Impact. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="/privacy-policy" className="text-sm text-gray-500 hover:text-gray-700 transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms-of-service" className="text-sm text-gray-500 hover:text-gray-700 transition-colors">
              Terms of Service
            </Link>
            <Link href="/login" className="text-sm text-gray-500 hover:text-gray-700 transition-colors">
              Staff Portal
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
