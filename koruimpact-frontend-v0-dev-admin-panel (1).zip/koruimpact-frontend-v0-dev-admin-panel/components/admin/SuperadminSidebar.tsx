// components/admin/SuperadminSidebar.tsx
"use client"

import { Button } from "@/components/ui/button"
import { useAuth } from "@/contexts/AuthContext"
import { cn } from "@/lib/utils"
import { Briefcase, Building, LayoutDashboard, LogOut, Settings, Users } from 'lucide-react'
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"

export function SuperadminSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { user, logout } = useAuth()

  const navItems = [
    {
      name: "Admin Dashboard",
      href: `/admin`, 
      icon: LayoutDashboard,
    },
    {
      name: "User Management",
      href: `/superadmin/users`,
      icon: Users,
    },
    {
      name: "Company Management",
      href: `/superadmin/companies`,
      icon: Building,
    },
    {
      name: "Settings",
      href: `/admin/settings`, 
      icon: Settings,
    },
  ]

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  return (
    <div className="hidden border-r bg-muted/40 lg:block">
      <div className="flex h-full max-h-screen flex-col gap-2">
        <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
          <Link href={`/admin`} className="flex items-center gap-2 font-semibold">
            <Briefcase className="h-6 w-6" />
            <span className="">Superadmin Panel</span>
          </Link>
        </div>
        <div className="flex-1">
          <nav className="grid items-start px-2 text-sm font-medium lg:px-4">
            {navItems.map((item) => {
                const isActive = pathname.startsWith(item.href)
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                      isActive && "bg-muted text-primary"
                    )}
                  >
                    <item.icon className="h-4 w-4" />
                    {item.name}
                  </Link>
                )
            })}
          </nav>
        </div>
        <div className="mt-auto p-4">
          <Button variant="secondary" className="w-full" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  )
}