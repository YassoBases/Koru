"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Play } from "lucide-react"
import Link from "next/link"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-koru-blue-50 via-white to-koru-green-50 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-72 h-72 bg-koru-blue-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-koru-green-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-1/2 w-72 h-72 bg-koru-gold-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-4000"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-5xl mx-auto text-center">
          {/* Main Headline */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-koru-blue-900 mb-8 leading-tight animate-fade-in">
            Transforming Organizations Through{" "}
            <span className="bg-gradient-to-r from-koru-green-600 to-koru-blue-600 bg-clip-text text-transparent">
              Evidence-First
            </span>{" "}
            Methodologies
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-koru-blue-700 mb-12 max-w-4xl mx-auto leading-relaxed animate-fade-in animation-delay-300">
            We partner with forward-thinking leaders to build psychologically safe, resilient organizations where people
            thrive and sustainable impact flourishes.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16 animate-fade-in animation-delay-600">
            <Button
              asChild
              size="lg"
              className="bg-gradient-to-r from-koru-gold-500 to-koru-gold-600 hover:from-koru-gold-600 hover:to-koru-gold-700 text-white font-semibold px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 focus:ring-4 focus:ring-koru-gold-200"
            >
              <Link href="/contact" className="flex items-center gap-2">
                Start Your Transformation
                <ArrowRight className="w-5 h-5" aria-hidden="true" />
              </Link>
            </Button>

            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-2 border-koru-blue-300 text-koru-blue-700 hover:bg-koru-blue-50 hover:border-koru-blue-400 font-semibold px-8 py-4 text-lg rounded-full shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 focus:ring-4 focus:ring-koru-blue-200 bg-transparent"
            >
              <Link href="/our-approach" className="flex items-center gap-2">
                <Play className="w-5 h-5" aria-hidden="true" />
                Explore Our Approach
              </Link>
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="animate-fade-in animation-delay-900">
            <p className="text-koru-blue-600 font-medium mb-6">
              Trusted by organizations committed to sustainable change
            </p>
            <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
              <div className="text-koru-blue-500 font-semibold">Evidence-Based</div>
              <div className="w-2 h-2 bg-koru-blue-300 rounded-full"></div>
              <div className="text-koru-blue-500 font-semibold">Systemic Approach</div>
              <div className="w-2 h-2 bg-koru-blue-300 rounded-full"></div>
              <div className="text-koru-blue-500 font-semibold">Sustainable Impact</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-koru-blue-300 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-koru-blue-400 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  )
}
