"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  ArrowRight,
  ArrowLeft,
  CheckCircle,
  User,
  Building,
  Target,
  MessageSquare,
  Users,
  Shield,
  TrendingUp,
  Lightbulb,
  Settings,
  Heart,
  Zap,
} from "lucide-react"

interface FormData {
  // Step 1: Basic Info
  fullName: string
  email: string
  company: string
  role: string
  phone: string

  // Step 2: Area of Interest
  servicesOfInterest: string[]
  primaryChallenge: string

  // Step 3: Context (varies by service)
  organizationSize: string
  timeline: string
  budget: string
  previousExperience: string
  specificGoals: string

  // Step 4: Message
  message: string
  preferredContact: string
  urgency: string
}

const initialFormData: FormData = {
  fullName: "",
  email: "",
  company: "",
  role: "",
  phone: "",
  servicesOfInterest: [],
  primaryChallenge: "",
  organizationSize: "",
  timeline: "",
  budget: "",
  previousExperience: "",
  specificGoals: "",
  message: "",
  preferredContact: "email",
  urgency: "standard",
}

const services = [
  {
    id: "psychological-safety",
    name: "Psychological Safety Diagnostic",
    icon: Shield,
    description: "Measure and improve team psychological safety",
  },
  {
    id: "burnout-prevention",
    name: "Burnout Prevention & Recovery",
    icon: Heart,
    description: "Prevent and address organizational burnout",
  },
  {
    id: "culture-assessment",
    name: "Culture Assessment",
    icon: Users,
    description: "Comprehensive organizational culture analysis",
  },
  {
    id: "leadership-development",
    name: "Leadership Development",
    icon: TrendingUp,
    description: "Evidence-based leadership transformation",
  },
  {
    id: "change-management",
    name: "Change Management",
    icon: Settings,
    description: "Strategic organizational change support",
  },
  {
    id: "lighthouse-project",
    name: "The Lighthouse Project",
    icon: Lightbulb,
    description: "Research partnership opportunities",
  },
  {
    id: "custom-consultation",
    name: "Custom Consultation",
    icon: Zap,
    description: "Tailored organizational solutions",
  },
]

const roles = [
  "CEO/Founder",
  "Chief People Officer",
  "HR Director",
  "VP of People",
  "Organizational Development",
  "Team Lead/Manager",
  "Consultant",
  "Other",
]

export function ProgressiveContactForm() {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const [showAbandonmentModal, setShowAbandonmentModal] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  // Save form data to localStorage
  useEffect(() => {
    const savedData = localStorage.getItem("koruContactForm")
    if (savedData) {
      const parsed = JSON.parse(savedData)
      if (parsed.timestamp && Date.now() - parsed.timestamp < 24 * 60 * 60 * 1000) {
        setFormData(parsed.data)
        setCurrentStep(parsed.step)
        if (parsed.step > 1) {
          setShowAbandonmentModal(true)
        }
      }
    }
  }, [])

  useEffect(() => {
    if (
      currentStep > 1 ||
      Object.values(formData).some((value) => (Array.isArray(value) ? value.length > 0 : value !== ""))
    ) {
      localStorage.setItem(
        "koruContactForm",
        JSON.stringify({
          data: formData,
          step: currentStep,
          timestamp: Date.now(),
        }),
      )
    }
  }, [formData, currentStep])

  const updateFormData = (field: keyof FormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleServiceToggle = (serviceId: string) => {
    const current = formData.servicesOfInterest
    const updated = current.includes(serviceId) ? current.filter((id) => id !== serviceId) : [...current, serviceId]
    updateFormData("servicesOfInterest", updated)
  }

  const getStepProgress = () => (currentStep / 4) * 100

  const canProceedFromStep = (step: number) => {
    switch (step) {
      case 1:
        return formData.fullName && formData.email && formData.company && formData.role
      case 2:
        return formData.servicesOfInterest.length > 0
      case 3:
        return formData.organizationSize && formData.timeline
      case 4:
        return formData.message.length > 10
      default:
        return false
    }
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsSubmitted(true)
    localStorage.removeItem("koruContactForm")
    setIsSubmitting(false)
  }

  const getContextQuestions = () => {
    const primaryService = formData.servicesOfInterest[0]

    switch (primaryService) {
      case "psychological-safety":
        return {
          title: "Psychological Safety Context",
          questions: [
            {
              key: "specificGoals",
              label: "What specific psychological safety challenges are you facing?",
              type: "textarea",
            },
            {
              key: "previousExperience",
              label: "Have you measured psychological safety before?",
              type: "select",
              options: [
                "No, this is our first time",
                "Yes, with basic surveys",
                "Yes, with comprehensive assessments",
                "We've tried but weren't satisfied with results",
              ],
            },
          ],
        }
      case "burnout-prevention":
        return {
          title: "Burnout Prevention Context",
          questions: [
            {
              key: "specificGoals",
              label: "What burnout indicators are you seeing in your organization?",
              type: "textarea",
            },
            {
              key: "previousExperience",
              label: "What approaches have you tried for burnout prevention?",
              type: "select",
              options: [
                "None yet",
                "Wellness programs",
                "Workload management",
                "Mental health resources",
                "Comprehensive burnout strategy",
              ],
            },
          ],
        }
      case "culture-assessment":
        return {
          title: "Culture Assessment Context",
          questions: [
            {
              key: "specificGoals",
              label: "What aspects of your culture do you want to understand better?",
              type: "textarea",
            },
            {
              key: "previousExperience",
              label: "Have you conducted culture assessments before?",
              type: "select",
              options: [
                "No previous assessments",
                "Basic employee surveys",
                "Comprehensive culture studies",
                "Multiple assessments over time",
              ],
            },
          ],
        }
      default:
        return {
          title: "Project Context",
          questions: [
            { key: "specificGoals", label: "What are your primary goals for this engagement?", type: "textarea" },
            {
              key: "previousExperience",
              label: "What's your experience with organizational consulting?",
              type: "select",
              options: [
                "First time working with consultants",
                "Some experience with consultants",
                "Extensive experience with consultants",
                "We have internal OD capabilities",
              ],
            },
          ],
        }
    }
  }

  if (isSubmitted) {
    return (
      <Card className="max-w-2xl mx-auto bg-gradient-to-br from-koru-green-50 to-koru-blue-50 border-koru-green-200">
        <CardContent className="p-8 text-center">
          <CheckCircle className="w-16 h-16 text-koru-green-600 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-gray-800 mb-4 font-heading">Thank You!</h3>
          <p className="text-gray-600 mb-6 font-body">
            We've received your message and will get back to you within 24 hours. Our team is excited to discuss how we
            can help transform your organization.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild className="bg-koru-blue-600 hover:bg-koru-blue-700">
              <a href="/our-approach">Learn About Our Methodology</a>
            </Button>
            <Button variant="outline" asChild>
              <a href="/journal">Read Our Latest Insights</a>
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <Card className="max-w-4xl mx-auto bg-white shadow-2xl border-0">
        <CardHeader className="bg-gradient-to-r from-koru-blue-600 to-koru-green-500 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl font-heading">Send us a Message</CardTitle>
              <p className="text-koru-blue-100 font-body">
                Tell us about your organization and how we can help you achieve sustainable transformation.
              </p>
            </div>
            <Badge variant="secondary" className="bg-white/20 text-white">
              Step {currentStep} of 4
            </Badge>
          </div>
          <Progress value={getStepProgress()} className="mt-4 bg-white/20" />
        </CardHeader>

        <CardContent className="p-8">
          {/* Step 1: Basic Information */}
          {currentStep === 1 && (
            <div className="space-y-6 animate-in fade-in-50 duration-500">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-koru-blue-100 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-koru-blue-600" />
                </div>
                <h3 className="text-xl font-semibold font-heading">Let's start with the basics</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="fullName" className="font-semibold">
                    Full Name *
                  </Label>
                  <Input
                    id="fullName"
                    value={formData.fullName}
                    onChange={(e) => updateFormData("fullName", e.target.value)}
                    className="mt-2"
                    placeholder="Your full name"
                  />
                </div>

                <div>
                  <Label htmlFor="email" className="font-semibold">
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => updateFormData("email", e.target.value)}
                    className="mt-2"
                    placeholder="your.email@company.com"
                  />
                </div>

                <div>
                  <Label htmlFor="company" className="font-semibold">
                    Company/Organization *
                  </Label>
                  <Input
                    id="company"
                    value={formData.company}
                    onChange={(e) => updateFormData("company", e.target.value)}
                    className="mt-2"
                    placeholder="Your organization name"
                  />
                </div>

                <div>
                  <Label htmlFor="role" className="font-semibold">
                    Your Role *
                  </Label>
                  <Select value={formData.role} onValueChange={(value) => updateFormData("role", value)}>
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select your role" />
                    </SelectTrigger>
                    <SelectContent>
                      {roles.map((role) => (
                        <SelectItem key={role} value={role}>
                          {role}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="phone" className="font-semibold">
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => updateFormData("phone", e.target.value)}
                    className="mt-2"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Services of Interest */}
          {currentStep === 2 && (
            <div className="space-y-6 animate-in fade-in-50 duration-500">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-koru-green-100 rounded-full flex items-center justify-center">
                  <Target className="w-5 h-5 text-koru-green-600" />
                </div>
                <h3 className="text-xl font-semibold font-heading">What can we help you with?</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {services.map((service) => {
                  const IconComponent = service.icon
                  const isSelected = formData.servicesOfInterest.includes(service.id)

                  return (
                    <Card
                      key={service.id}
                      className={`cursor-pointer transition-all duration-300 hover:shadow-lg ${
                        isSelected
                          ? "ring-2 ring-koru-blue-500 bg-koru-blue-50 border-koru-blue-200"
                          : "hover:border-koru-blue-300"
                      }`}
                      onClick={() => handleServiceToggle(service.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <Checkbox
                            checked={isSelected}
                            onChange={() => handleServiceToggle(service.id)}
                            className="mt-1"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <IconComponent className="w-5 h-5 text-koru-blue-600" />
                              <h4 className="font-semibold font-heading text-sm">{service.name}</h4>
                            </div>
                            <p className="text-sm text-gray-600 font-body">{service.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>

              <div>
                <Label htmlFor="primaryChallenge" className="font-semibold">
                  What's your primary organizational challenge right now?
                </Label>
                <Textarea
                  id="primaryChallenge"
                  value={formData.primaryChallenge}
                  onChange={(e) => updateFormData("primaryChallenge", e.target.value)}
                  className="mt-2"
                  placeholder="Describe the main challenge you're facing..."
                  rows={3}
                />
              </div>
            </div>
          )}

          {/* Step 3: Context Questions */}
          {currentStep === 3 && (
            <div className="space-y-6 animate-in fade-in-50 duration-500">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-koru-gold-100 rounded-full flex items-center justify-center">
                  <Building className="w-5 h-5 text-koru-gold-600" />
                </div>
                <h3 className="text-xl font-semibold font-heading">{getContextQuestions().title}</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="organizationSize" className="font-semibold">
                    Organization Size *
                  </Label>
                  <Select
                    value={formData.organizationSize}
                    onValueChange={(value) => updateFormData("organizationSize", value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select organization size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="startup">Startup (1-50 employees)</SelectItem>
                      <SelectItem value="small">Small (51-200 employees)</SelectItem>
                      <SelectItem value="medium">Medium (201-1000 employees)</SelectItem>
                      <SelectItem value="large">Large (1000+ employees)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="timeline" className="font-semibold">
                    Preferred Timeline *
                  </Label>
                  <Select value={formData.timeline} onValueChange={(value) => updateFormData("timeline", value)}>
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select timeline" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="immediate">Immediate (within 1 month)</SelectItem>
                      <SelectItem value="short">Short-term (1-3 months)</SelectItem>
                      <SelectItem value="medium">Medium-term (3-6 months)</SelectItem>
                      <SelectItem value="long">Long-term (6+ months)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="budget" className="font-semibold">
                    Budget Range
                  </Label>
                  <Select value={formData.budget} onValueChange={(value) => updateFormData("budget", value)}>
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select budget range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="under-25k">Under $25,000</SelectItem>
                      <SelectItem value="25k-50k">$25,000 - $50,000</SelectItem>
                      <SelectItem value="50k-100k">$50,000 - $100,000</SelectItem>
                      <SelectItem value="100k-plus">$100,000+</SelectItem>
                      <SelectItem value="discuss">Prefer to discuss</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {getContextQuestions().questions.map((question) => (
                <div key={question.key}>
                  <Label htmlFor={question.key} className="font-semibold">
                    {question.label}
                  </Label>
                  {question.type === "textarea" ? (
                    <Textarea
                      id={question.key}
                      value={formData[question.key as keyof FormData] as string}
                      onChange={(e) => updateFormData(question.key as keyof FormData, e.target.value)}
                      className="mt-2"
                      rows={3}
                    />
                  ) : (
                    <Select
                      value={formData[question.key as keyof FormData] as string}
                      onValueChange={(value) => updateFormData(question.key as keyof FormData, value)}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue placeholder="Select an option" />
                      </SelectTrigger>
                      <SelectContent>
                        {question.options?.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Step 4: Final Message */}
          {currentStep === 4 && (
            <div className="space-y-6 animate-in fade-in-50 duration-500">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-koru-green-100 rounded-full flex items-center justify-center">
                  <MessageSquare className="w-5 h-5 text-koru-green-600" />
                </div>
                <h3 className="text-xl font-semibold font-heading">Tell us more about your goals</h3>
              </div>

              <div>
                <Label htmlFor="message" className="font-semibold">
                  Message *
                </Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => updateFormData("message", e.target.value)}
                  className="mt-2"
                  placeholder="Tell us about your organization's challenges and goals..."
                  rows={6}
                />
                <p className="text-sm text-gray-500 mt-2">{formData.message.length}/500 characters</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="preferredContact" className="font-semibold">
                    Preferred Contact Method
                  </Label>
                  <Select
                    value={formData.preferredContact}
                    onValueChange={(value) => updateFormData("preferredContact", value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="phone">Phone</SelectItem>
                      <SelectItem value="video">Video Call</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="urgency" className="font-semibold">
                    Urgency Level
                  </Label>
                  <Select value={formData.urgency} onValueChange={(value) => updateFormData("urgency", value)}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low - General inquiry</SelectItem>
                      <SelectItem value="standard">Standard - Within a week</SelectItem>
                      <SelectItem value="high">High - Within 2-3 days</SelectItem>
                      <SelectItem value="urgent">Urgent - Within 24 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Summary */}
              <Card className="bg-gradient-to-br from-koru-blue-50 to-koru-green-50 border-koru-blue-200">
                <CardContent className="p-6">
                  <h4 className="font-semibold mb-4 font-heading">Summary of Your Request</h4>
                  <div className="space-y-2 text-sm">
                    <p>
                      <strong>Contact:</strong> {formData.fullName} ({formData.role}) at {formData.company}
                    </p>
                    <p>
                      <strong>Services:</strong>{" "}
                      {formData.servicesOfInterest.map((id) => services.find((s) => s.id === id)?.name).join(", ")}
                    </p>
                    <p>
                      <strong>Organization Size:</strong> {formData.organizationSize}
                    </p>
                    <p>
                      <strong>Timeline:</strong> {formData.timeline}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between items-center mt-8 pt-6 border-t">
            <Button
              variant="outline"
              onClick={() => setCurrentStep((prev) => prev - 1)}
              disabled={currentStep === 1}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Previous
            </Button>

            <div className="flex gap-2">
              {[1, 2, 3, 4].map((step) => (
                <div
                  key={step}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    step === currentStep ? "bg-koru-blue-600" : step < currentStep ? "bg-koru-green-500" : "bg-gray-300"
                  }`}
                />
              ))}
            </div>

            {currentStep < 4 ? (
              <Button
                onClick={() => setCurrentStep((prev) => prev + 1)}
                disabled={!canProceedFromStep(currentStep)}
                className="flex items-center gap-2 bg-koru-blue-600 hover:bg-koru-blue-700"
              >
                Next
                <ArrowRight className="w-4 h-4" />
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                disabled={!canProceedFromStep(currentStep) || isSubmitting}
                className="flex items-center gap-2 bg-koru-gold-500 hover:bg-koru-gold-600 text-koru-blue-900 font-semibold"
              >
                {isSubmitting ? "Sending..." : "Send Message"}
                <ArrowRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Abandonment Recovery Modal */}
      <Dialog open={showAbandonmentModal} onOpenChange={setShowAbandonmentModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Continue where you left off?</DialogTitle>
            <DialogDescription>
              We found a partially completed form. Would you like to continue from where you left off or start fresh?
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-4 mt-4">
            <Button onClick={() => setShowAbandonmentModal(false)} className="flex-1">
              Continue
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setFormData(initialFormData)
                setCurrentStep(1)
                setShowAbandonmentModal(false)
                localStorage.removeItem("koruContactForm")
              }}
              className="flex-1"
            >
              Start Fresh
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
