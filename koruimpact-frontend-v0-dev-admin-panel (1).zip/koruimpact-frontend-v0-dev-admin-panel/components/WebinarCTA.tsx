import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PlayCircle } from 'lucide-react'

export function WebinarCTA() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <Card className="w-full max-w-2xl text-center p-6">
            <CardHeader>
              <PlayCircle className="h-16 w-16 text-primary mx-auto mb-4" />
              <CardTitle className="text-3xl font-bold">
                Watch Our Latest Webinar
              </CardTitle>
              <CardDescription className="text-lg text-gray-600 dark:text-gray-400">
                "Building Resilient Teams: A Deep Dive into Psychological Safety"
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500 dark:text-gray-400 mb-6">
                Gain valuable insights from our experts on fostering an environment where your team can thrive.
              </p>
              <Button asChild size="lg">
                <Link href="#">Watch Now</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
