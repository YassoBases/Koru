import Image from "next/image"

export function SocialProof() {
  const logos = [
    "/placeholder.svg?height=40&width=120",
    "/placeholder.svg?height=40&width=120",
    "/placeholder.svg?height=40&width=120",
    "/placeholder.svg?height=40&width=120",
    "/placeholder.svg?height=40&width=120",
  ]

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50 dark:bg-gray-900">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl md:text-4xl text-gray-800 dark:text-gray-200">
            Trusted by Leading Organizations
          </h2>
          <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
            We partner with innovative companies to drive meaningful change and foster thriving workplaces.
          </p>
        </div>
        <div className="flex flex-wrap justify-center items-center gap-8 mt-10">
          {logos.map((logo, index) => (
            <Image
              key={index}
              src={logo || "/placeholder.svg"}
              alt={`Client Logo ${index + 1}`}
              width={120}
              height={40}
              className="object-contain h-10 w-auto opacity-70 hover:opacity-100 transition-opacity duration-300"
            />
          ))}
        </div>
      </div>
    </section>
  )
}
