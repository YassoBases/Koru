import { Card, CardContent } from "@/components/ui/card"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"
import Image from "next/image"

export function EnhancedTestimonials() {
  const testimonials = [
    {
      quote: "Koru Impact transformed our team dynamics. The psychological safety workshops were a game-changer for our communication and innovation.",
      author: "Jane Doe",
      title: "CEO, Tech Innovators Inc.",
      avatar: "/placeholder-user.jpg",
    },
    {
      quote: "Their evidence-first approach to leadership development provided our managers with actionable insights that led to measurable improvements in team performance.",
      author: "John Smith",
      title: "HR Director, Global Solutions",
      avatar: "/placeholder-user.jpg",
    },
    {
      quote: "The change management consulting from Koru Impact was instrumental in our successful organizational restructuring. Highly recommend their expertise.",
      author: "Emily White",
      title: "COO, Future Forward Corp.",
      avatar: "/placeholder-user.jpg",
    },
    {
      quote: "Koru Impact helped us identify and address the root causes of burnout in our organization. Our employee well-being scores have significantly improved.",
      author: "Michael Brown",
      title: "VP of Operations, HealthTech Innovations",
      avatar: "/placeholder-user.jpg",
    },
  ]

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              What Our Clients Say
            </h2>
            <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              Hear from leaders and organizations who have experienced transformative results with Koru Impact.
            </p>
          </div>
        </div>
        <div className="mt-10 w-full max-w-5xl mx-auto">
          <Carousel
            opts={{
              align: "start",
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent>
              {testimonials.map((testimonial, index) => (
                <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
                  <div className="p-1">
                    <Card className="h-full flex flex-col justify-between">
                      <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                        <QuoteIcon className="h-8 w-8 text-gray-400 dark:text-gray-600 mb-4" />
                        <p className="text-lg font-medium leading-relaxed text-gray-700 dark:text-gray-300 mb-6">
                          {testimonial.quote}
                        </p>
                        <div className="flex items-center space-x-4">
                          <Image
                            src={testimonial.avatar || "/placeholder.svg"}
                            width={56}
                            height={56}
                            alt={`Avatar of ${testimonial.author}`}
                            className="rounded-full object-cover"
                          />
                          <div>
                            <p className="text-base font-semibold text-gray-900 dark:text-gray-100">
                              {testimonial.author}
                            </p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              {testimonial.title}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious />
            <CarouselNext />
          </Carousel>
        </div>
      </div>
    </section>
  )
}

function QuoteIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 21c0-4.2 4-7 8-7" />
      <path d="M15 21c0-4.2 4-7 8-7" />
      <path d="M7 14q-.5-1.5-2-2.5L2 7" />
      <path d="M19 14q-.5-1.5-2-2.5L14 7" />
    </svg>
  )
}
