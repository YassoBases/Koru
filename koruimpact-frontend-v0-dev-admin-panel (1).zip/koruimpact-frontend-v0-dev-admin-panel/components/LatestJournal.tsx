import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

export function LatestJournal() {
  const latestEntries = [
    {
      id: "1",
      title: "The Power of Psychological Safety in Hybrid Teams",
      date: "October 20, 2024",
      author: "Dr. Alex Johnson",
      description: "Discover how fostering psychological safety can unlock innovation and collaboration in remote and hybrid work environments.",
      image: "/public/images/psychological-safety-guide.png",
      slug: "the-power-of-psychological-safety-in-hybrid-teams",
    },
    {
      id: "2",
      title: "Navigating Organizational Change with Empathy",
      date: "September 15, 2024",
      author: "Sarah Lee",
      description: "A guide to leading change initiatives with a human-centered approach, minimizing resistance and maximizing adoption.",
      image: "/placeholder.svg?height=200&width=300",
      slug: "navigating-organizational-change-with-empathy",
    },
    {
      id: "3",
      title: "Burnout Prevention: Strategies for Sustainable Performance",
      date: "August 28, 2024",
      author: "Michael Chen",
      description: "Practical strategies for individuals and organizations to combat burnout and maintain long-term well-being and productivity.",
      image: "/public/images/burnout-prevention-leadership.png",
      slug: "burnout-prevention-strategies-for-sustainable-performance",
    },
  ]

  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Latest from Our Journal
            </h2>
            <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              Stay informed with our most recent publications and thought leadership on organizational development.
            </p>
          </div>
        </div>
        <div className="grid gap-6 lg:grid-cols-3 mt-10">
          {latestEntries.map((entry) => (
            <Card key={entry.id} className="flex flex-col">
              <CardHeader>
                <Image
                  src={entry.image || "/placeholder.svg"}
                  alt={entry.title}
                  width={300}
                  height={200}
                  className="aspect-video object-cover rounded-md mb-4"
                />
                <CardTitle className="text-xl font-bold">{entry.title}</CardTitle>
                <CardDescription className="text-sm text-gray-500">
                  {entry.date} by {entry.author}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1">
                <p className="text-sm text-gray-600 dark:text-gray-400">{entry.description}</p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href={`/journal/${entry.slug}`}>Read More</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        <div className="flex justify-center mt-10">
          <Button asChild variant="outline">
            <Link href="/journal">View All Journal Entries</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
