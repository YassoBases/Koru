import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Lightbulb, Users, TrendingDown, ShieldOff } from 'lucide-react'

export function KeyChallenges() {
  const challenges = [
    {
      icon: Users,
      title: "Team Cohesion & Collaboration",
      description: "Bridging gaps in communication and trust to foster a more unified and productive workforce.",
    },
    {
      icon: TrendingDown,
      title: "Burnout & Employee Well-being",
      description: "Addressing the rising tide of burnout to ensure sustainable performance and a healthy work-life balance.",
    },
    {
      icon: ShieldOff,
      title: "Lack of Psychological Safety",
      description: "Creating environments where employees feel safe to speak up, take risks, and innovate without fear of negative repercussions.",
    },
    {
      icon: Lightbulb,
      title: "Ineffective Leadership & Change Management",
      description: "Equipping leaders with the skills to navigate complex organizational changes and inspire their teams through uncertainty.",
    },
  ]

  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Addressing Your Key Challenges
            </h2>
            <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              We partner with organizations to tackle critical issues hindering growth and well-being.
            </p>
          </div>
        </div>
        <div className="grid gap-6 lg:grid-cols-2 xl:grid-cols-4 mt-10">
          {challenges.map((challenge, index) => (
            <Card key={index} className="flex flex-col items-center text-center p-6">
              <CardHeader>
                <div className="bg-primary/10 p-3 rounded-full mb-4">
                  <challenge.icon className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-xl font-bold">{challenge.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500 dark:text-gray-400">{challenge.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
