import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import { Lightbulb, Users, TrendingUp } from 'lucide-react'

export function LighthouseProjectHighlight() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Our Impact in Action: The Lighthouse Project
            </h2>
            <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              See how our evidence-first approach delivers measurable results for real organizations.
            </p>
          </div>
        </div>
        <div className="grid gap-8 lg:grid-cols-2 xl:grid-cols-2 mt-10">
          <Image
            src="/placeholder.svg?height=400&width=600"
            width={600}
            height={400}
            alt="Lighthouse Project Case Study"
            className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center"
          />
          <div className="flex flex-col justify-center space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl font-bold">Challenge</CardTitle>
                <CardDescription>
                  A rapidly scaling tech company faced significant challenges with employee retention and declining morale due to a lack of psychological safety and effective leadership.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  <div className="flex items-start gap-3">
                    <Lightbulb className="h-6 w-6 text-primary shrink-0" />
                    <div>
                      <h3 className="font-semibold">Our Solution</h3>
                      <p className="text-gray-500 dark:text-gray-400">
                        Implemented a comprehensive psychological safety diagnostic, followed by tailored leadership development programs and team-building initiatives.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <TrendingUp className="h-6 w-6 text-primary shrink-0" />
                    <div>
                      <h3 className="font-semibold">Measurable Impact</h3>
                      <p className="text-gray-500 dark:text-gray-400">
                        Achieved a 25% increase in employee retention and a 40% improvement in psychological safety scores within 12 months.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Users className="h-6 w-6 text-primary shrink-0" />
                    <div>
                      <h3 className="font-semibold">Outcome</h3>
                      <p className="text-gray-500 dark:text-gray-400">
                        Transformed into a more cohesive, innovative, and high-performing organization.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <div className="flex justify-center lg:justify-start">
              <Button asChild>
                <Link href="/our-work/lighthouse-project">Read the Full Case Study</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
