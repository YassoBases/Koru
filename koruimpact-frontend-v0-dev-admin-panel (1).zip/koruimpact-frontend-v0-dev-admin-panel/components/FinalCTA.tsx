import { Button } from "@/components/ui/button"
import { Calendar, Download, ArrowRight } from "lucide-react"
import Link from "next/link"

export function FinalCTA() {
  return (
    <section className="py-20 bg-gradient-to-br from-koru-blue-600 via-koru-blue-700 to-koru-green-700 text-white relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden" aria-hidden="true">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-koru-green-400/20 rounded-full blur-3xl animate-pulse"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center animate-fade-in">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">Ready to Transform Your Organization?</h2>
          <p className="text-xl mb-12 text-blue-100 leading-relaxed">
            Join our upcoming webinar to discover how evidence-based approaches can drive lasting change in your
            workplace. Register now for exclusive insights from our expert team.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center mb-8">
            <Button
              asChild
              size="lg"
              className="bg-koru-gold-500 hover:bg-koru-gold-600 text-gray-900 px-10 py-4 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105 shadow-xl hover:shadow-2xl focus:ring-4 focus:ring-koru-gold-200"
            >
              <Link href="/events">
                <Calendar className="w-5 h-5 mr-2" aria-hidden="true" />
                Register for Webinar
                <span className="sr-only">Register for our upcoming webinar</span>
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-2 border-white text-white hover:bg-white hover:text-koru-blue-700 px-10 py-4 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105 bg-transparent shadow-lg hover:shadow-xl focus:ring-4 focus:ring-white/20"
            >
              <Link href="/contact">
                <Download className="w-5 h-5 mr-2" aria-hidden="true" />
                Get Free Consultation
                <span className="sr-only">Schedule a free consultation</span>
              </Link>
            </Button>
          </div>

          {/* Additional value proposition */}
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 mb-8 border border-white/20">
            <h3 className="text-xl font-semibold mb-4">What You'll Get:</h3>
            <div className="grid md:grid-cols-3 gap-4 text-sm">
              <div className="flex items-center">
                <ArrowRight className="w-4 h-4 mr-2 text-koru-gold-400" aria-hidden="true" />
                Evidence-based insights
              </div>
              <div className="flex items-center">
                <ArrowRight className="w-4 h-4 mr-2 text-koru-gold-400" aria-hidden="true" />
                Cultural assessment tools
              </div>
              <div className="flex items-center">
                <ArrowRight className="w-4 h-4 mr-2 text-koru-gold-400" aria-hidden="true" />
                Implementation roadmap
              </div>
            </div>
          </div>

          <p className="text-blue-200">
            Join the growing community of organizations prioritizing both performance and well-being.
          </p>
        </div>
      </div>
    </section>
  )
}
