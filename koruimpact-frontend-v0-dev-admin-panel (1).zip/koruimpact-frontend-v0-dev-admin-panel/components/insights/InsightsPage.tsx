"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowRight, Filter, Search } from 'lucide-react'
import Image from "next/image"
import Link from "next/link"
import { useEffect, useState } from "react"
import { apiService } from "../../src/services/apiService"
import { Content } from "../../src/types/content.types"
import { LoadingSpinner } from "../LoadingSpinner"

// Helper function to convert Firestore timestamp
const formatFirestoreTimestamp = (timestamp: any) => {
  if (timestamp && timestamp._seconds) {
    return new Date(timestamp._seconds * 1000).toLocaleDateString();
  }
  // Fallback for string dates
  if (typeof timestamp === 'string') {
    return new Date(timestamp).toLocaleDateString();
  }
  return "Date not available";
};


export function InsightsPage() {
  const [insights, setInsights] = useState<Content[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterCategory, setFilterCategory] = useState("All")
  const [error, setError] = useState("")

  useEffect(() => {
    const loadInsights = async () => {
      try {
        setLoading(true)
        // This now correctly expects a direct array: Content[]
        const response = await apiService.content.getPublishedContent()
        // We set the state directly with the response array
        setInsights(response || [])
      } catch (err: any) {
        setError(err.message || "Failed to load insights")
        console.error('Error loading insights:', err)
      } finally {
        setLoading(false)
      }
    }

    loadInsights()
  }, [])

  const categories = ["All", ...Array.from(new Set(insights.flatMap(insight => insight.tags || [])))]

  const filteredInsights = insights.filter(insight => {
    const matchesSearch = insight.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (insight.content && insight.content.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesCategory = filterCategory === "All" || (insight.tags && insight.tags.includes(filterCategory))
    return matchesSearch && matchesCategory
  })

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8 md:px-6 lg:px-8">
        <div className="flex items-center justify-center h-64">
          <div className="text-lg text-destructive">{error}</div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 md:px-6 lg:px-8">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
          Koru Insights
        </h1>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
          Dive deep into our research, articles, and thought leadership on organizational development, leadership, and sustainable impact.
        </p>
      </header>

      <div className="mb-8 flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search insights..."
            className="w-full pl-10 pr-4 py-2 rounded-md border"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <select
            className="w-full md:w-auto pl-10 pr-4 py-2 rounded-md border bg-background appearance-none"
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
          >
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredInsights.length > 0 ? (
          filteredInsights.map((insight) => (
            <Card key={insight.id} className="flex flex-col overflow-hidden">
              <div className="relative h-40 w-full">
                <Image
                  src={insight.thumbnailUrl || "/placeholder.svg?height=200&width=300"}
                  alt={insight.title}
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
              <CardHeader className="pb-2">
                {insight.tags && insight.tags.length > 0 && (
                  <Badge variant="secondary" className="mb-2 w-fit">
                    {insight.tags[0]}
                  </Badge>
                )}
                <CardTitle className="text-xl font-semibold line-clamp-2">
                  <Link href={`/insights/${insight.id}`} className="hover:underline">
                    {insight.title}
                  </Link>
                </CardTitle>
                <CardDescription className="text-sm text-muted-foreground">
                  {formatFirestoreTimestamp(insight.createdAt)}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow flex flex-col justify-between">
                <p className="text-sm text-gray-600 line-clamp-3 mb-4" dangerouslySetInnerHTML={{ __html: insight.content.substring(0, 100) + '...' }} />
                <Link href={`/insights/${insight.id}`} className="inline-flex items-center text-primary hover:underline">
                  Read More <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="col-span-full text-center text-muted-foreground py-10">
            No insights found matching your criteria.
          </div>
        )}
      </div>
    </div>
  )
}
