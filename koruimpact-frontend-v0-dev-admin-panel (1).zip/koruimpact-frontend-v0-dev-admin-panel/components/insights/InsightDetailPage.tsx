"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { apiService } from "../../src/services/apiService"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft } from 'lucide-react'
import { Content } from "../../src/types/content.types"

export function InsightDetailPage({ id }: { id: string }) {
  const router = useRouter()
  const [insight, setInsight] = useState<Content | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    loadInsight()
  }, [id])

  const loadInsight = async () => {
    try {
      setLoading(true)
      const response = await apiService.content.getById(id)
      setInsight(response.content)
    } catch (err: any) {
      setError(err.message || "Failed to load insight")
      console.error('Error loading insight:', err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 md:px-6 lg:px-8 max-w-4xl">
        <div className="flex items-center justify-center h-64">
          <div className="text-lg">Loading insight...</div>
        </div>
      </div>
    )
  }

  if (error || !insight) {
    return (
      <div className="container mx-auto px-4 py-8 md:px-6 lg:px-8 max-w-4xl">
        <Button variant="ghost" onClick={() => router.back()} className="mb-6 flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" /> Back to Insights
        </Button>
        <div className="flex items-center justify-center h-64">
          <div className="text-lg text-destructive">{error || "Insight not found"}</div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 md:px-6 lg:px-8 max-w-4xl">
      <Button variant="ghost" onClick={() => router.back()} className="mb-6 flex items-center gap-2">
        <ArrowLeft className="h-4 w-4" /> Back to Insights
      </Button>

      <article className="prose prose-lg mx-auto dark:prose-invert">
        <div className="mb-6">
          <h1 className="text-4xl font-bold mb-4">{insight.title}</h1>
          <div className="flex items-center gap-4 mb-6">
            {insight.metadata?.category && (
              <Badge variant="secondary">{insight.metadata.category}</Badge>
            )}
            <p className="text-muted-foreground text-sm">
              {insight.publishedAt ? new Date(insight.publishedAt).toLocaleDateString() : new Date(insight.createdAt).toLocaleDateString()}
            </p>
            {insight.metadata?.readTime && (
              <p className="text-muted-foreground text-sm">
                {insight.metadata.readTime} min read
              </p>
            )}
          </div>
        </div>

        {insight.thumbnailUrl && (
          <div className="relative w-full h-80 mb-8 rounded-lg overflow-hidden">
            <Image
              src={insight.thumbnailUrl || "/placeholder.svg"}
              alt={insight.title}
              fill
              className="object-cover rounded-lg"
            />
          </div>
        )}

        {insight.description && (
          <div className="text-xl text-muted-foreground mb-8 font-medium">
            {insight.description}
          </div>
        )}

        <div 
          className="prose-content"
          dangerouslySetInnerHTML={{ __html: insight.content }} 
        />

        {insight.metadata?.tags && insight.metadata.tags.length > 0 && (
          <div className="mt-8 pt-8 border-t">
            <h3 className="text-lg font-semibold mb-4">Tags</h3>
            <div className="flex flex-wrap gap-2">
              {insight.metadata.tags.map((tag, index) => (
                <Badge key={index} variant="outline">{tag}</Badge>
              ))}
            </div>
          </div>
        )}
      </article>
    </div>
  )
}
