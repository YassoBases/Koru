import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, BookOpen, Users } from "lucide-react"
import Link from "next/link"

export function FeaturedSection() {
  return (
    <section className="py-20 bg-gradient-to-br from-white via-koru-blue-50 to-koru-green-50">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-7xl mx-auto">
          {/* Featured Article Card */}
          <Card className="group overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 border-0 bg-white/90 backdrop-blur-sm animate-slide-in-left">
            <div className="relative">
              <div className="absolute top-4 left-4 z-10">
                <Badge className="bg-koru-gold-500 hover:bg-koru-gold-600 text-white px-3 py-1 rounded-full text-sm font-semibold shadow-lg">
                  <BookOpen className="w-3 h-3 mr-1" aria-hidden="true" />
                  Trending
                </Badge>
              </div>
              <div
                className="h-64 bg-cover bg-center group-hover:scale-105 transition-transform duration-500"
                style={{
                  backgroundImage: `url('/placeholder.svg?height=400&width=600&text=Organizational+Psychology+Article')`,
                }}
                role="img"
                aria-label="Organizational psychology workplace transformation"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent group-hover:from-black/40 transition-all duration-300"></div>
            </div>
            <CardContent className="p-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-koru-blue-700 transition-colors duration-300">
                How Organizational Psychology Will Transform Your Workplace This Year
              </h3>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Discover the latest evidence-based approaches that are revolutionizing how organizations create
                psychologically safe and high-performing work environments.
              </p>
              <Button
                variant="outline"
                className="bg-white/80 border-koru-blue-300 text-koru-blue-700 hover:bg-koru-blue-50 hover:border-koru-blue-400 transition-all duration-300 hover:scale-105 focus:ring-4 focus:ring-koru-blue-200"
              >
                Read Now
                <ArrowRight className="ml-2 w-4 h-4" aria-hidden="true" />
                <span className="sr-only">Read the full article</span>
              </Button>
            </CardContent>
          </Card>

          {/* Online Programs */}
          <div className="space-y-8 animate-slide-in-right">
            <div className="text-center lg:text-left">
              <div className="flex items-center justify-center lg:justify-start mb-4">
                <Users className="w-8 h-8 text-koru-green-600 mr-3" aria-hidden="true" />
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Online Programs</h2>
              </div>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Get expert guidance for your organization from the comfort of your workplace. Our evidence-based
                programs deliver measurable results.
              </p>
            </div>

            <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
              <Button
                variant="default"
                size="lg"
                className="bg-koru-blue-600 hover:bg-koru-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 focus:ring-4 focus:ring-koru-blue-200"
              >
                Leadership Programs 2025
                <span className="sr-only">Explore our leadership development programs</span>
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-koru-green-400 text-koru-green-700 hover:bg-koru-green-50 hover:border-koru-green-500 bg-white/80 transition-all duration-300 hover:scale-105 focus:ring-4 focus:ring-koru-green-200"
              >
                Culture Assessment
                <span className="sr-only">Learn about our culture assessment tools</span>
              </Button>
            </div>

            <div className="bg-white/70 backdrop-blur-sm rounded-xl p-6 border border-koru-blue-200 hover:border-koru-blue-300 transition-all duration-300">
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Why Choose Our Programs?</h4>
              <ul className="text-gray-600 space-y-2">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-koru-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  Evidence-based methodologies with proven results
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-koru-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  Cultural intelligence integrated into every program
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-koru-gold-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  Ongoing support and measurement of impact
                </li>
              </ul>
            </div>

            <div className="text-center lg:text-left">
              <Button
                variant="link"
                className="text-koru-blue-600 hover:text-koru-blue-700 p-0 text-lg font-semibold group transition-colors duration-300 focus:ring-2 focus:ring-koru-blue-200"
                asChild
              >
                <Link href="/our-work/services">
                  LEARN MORE
                  <ArrowRight
                    className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300"
                    aria-hidden="true"
                  />
                  <span className="sr-only">Learn more about our services</span>
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
