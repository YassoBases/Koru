"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Quote } from "lucide-react"

export function GuidingPrinciples() {
  return (
    <section className="py-20 bg-gradient-to-br from-koru-blue-50 via-white to-koru-green-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-koru-blue-900 mb-6">Our Guiding Principles</h2>
          <p className="text-lg md:text-xl text-koru-blue-700 max-w-3xl mx-auto leading-relaxed">
            The foundational beliefs that drive our evidence-first approach to organizational transformation.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-7xl mx-auto">
          {/* Box 1: Evidence-First */}
          <Card className="group bg-white/80 backdrop-blur-sm border-koru-blue-200 hover:border-koru-blue-300 hover:shadow-xl transition-all duration-500 hover:-translate-y-2">
            <CardContent className="p-8 lg:p-10">
              <div className="flex items-start gap-4 mb-6">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-koru-blue-500 to-koru-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                  <Quote className="w-6 h-6 text-white" aria-hidden="true" />
                </div>
                <h3 className="text-2xl font-bold text-koru-blue-900 leading-tight">A Commitment to Evidence</h3>
              </div>

              <blockquote className="text-koru-blue-800 leading-relaxed mb-8 text-lg italic">
                "A simple survey can show you a symptom, but it rarely reveals the cause. We built our 'Evidence-First'
                doctrine on the principle of methodological triangulation—combining quantitative data with deep
                qualitative insights. It's the only way to move beyond surface-level problems and create lasting,
                systemic change."
              </blockquote>

              <div className="border-t border-koru-blue-200 pt-6">
                <div className="font-semibold text-koru-blue-900 text-lg">Şener Cem Irmak</div>
                <div className="text-koru-blue-600 font-medium">Founder & CEO</div>
              </div>
            </CardContent>
          </Card>

          {/* Box 2: Systemic Approach */}
          <Card className="group bg-white/80 backdrop-blur-sm border-koru-green-200 hover:border-koru-green-300 hover:shadow-xl transition-all duration-500 hover:-translate-y-2">
            <CardContent className="p-8 lg:p-10">
              <div className="flex items-start gap-4 mb-6">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-koru-green-500 to-koru-green-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                  <Quote className="w-6 h-6 text-white" aria-hidden="true" />
                </div>
                <h3 className="text-2xl font-bold text-koru-green-900 leading-tight">
                  The Power of a Systemic Approach
                </h3>
              </div>

              <blockquote className="text-koru-green-800 leading-relaxed mb-8 text-lg italic">
                "You can't fix a struggling plant by just polishing its leaves. We apply the same logic to
                organizations. Our work focuses on the entire ecosystem—the leadership, the culture, the communication
                systems—because that is where true resilience and flourishing are born."
              </blockquote>

              <div className="border-t border-koru-green-200 pt-6">
                <div className="font-semibold text-koru-green-900 text-lg">Şener Cem Irmak</div>
                <div className="text-koru-green-600 font-medium">Founder & CEO</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Trust indicator */}
        <div className="text-center mt-12">
          <p className="text-koru-blue-600 font-medium">
            Authentic insights that reinforce our intellectual rigor and build lasting trust
          </p>
        </div>
      </div>
    </section>
  )
}
