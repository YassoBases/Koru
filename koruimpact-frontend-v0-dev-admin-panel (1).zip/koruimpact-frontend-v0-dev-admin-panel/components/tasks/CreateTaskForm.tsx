// components/tasks/CreateTaskForm.tsx
"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { useAuth } from "@/contexts/AuthContext"
import { useState } from "react"
import { apiService } from "../../src/services/apiService"
import { CreateTaskDto, Task, TaskPriority, TaskStatus } from "../../src/types/task.types"

interface CreateTaskFormProps {
  onCreate: (task: Task) => void
}

export function CreateTaskForm({ onCreate }: CreateTaskFormProps) {
  const { user } = useAuth()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState<Omit<CreateTaskDto, 'assignedBy' | 'status'>>({
    title: "",
    description: "",
    priority: TaskPriority.MEDIUM,
    assignedTo: "",
    companyId: "", 
    dueDate: ""
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user?.uid || !formData.companyId) {
        console.error("User or Company ID not available");
        return;
    }

    setLoading(true)
    const taskData: CreateTaskDto = {
        ...formData,
        assignedBy: user.uid,
        status: TaskStatus.PENDING,
    };

    try {
      const newTask = await apiService.tasks.create(taskData)
      onCreate(newTask)
      
      setFormData({
        title: "",
        description: "",
        priority: TaskPriority.MEDIUM,
        assignedTo: "",
        companyId: "",
        dueDate: ""
      })
    } catch (error) {
      console.error('Error creating task:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-4 py-4">
      <div className="grid gap-2">
        <Label htmlFor="title">Title</Label>
        <Input
          id="title"
          placeholder="Task title"
          value={formData.title}
          onChange={(e) => handleInputChange("title", e.target.value)}
          required
        />
      </div>
      
      <div className="grid gap-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          placeholder="Task description"
          value={formData.description || ""}
          onChange={(e) => handleInputChange("description", e.target.value)}
        />
      </div>

      <div className="grid gap-2">
        <Label htmlFor="companyId">Company ID</Label>
        <Input
          id="companyId"
          placeholder="Enter the Company ID for this task"
          value={formData.companyId}
          onChange={(e) => handleInputChange("companyId", e.target.value)}
          required
        />
      </div>

      <div className="grid gap-2">
        <Label>Priority</Label>
        <RadioGroup
            value={formData.priority}
            onValueChange={(value: TaskPriority) => handleInputChange("priority", value)}
            className="flex space-x-4"
        >
            <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskPriority.LOW} id="low" />
                <Label htmlFor="low">Low</Label>
            </div>
            <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskPriority.MEDIUM} id="medium" />
                <Label htmlFor="medium">Medium</Label>
            </div>
            <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskPriority.HIGH} id="high" />
                <Label htmlFor="high">High</Label>
            </div>
             <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskPriority.CRITICAL} id="critical" />
                <Label htmlFor="critical">Critical</Label>
            </div>
        </RadioGroup>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label htmlFor="assignedTo">Assigned To (User ID)</Label>
          <Input
            id="assignedTo"
            placeholder="Enter User ID"
            value={formData.assignedTo || ""}
            onChange={(e) => handleInputChange("assignedTo", e.target.value)}
            required
          />
        </div>
        <div className="grid gap-2">
            <Label htmlFor="dueDate">Due Date</Label>
            <Input
            id="dueDate"
            type="date"
            value={formData.dueDate || ""}
            onChange={(e) => handleInputChange("dueDate", e.target.value)}
            />
        </div>
      </div>
      
      <Button type="submit" disabled={loading}>
        {loading ? "Creating..." : "Create Task"}
      </Button>
    </form>
  )
}