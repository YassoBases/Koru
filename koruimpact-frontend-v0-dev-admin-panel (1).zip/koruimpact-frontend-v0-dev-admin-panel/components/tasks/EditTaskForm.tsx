// components/tasks/EditTaskForm.tsx
"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { useEffect, useState } from "react"
import { apiService } from "../../src/services/apiService"
import { Task, TaskPriority, TaskStatus, UpdateTaskDto } from "../../src/types/task.types"

interface EditTaskFormProps {
  task: Task
  onUpdate: (task: Task) => void
}

export function EditTaskForm({ task, onUpdate }: EditTaskFormProps) {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState<UpdateTaskDto>({
    title: task.title,
    description: task.description,
    status: task.status,
    priority: task.priority,
    assignedTo: task.assignedTo,
    dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : ""
  })

  // This useEffect ensures the form resets if a different task is selected
  // while the dialog is already open.
  useEffect(() => {
    setFormData({
      title: task.title,
      description: task.description,
      status: task.status,
      priority: task.priority,
      assignedTo: task.assignedTo,
      dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : ""
    })
  }, [task])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    
    try {
      // The API service expects the task ID and the update data.
      const updatedTask = await apiService.tasks.update(task.id, formData)
      // The onUpdate callback passes the full updated task object back to the parent page.
      onUpdate(updatedTask)
    } catch (error) {
      console.error('Error updating task:', error)
      // You could add a toast notification for the error here.
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (field: keyof UpdateTaskDto, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-4 py-4">
      <div className="grid gap-2">
        <Label htmlFor="title-edit">Title</Label>
        <Input
          id="title-edit"
          placeholder="Task title"
          value={formData.title || ""}
          onChange={(e) => handleInputChange("title", e.target.value)}
          required
        />
      </div>
      
      <div className="grid gap-2">
        <Label htmlFor="description-edit">Description</Label>
        <Textarea
          id="description-edit"
          placeholder="Task description"
          value={formData.description || ""}
          onChange={(e) => handleInputChange("description", e.target.value)}
        />
      </div>
      
      <div className="grid gap-2">
        <Label>Status</Label>
        <RadioGroup
            value={formData.status}
            onValueChange={(value: TaskStatus) => handleInputChange("status", value)}
            className="flex items-center space-x-4"
        >
            <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskStatus.PENDING} id="pending-edit" />
                <Label htmlFor="pending-edit">Pending</Label>
            </div>
            <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskStatus.IN_PROGRESS} id="in_progress-edit" />
                <Label htmlFor="in_progress-edit">In Progress</Label>
            </div>
            <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskStatus.COMPLETED} id="completed-edit" />
                <Label htmlFor="completed-edit">Completed</Label>
            </div>
             <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskStatus.CANCELLED} id="cancelled-edit" />
                <Label htmlFor="cancelled-edit">Cancelled</Label>
            </div>
        </RadioGroup>
      </div>

      <div className="grid gap-2">
        <Label>Priority</Label>
        <RadioGroup
            value={formData.priority}
            onValueChange={(value: TaskPriority) => handleInputChange("priority", value)}
            className="flex items-center space-x-4"
        >
            <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskPriority.LOW} id="low-edit" />
                <Label htmlFor="low-edit">Low</Label>
            </div>
            <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskPriority.MEDIUM} id="medium-edit" />
                <Label htmlFor="medium-edit">Medium</Label>
            </div>
            <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskPriority.HIGH} id="high-edit" />
                <Label htmlFor="high-edit">High</Label>
            </div>
             <div className="flex items-center space-x-2">
                <RadioGroupItem value={TaskPriority.CRITICAL} id="critical-edit" />
                <Label htmlFor="critical-edit">Critical</Label>
            </div>
        </RadioGroup>
      </div>
      
      {/* This grid wrapper ensures the two fields below are side-by-side */}
      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
            <Label htmlFor="assignedTo-edit">Assigned To</Label>
            <Input
            id="assignedTo-edit"
            placeholder="User ID or Email"
            value={formData.assignedTo || ""}
            onChange={(e) => handleInputChange("assignedTo", e.target.value)}
            />
        </div>
        <div className="grid gap-2">
            <Label htmlFor="dueDate-edit">Due Date</Label>
            <Input
            id="dueDate-edit"
            type="date"
            value={formData.dueDate || ""}
            onChange={(e) => handleInputChange("dueDate", e.target.value)}
            />
        </div>
      </div>
      
      <Button type="submit" disabled={loading}>
        {loading ? "Saving..." : "Save Changes"}
      </Button>
    </form>
  )
}
