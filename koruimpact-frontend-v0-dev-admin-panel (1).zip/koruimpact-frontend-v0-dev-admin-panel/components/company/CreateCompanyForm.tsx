"use client"

import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/contexts/AuthContext"
import { Building } from "lucide-react"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { apiService } from "../../src/services/apiService"
import { CompanySize, CreateCompanyDto } from "../../src/types/company.types"

export function CreateCompanyForm() {
  const { user, updateCompany } = useAuth()
  const router = useRouter()
  const { toast } = useToast();
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [formData, setFormData] = useState<CreateCompanyDto>({
    name: "",
    description: "",
    industry: "",
    size: CompanySize.SMALL, // Default value
    website: "",
    contactEmail: user?.email || "",
    phoneNumber: "",
    address: {
      street: "",
      city: "",
      state: "",
      country: "",
      postalCode: ""
    }
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const response = await apiService.companies.create(formData)
      if (response.success && response.data) {
        updateCompany(response.data) // Update the company in the AuthContext
        toast({
          title: "Company Created!",
          description: "Your company profile has been successfully created.",
        });
        router.push(`/company/${response.data.companyId}/dashboard`)
      } else {
        throw new Error(response.message || "Failed to create company.");
      }
    } catch (err: any) {
      setError(err.message || "Failed to create company. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (field: keyof CreateCompanyDto, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleAddressChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      address: {
        ...prev.address,
        [field]: value
      }
    }))
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
            <div className="p-3 bg-blue-100 rounded-full">
                <Building className="h-8 w-8 text-blue-600" />
            </div>
        </div>
        <CardTitle className="text-2xl font-bold">Set Up Your Company</CardTitle>
        <CardDescription>
          Create your company profile to start managing your team and projects.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Company Name *</Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="Your Company Name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ""}
                onChange={(e) => handleInputChange("description", e.target.value)}
                placeholder="Brief description of your company"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="industry">Industry</Label>
                <Input
                  id="industry"
                  type="text"
                  value={formData.industry || ""}
                  onChange={(e) => handleInputChange("industry", e.target.value)}
                  placeholder="e.g., Technology, Healthcare"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="size">Company Size</Label>
                <Select value={formData.size} onValueChange={(value: CompanySize) => handleInputChange("size", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select company size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={CompanySize.STARTUP}>Startup (1-10 employees)</SelectItem>
                    <SelectItem value={CompanySize.SMALL}>Small (11-50 employees)</SelectItem>
                    <SelectItem value={CompanySize.MEDIUM}>Medium (51-200 employees)</SelectItem>
                    <SelectItem value={CompanySize.LARGE}>Large (201-1000 employees)</SelectItem>
                    <SelectItem value={CompanySize.ENTERPRISE}>Enterprise (1000+ employees)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  type="url"
                  value={formData.website || ""}
                  onChange={(e) => handleInputChange("website", e.target.value)}
                  placeholder="https://yourcompany.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phoneNumber">Phone Number</Label>
                <Input
                  id="phoneNumber"
                  type="tel"
                  value={formData.phoneNumber || ""}
                  onChange={(e) => handleInputChange("phoneNumber", e.target.value)}
                  placeholder="+1 (555) 123-4567"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="contactEmail">Contact Email</Label>
              <Input
                id="contactEmail"
                type="email"
                value={formData.contactEmail || ""}
                onChange={(e) => handleInputChange("contactEmail", e.target.value)}
                placeholder="contact@yourcompany.com"
              />
            </div>

            <div className="space-y-4 pt-4 border-t">
              <Label className="text-base font-medium">Address (Optional)</Label>
              
              <div className="space-y-2">
                <Label htmlFor="street">Street Address</Label>
                <Input
                  id="street"
                  type="text"
                  value={formData.address?.street || ""}
                  onChange={(e) => handleAddressChange("street", e.target.value)}
                  placeholder="123 Main Street"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    type="text"
                    value={formData.address?.city || ""}
                    onChange={(e) => handleAddressChange("city", e.target.value)}
                    placeholder="New York"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state">State/Province</Label>
                  <Input
                    id="state"
                    type="text"
                    value={formData.address?.state || ""}
                    onChange={(e) => handleAddressChange("state", e.target.value)}
                    placeholder="NY"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="country">Country</Label>
                  <Input
                    id="country"
                    type="text"
                    value={formData.address?.country || ""}
                    onChange={(e) => handleAddressChange("country", e.target.value)}
                    placeholder="United States"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="postalCode">Postal Code</Label>
                  <Input
                    id="postalCode"
                    type="text"
                    value={formData.address?.postalCode || ""}
                    onChange={(e) => handleAddressChange("postalCode", e.target.value)}
                    placeholder="10001"
                  />
                </div>
              </div>
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Creating Company..." : "Create Company"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
