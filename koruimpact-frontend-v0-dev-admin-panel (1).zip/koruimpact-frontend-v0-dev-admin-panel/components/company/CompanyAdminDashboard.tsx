"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { apiService } from "../../src/services/apiService"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { StatCard } from "@/components/dashboard/StatCard"
import { TeamManagement } from "@/components/team/TeamManagement"
import { InviteAdminForm } from "@/components/team/InviteAdminForm"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Users, Building, CheckCircle, Clock, Plus } from 'lucide-react'
import { User } from "../../src/types/user.types"
import { Company } from "../../src/types/company.types"

export function CompanyAdminDashboard() {
  const { user, company, updateCompany } = useAuth()
  const [loading, setLoading] = useState(true)
  const [teamMembers, setTeamMembers] = useState<User[]>([])
  const [companyData, setCompanyData] = useState<Company | null>(company)
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false)

  useEffect(() => {
    if (company?.companyId) {
      loadCompanyData()
    }
  }, [company?.companyId])

  const loadCompanyData = async () => {
    if (!company?.companyId) return

    try {
      setLoading(true)
      
      // Load fresh company data
      const companyResponse = await apiService.companies.getById(company.companyId)
      setCompanyData(companyResponse.data)
      updateCompany(companyResponse.data)

      // Load team members (admins and members)
      const allUserIds = [...companyResponse.data.adminIds, ...companyResponse.data.memberIds]
      const memberPromises = allUserIds.map(userId => 
        apiService.users.getById(userId).catch(() => null)
      )
      
      const memberResults = await Promise.all(memberPromises)
      const validMembers = memberResults
        .filter((result): result is { user: User } => result !== null)
        .map(result => result.user)
      
      setTeamMembers(validMembers)
    } catch (error) {
      console.error('Error loading company data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleInviteAdmin = async (email: string) => {
    if (!company?.companyId) return

    try {
      await apiService.companies.addAdmin(company.companyId, { email })
      setInviteDialogOpen(false)
      await loadCompanyData() // Refresh data
    } catch (error) {
      console.error('Error inviting admin:', error)
      throw error
    }
  }

  const handleRemoveMember = async (userId: string) => {
    if (!company?.companyId) return

    try {
      await apiService.companies.removeAdmin(company.companyId, userId)
      await loadCompanyData() // Refresh data
    } catch (error) {
      console.error('Error removing member:', error)
      throw error
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading dashboard...</div>
  }

  if (!companyData) {
    return <div className="flex items-center justify-center h-64">Company data not found</div>
  }

  const adminMembers = teamMembers.filter(member => 
    companyData.adminIds.includes(member.uid)
  )
  
  const regularMembers = teamMembers.filter(member => 
    companyData.memberIds.includes(member.uid)
  )

  return (
    <div className="flex flex-col gap-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Company Dashboard</h1>
          <p className="text-lg text-muted-foreground">
            Welcome back, {user?.displayName || user?.email}
          </p>
        </div>
        
        <Dialog open={inviteDialogOpen} onOpenChange={setInviteDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Invite Admin
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Invite New Admin</DialogTitle>
            </DialogHeader>
            <InviteAdminForm onInvite={handleInviteAdmin} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Company Status"
          value={companyData.status}
          description={`Size: ${companyData.size}`}
          icon={<Building className="h-5 w-5 text-muted-foreground" />}
        />
        <StatCard
          title="Total Admins"
          value={adminMembers.length.toString()}
          description="Company administrators"
          icon={<Users className="h-5 w-5 text-muted-foreground" />}
        />
        <StatCard
          title="Total Members"
          value={regularMembers.length.toString()}
          description="Company members"
          icon={<Users className="h-5 w-5 text-muted-foreground" />}
        />
        <StatCard
          title="Active Projects"
          value="0"
          description="Coming soon"
          icon={<CheckCircle className="h-5 w-5 text-muted-foreground" />}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Company Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold">Company Name</h3>
              <p className="text-muted-foreground">{companyData.name}</p>
            </div>
            {companyData.description && (
              <div>
                <h3 className="font-semibold">Description</h3>
                <p className="text-muted-foreground">{companyData.description}</p>
              </div>
            )}
            {companyData.industry && (
              <div>
                <h3 className="font-semibold">Industry</h3>
                <p className="text-muted-foreground">{companyData.industry}</p>
              </div>
            )}
            {companyData.website && (
              <div>
                <h3 className="font-semibold">Website</h3>
                <a 
                  href={companyData.website} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  {companyData.website}
                </a>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Company created on {new Date(companyData.createdAt).toLocaleDateString()}
              </p>
              <p className="text-sm text-muted-foreground">
                Last updated on {new Date(companyData.updatedAt).toLocaleDateString()}
              </p>
              <p className="text-sm text-muted-foreground">
                {teamMembers.length} total team members
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <TeamManagement 
        members={teamMembers.map(member => ({
          id: member.uid,
          email: member.email,
          role: companyData.adminIds.includes(member.uid) ? "admin" : "member"
        }))}
        onRemove={handleRemoveMember}
      />
    </div>
  )
}
