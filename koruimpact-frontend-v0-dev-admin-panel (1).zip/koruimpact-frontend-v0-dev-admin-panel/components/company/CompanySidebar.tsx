"use client"

import Link from "next/link"
import Image from "next/image"
import { Briefcase, LayoutDashboard, Users, ListTodo, Settings, LogOut } from 'lucide-react'
import { usePathname, useRouter } from "next/navigation"
import { useAuth } from "@/contexts/AuthContext"
import { cn } from "@/lib/utils"

export function CompanySidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { user, logout } = useAuth()

  const companyId = user?.companyId // Get companyId from authenticated user

  const navItems = [
    {
      name: "Dashboard",
      href: `/company/${companyId}/dashboard`,
      icon: LayoutDashboard,
      roles: ["admin", "member"],
    },
    {
      name: "Tasks",
      href: `/company/${companyId}/tasks`,
      icon: ListTodo,
      roles: ["admin", "member"],
    },
    {
      name: "Team",
      href: `/company/${companyId}/team`,
      icon: Users,
      roles: ["admin"], // Only admins can manage team
    },
    {
      name: "Settings",
      href: `/company/${companyId}/settings`, // Placeholder
      icon: Settings,
      roles: ["admin"],
    },
  ]

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  if (!user || !companyId) {
    return null // Or a loading state, ProtectedRoute should handle redirection
  }

  return (
    <div className="hidden border-r bg-muted/40 lg:block">
      <div className="flex h-full max-h-screen flex-col gap-2">
        <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
          <Link href={`/company/${companyId}/dashboard`} className="flex items-center gap-2 font-semibold">
            <Briefcase className="h-6 w-6" />
            <span className="">Company Portal</span>
          </Link>
        </div>
        <div className="flex-1">
          <nav className="grid items-start px-2 text-sm font-medium lg:px-4">
            {navItems.map((item) => {
              // Only render if the user's role is allowed for this item
              if (item.roles.includes(user.role)) {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary",
                      isActive && "bg-muted text-primary"
                    )}
                  >
                    <item.icon className="h-4 w-4" />
                    {item.name}
                  </Link>
                )
              }
              return null
            })}
          </nav>
        </div>
        <div className="mt-auto p-4">
          <Button variant="secondary" className="w-full" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  )
}
