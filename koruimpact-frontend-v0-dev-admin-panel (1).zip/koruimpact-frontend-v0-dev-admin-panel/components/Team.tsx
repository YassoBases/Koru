import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Linkedin, Twitter } from 'lucide-react'
import Link from "next/link"

export function Team() {
  const teamMembers = [
    {
      name: "Dr. Anya Sharma",
      title: "Founder & Lead Organizational Psychologist",
      description: "Specializing in psychological safety and high-performing teams. Anya brings over 15 years of experience in organizational development and research.",
      image: "/placeholder-user.jpg",
      linkedin: "#",
      twitter: "#",
    },
    {
      name: "Mark Chen",
      title: "Head of Strategy & Innovation",
      description: "Expert in change management and strategic planning. Mark helps organizations navigate complex transitions and foster a culture of innovation.",
      image: "/placeholder-user.jpg",
      linkedin: "#",
      twitter: "#",
    },
    {
      name: "Sarah Lee",
      title: "Senior Consultant, Leadership Development",
      description: "Focuses on empowering leaders through tailored coaching and development programs. Sarah has a strong background in executive education.",
      image: "/placeholder-user.jpg",
      linkedin: "#",
      twitter: "#",
    },
    {
      name: "David Kim",
      title: "Research & Analytics Lead",
      description: "Drives our evidence-first approach by leading data collection, analysis, and research initiatives to ensure measurable impact.",
      image: "/placeholder-user.jpg",
      linkedin: "#",
      twitter: "#",
    },
  ]

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Meet Our Expert Team
            </h2>
            <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              Our diverse team of organizational psychologists, strategists, and consultants are dedicated to your success.
            </p>
          </div>
        </div>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 mt-10">
          {teamMembers.map((member, index) => (
            <Card key={index} className="flex flex-col items-center text-center p-6">
              <Image
                src={member.image || "/placeholder.svg"}
                width={120}
                height={120}
                alt={`Photo of ${member.name}`}
                className="rounded-full object-cover mb-4"
              />
              <CardHeader className="p-0 mb-4">
                <CardTitle className="text-xl font-bold">{member.name}</CardTitle>
                <CardDescription className="text-primary text-sm font-medium">
                  {member.title}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1 p-0">
                <p className="text-gray-500 dark:text-gray-400 text-sm">
                  {member.description}
                </p>
              </CardContent>
              <div className="flex gap-3 mt-4">
                {member.linkedin && (
                  <Link href={member.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-100">
                    <Linkedin className="h-5 w-5" />
                    <span className="sr-only">LinkedIn</span>
                  </Link>
                )}
                {member.twitter && (
                  <Link href={member.twitter} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-100">
                    <Twitter className="h-5 w-5" />
                    <span className="sr-only">Twitter</span>
                  </Link>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
