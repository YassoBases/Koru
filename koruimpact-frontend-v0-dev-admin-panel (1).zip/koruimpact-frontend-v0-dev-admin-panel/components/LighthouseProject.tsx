import Link from "next/link"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export function LighthouseProject() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800">
      <div className="container px-4 md:px-6">
        <div className="grid items-center gap-6 lg:grid-cols-2 lg:gap-12">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">
                The Lighthouse Project: Our Flagship Initiative
              </h2>
              <p className="max-w-[600px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                A testament to our evidence-first approach, the Lighthouse Project showcases how rigorous research and tailored interventions lead to profound organizational transformation.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button asChild>
                <Link href="/our-work/lighthouse-project">Learn More</Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/research/the-lighthouse-project">View Research</Link>
              </Button>
            </div>
          </div>
          <Image
            src="/placeholder.svg?height=400&width=600"
            width={600}
            height={400}
            alt="Lighthouse Project"
            className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full"
          />
        </div>
      </div>
    </section>
  )
}
