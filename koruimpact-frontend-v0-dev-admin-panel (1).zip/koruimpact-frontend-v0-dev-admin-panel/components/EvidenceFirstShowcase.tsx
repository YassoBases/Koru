import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export function EvidenceFirstShowcase() {
  const showcaseItems = [
    {
      title: "Organizational Psychology",
      badge: "WORKPLACE WELLNESS",
      description: "Understanding the psychological dynamics that drive organizational behavior and performance",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/organizational-psychology-workspace.jpg-r7XZgbNRAFZA996yTDqjWyMb0nE5m9.jpeg",
      href: "/our-approach/organizational-audit",
    },
    {
      title: "Burnout Prevention",
      badge: "PREVENTION",
      description: "Systematic approaches to identifying and preventing burnout before it impacts your organization",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/burnout-prevention-coffee.jpg-RgtZ97tNtgZDwf68ZqXLXdjULsYSAk.jpeg",
      href: "/our-approach/organizational-audit",
    },
    {
      title: "Psychological Safety",
      badge: "TEAM DYNAMICS",
      description: "Creating environments where teams feel safe to speak up, take risks, and be vulnerable",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/psychological-safety-office.jpg-xlUBqMKPglV4mD8JyIbbYT6HhPSqPS.jpeg",
      href: "/our-approach/organizational-audit",
    },
    {
      title: "Cultural Transformation",
      badge: "LEADERSHIP",
      description: "Evidence-based approaches to transforming organizational culture through validated insights",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/cultural-transformation-professionals-SQKB46CqlJsllH9LmgkjdgX5uDGwLw.png",
      href: "/our-approach/organizational-audit",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-koru-green-50 via-gray-50 to-koru-blue-50">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Beyond the Survey: Our Evidence-First Audit
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Traditional surveys miss the cultural nuances and systemic factors that drive organizational challenges.
              Our comprehensive audit combines quantitative data with qualitative validation to deliver reliable
              evidence.
            </p>
          </div>

          {/* 2x2 Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            {showcaseItems.map((item, index) => (
              <Card
                key={index}
                className="group hover:shadow-2xl transition-all duration-500 overflow-hidden border-0 bg-white/80 backdrop-blur-sm hover:bg-white animate-slide-in-left"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={`${item.title} - ${item.description}`}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent group-hover:from-black/30 transition-all duration-300"></div>
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-koru-green-600 hover:bg-koru-green-700 text-white shadow-lg">
                      {item.badge}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-koru-blue-700 transition-colors duration-300">
                    {item.title}
                  </h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">{item.description}</p>
                  <Button
                    asChild
                    variant="ghost"
                    className="p-0 h-auto text-koru-blue-600 hover:text-koru-blue-700 group-hover:translate-x-2 transition-all duration-300 focus:ring-2 focus:ring-koru-blue-200"
                  >
                    <Link href={item.href} className="flex items-center">
                      Learn More
                      <ArrowRight
                        className="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform duration-300"
                        aria-hidden="true"
                      />
                      <span className="sr-only">Learn more about {item.title}</span>
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Data Validity Paradox Explanation */}
          <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-8 border border-koru-blue-200 shadow-lg hover:shadow-xl transition-all duration-300 animate-fade-in">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">The Data Validity Paradox</h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              In cultures with high Power Distance and Uncertainty Avoidance, traditional surveys often capture what
              employees think leadership wants to hear, not organizational reality. Our triangulated approach validates
              quantitative findings through confidential qualitative methods, ensuring you get evidence, not just data.
            </p>
            <Button
              asChild
              className="bg-koru-gold-500 hover:bg-koru-gold-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 focus:ring-4 focus:ring-koru-gold-200"
            >
              <Link href="/our-approach">
                Discover Our Methodology
                <ArrowRight className="ml-2 w-4 h-4" aria-hidden="true" />
                <span className="sr-only">Learn about our methodology</span>
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
