'use client';

import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from "@/components/ui/use-toast";
import { ExclamationTriangleIcon } from '@radix-ui/react-icons';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { RegisterUserDto } from '../../src/types/auth.types';
import { UserRole } from '../../src/types/user.types';

export default function RegisterForm() {
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.INDIVIDUAL);
  const [companyId, setCompanyId] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const { register, authError, isLoading, clearAuthError, isAuthenticated, user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    if (isAuthenticated && user) {
      return;
    }
  }, [isAuthenticated, user, router]);

  useEffect(() => {
    if (authError) clearAuthError();
    if (formError) setFormError(null);
  }, [email, password, displayName, role, companyId, authError, clearAuthError, formError]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    clearAuthError();

    if (!role) {
      setFormError('Please select an account type.');
      return;
    }
    if (password !== confirmPassword) {
      setFormError('Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      setFormError('Password must be at least 6 characters long.');
      return;
    }
    const name = displayName.trim();
    if (!name) {
      setFormError('Full name is required.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setFormError('Please enter a valid email address.');
      return;
    }

    const userData: RegisterUserDto = {
      email,
      password,
      name,
      role,
      companyId: (role === UserRole.EMPLOYEE || role === UserRole.COMPANY_ADMIN) && companyId 
        ? companyId 
        : undefined,
      permissions: [],
      profile: {},
    };

    const response = await register(userData);

    if (response.success) {
      toast({
        title: "Account Created!",
        description: "You have successfully registered. Please log in to continue.",
      });
      setDisplayName('');
      setEmail('');
      setPassword('');
      setConfirmPassword('');
      setRole(UserRole.INDIVIDUAL);
      setCompanyId('');
      setTimeout(() => {
        router.push('/login');
      }, 1500);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900">
      <div className="w-full max-w-md">
        <div className="mb-6">
          <Link
            href="/"
            className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Link>
        </div>
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Create Account</CardTitle>
          </CardHeader>
          <CardContent>
            {(authError || formError) && (
              <Alert variant="destructive" className="mb-4">
                <ExclamationTriangleIcon className="h-4 w-4" />
                <AlertTitle>Registration Error</AlertTitle>
                <AlertDescription>{authError || formError}</AlertDescription>
              </Alert>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="displayName">Full Name *</Label>
                <Input
                  id="displayName"
                  type="text"
                  placeholder="John Doe"
                  required
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="john.doe@example.com"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter a secure password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password *</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Confirm your password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Account Type *</Label>
                <RadioGroup
                  value={role}
                  onValueChange={(value: UserRole) => {
                    setRole(value);
                    if (value === UserRole.INDIVIDUAL) {
                      setCompanyId('');
                    }
                  }}
                  className="grid grid-cols-1 sm:grid-cols-2 gap-4"
                >
                  <Label htmlFor="individual" className="flex flex-col items-start justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                    <div className="flex items-center w-full justify-between">
                      <span className="font-semibold">Individual</span>
                      <RadioGroupItem value={UserRole.INDIVIDUAL} id="individual" />
                    </div>
                    <span className="text-sm text-muted-foreground mt-2">Personal account with basic access.</span>
                  </Label>
                   <Label htmlFor="employee" className="flex flex-col items-start justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                    <div className="flex items-center w-full justify-between">
                      <span className="font-semibold">Employee</span>
                      <RadioGroupItem value={UserRole.EMPLOYEE} id="employee" />
                    </div>
                    <span className="text-sm text-muted-foreground mt-2">Join an existing company.</span>
                  </Label>
                   <Label htmlFor="company_admin" className="flex flex-col items-start justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                    <div className="flex items-center w-full justify-between">
                      <span className="font-semibold">Company Admin</span>
                      <RadioGroupItem value={UserRole.COMPANY_ADMIN} id="company_admin" />
                    </div>
                    <span className="text-sm text-muted-foreground mt-2">Manage a company and its members.</span>
                  </Label>
                   <Label htmlFor="admin" className="flex flex-col items-start justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                    <div className="flex items-center w-full justify-between">
                      <span className="font-semibold">Admin</span>
                      <RadioGroupItem value={UserRole.ADMIN} id="admin" />
                    </div>
                    <span className="text-sm text-muted-foreground mt-2">For internal Koru Impact staff.</span>
                  </Label>
                </RadioGroup>
              </div>

              {(role === UserRole.EMPLOYEE || role === UserRole.COMPANY_ADMIN) && (
                <div className="space-y-2 animate-in fade-in-50 duration-500">
                  <Label htmlFor="companyId">Company ID *</Label>
                  <Input
                    id="companyId"
                    type="text"
                    placeholder="Enter your company ID"
                    value={companyId}
                    onChange={(e) => setCompanyId(e.target.value)}
                    required
                  />
                  <p className="text-xs text-gray-500">
                    Contact your company administrator for the company ID.
                  </p>
                </div>
              )}

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'Creating Account...' : 'Create Account'}
              </Button>
            </form>
            
            <div className="mt-6 text-center text-sm">
              Already have an account?{' '}
              <Link className="text-blue-600 hover:text-blue-800 underline" href="/login">
                Sign in
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
