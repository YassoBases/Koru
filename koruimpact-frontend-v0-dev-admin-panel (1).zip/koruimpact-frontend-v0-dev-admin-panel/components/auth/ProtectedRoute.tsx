"use client"

import { LoadingSpinner } from "@/components/LoadingSpinner"
import { useAuth } from "@/contexts/AuthContext"
import { UserRole } from "@/src/types"
import { useRouter } from "next/navigation"
import { useEffect } from "react"

interface ProtectedRouteProps {
  children: React.ReactNode
  allowedRoles: UserRole[]
  companyId?: string // Optional: for company-specific routes
}

export function ProtectedRoute({ children, allowedRoles, companyId }: ProtectedRouteProps) {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (loading) {
      return // Still loading, do nothing
    }

    if (!user) {
      // Not authenticated, redirect to login
      router.push("/login")
      return
    }

    // Check if user's role is allowed
    if (!allowedRoles.includes(user.role)) {
      // Role not allowed, redirect to a suitable page (e.g., dashboard or home)
      if (user.role === UserRole.ADMIN || user.role === UserRole.SUPERADMIN) {
        router.push(`/admin`)
      } else if (user.role === UserRole.COMPANY_ADMIN && user.companyId) {
        router.push(`/company/${user.companyId}/dashboard`)
      } else if (user.role === UserRole.EMPLOYEE && user.companyId) {
        router.push(`/company/${user.companyId}/dashboard`)
      } else if (user.role === UserRole.INDIVIDUAL) {
        router.push("/dashboard")
      } else {
        router.push("/") // Fallback
      }
      return
    }

    // If companyId is provided for a route, check if the user belongs to that company
    if (companyId && user.companyId !== companyId) {
      // User does not belong to this company, redirect
       if (user.role === UserRole.ADMIN || user.role === UserRole.SUPERADMIN) {
        router.push(`/admin`)
      } else if (user.companyId) {
        router.push(`/company/${user.companyId}/dashboard`)
      } else {
        router.push("/") // Fallback
      }
      return
    }

    // If user is a COMPANY_ADMIN and doesn't have a company yet, redirect to create company
    if (user.role === UserRole.COMPANY_ADMIN && !user.companyId && router.pathname !== "/company/create") {
      router.push("/company/create")
      return
    }

  }, [user, loading, router, allowedRoles, companyId])

  if (loading || !user || !allowedRoles.includes(user.role) || (companyId && user.companyId !== companyId)) {
    // Show loading spinner while checking auth or if redirection is pending
    return <LoadingSpinner />
  }

  return <>{children}</>
}