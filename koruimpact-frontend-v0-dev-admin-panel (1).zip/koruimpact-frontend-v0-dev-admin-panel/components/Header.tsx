"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sheet, SheetTrigger, SheetContent } from "@/components/ui/sheet"
import { Menu, Package2, Search } from 'lucide-react'
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from "@/components/ui/dropdown-menu"
import { useAuth } from "@/contexts/AuthContext"
import { useRouter } from "next/navigation"
import Image from "next/image"

export function Header() {
  const { user, logout } = useAuth()
  const router = useRouter()

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  return (
    <header className="sticky top-0 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6 z-50">
      <nav className="hidden flex-col gap-6 text-lg font-medium md:flex md:flex-row md:items-center md:gap-5 md:text-sm lg:gap-6">
        <Link
          href="/"
          className="flex items-center gap-2 text-lg font-semibold md:text-base"
        >
          <Image
            src="/public/images/koru-logo.png"
            alt="Koru Impact Logo"
            width={32}
            height={32}
            className="h-6 w-6"
          />
          <span className="sr-only">Koru Impact</span>
        </Link>
        <Link
          href="/our-approach"
          className="text-foreground transition-colors hover:text-foreground"
        >
          Our Approach
        </Link>
        <Link
          href="/our-work"
          className="text-muted-foreground transition-colors hover:text-foreground"
        >
          Our Work
        </Link>
        <Link
          href="/insights"
          className="text-muted-foreground transition-colors hover:text-foreground"
        >
          Insights
        </Link>
        <Link
          href="/about"
          className="text-muted-foreground transition-colors hover:text-foreground"
        >
          About
        </Link>
        <Link
          href="/contact"
          className="text-muted-foreground transition-colors hover:text-foreground"
        >
          Contact
        </Link>
        {user && user.role === "admin" && (
          <Link
            href="/admin"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            Admin
          </Link>
        )}
        {user && (user.role === "admin" || user.role === "member") && user.companyId && (
          <Link
            href={`/company/${user.companyId}/dashboard`}
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            Company Dashboard
          </Link>
        )}
        {user && user.role === "individual" && (
          <Link
            href="/dashboard"
            className="text-muted-foreground transition-colors hover:text-foreground"
          >
            My Dashboard
          </Link>
        )}
      </nav>
      <Sheet>
        <SheetTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="shrink-0 md:hidden"
          >
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle navigation menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left">
          <nav className="grid gap-6 text-lg font-medium">
            <Link
              href="/"
              className="flex items-center gap-2 text-lg font-semibold"
            >
              <Image
                src="/public/images/koru-logo.png"
                alt="Koru Impact Logo"
                width={32}
                height={32}
                className="h-6 w-6"
              />
              <span className="sr-only">Koru Impact</span>
            </Link>
            <Link href="/our-approach" className="hover:text-foreground">
              Our Approach
            </Link>
            <Link href="/our-work" className="text-muted-foreground hover:text-foreground">
              Our Work
            </Link>
            <Link href="/insights" className="text-muted-foreground hover:text-foreground">
              Insights
            </Link>
            <Link href="/about" className="text-muted-foreground hover:text-foreground">
              About
            </Link>
            <Link href="/contact" className="text-muted-foreground hover:text-foreground">
              Contact
            </Link>
            {user && user.role === "admin" && (
              <Link href="/admin" className="text-muted-foreground hover:text-foreground">
                Admin
              </Link>
            )}
            {user && (user.role === "admin" || user.role === "member") && user.companyId && (
              <Link href={`/company/${user.companyId}/dashboard`} className="text-muted-foreground hover:text-foreground">
                Company Dashboard
              </Link>
            )}
            {user && user.role === "individual" && (
              <Link href="/dashboard" className="text-muted-foreground hover:text-foreground">
                My Dashboard
              </Link>
            )}
          </nav>
        </SheetContent>
      </Sheet>
      <div className="flex w-full items-center gap-4 md:ml-auto md:gap-2 lg:gap-4">
        <form className="ml-auto flex-1 sm:flex-initial">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search products..."
              className="pl-8 sm:w-[300px] md:w-[200px] lg:w-[300px]"
            />
          </div>
        </form>
        {user ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="secondary" size="icon" className="rounded-full">
                <Image
                  src="/public/placeholder-user.jpg"
                  width={36}
                  height={36}
                  alt="Avatar"
                  className="overflow-hidden rounded-full"
                />
                <span className="sr-only">Toggle user menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>My Account</DropdownMenuItem>
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout}>Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <Button asChild>
            <Link href="/login">Login</Link>
          </Button>
        )}
      </div>
    </header>
  )
}
