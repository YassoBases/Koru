import { Star } from 'lucide-react'

export function TrustSignals() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Why Choose Koru Impact?
            </h2>
            <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              Our commitment to evidence, expertise, and measurable results sets us apart.
            </p>
          </div>
        </div>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 mt-10">
          <div className="flex flex-col items-center text-center p-6 bg-white dark:bg-gray-950 rounded-lg shadow-sm">
            <div className="bg-primary/10 p-3 rounded-full mb-4">
              <Star className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-2">Evidence-First Approach</h3>
            <p className="text-gray-500 dark:text-gray-400">
              All our strategies and interventions are grounded in the latest scientific research and data.
            </p>
          </div>
          <div className="flex flex-col items-center text-center p-6 bg-white dark:bg-gray-950 rounded-lg shadow-sm">
            <div className="bg-primary/10 p-3 rounded-full mb-4">
              <Star className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-2">Expert Team</h3>
            <p className="text-gray-500 dark:text-gray-400">
              Work with leading organizational psychologists and seasoned consultants with deep industry knowledge.
            </p>
          </div>
          <div className="flex flex-col items-center text-center p-6 bg-white dark:bg-gray-950 rounded-lg shadow-sm">
            <div className="bg-primary/10 p-3 rounded-full mb-4">
              <Star className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-2">Measurable Impact</h3>
            <p className="text-gray-500 dark:text-gray-400">
              We focus on delivering tangible, measurable results that drive real organizational change.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
