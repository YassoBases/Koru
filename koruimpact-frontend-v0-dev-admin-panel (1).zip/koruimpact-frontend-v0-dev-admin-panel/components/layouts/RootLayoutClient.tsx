"use client"

import { Footer } from "@/components/Footer"
import { Header } from "@/components/Header"
import { usePathname } from 'next/navigation'

export function RootLayoutClient({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const isAdminRoute = pathname.startsWith('/admin') || pathname.startsWith('/superadmin')

  return (
    <div className="flex flex-col min-h-screen">
      {!isAdminRoute && <Header />}
      <main className="flex-grow">
        {children}
      </main>
      {!isAdminRoute && <Footer />}
    </div>
  )
}
